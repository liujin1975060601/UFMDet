# @article{FourierDetByJinLiu,
#     author  = "Jin Liu; Zhongyuan Lu; Yaorong Cen; Hui Hu; Zhenfeng Shao; Yong Hong, Ming Jiang, Miaozhong Xu",
#     title   = "Enhancing Object Detection With Fourier Series",
#     year    = "January 8, 2025",
#     journal = "IEEE Transactions on Pattern Analysis and Machine Intelligence",
#     volume  = "47",
#     number  = "4",
#     pages   = "2581 - 2596",
#     doi = 10.1109/TPAMI.2025.3526990,
#     month   = "January",
# }
# @article{FourierDetByJinLiu,
#     author  = "Jin Liu, Huan Li, Zhenfeng Shao, Biyin Zhang, Mi Wang",
#     title   = "UFMDet: Unified Fourier Multi-shape Detection for Blob-like and Line-like Objects in Natural Scenes",
#     Submit to "IEEE Transactions on Pattern Analysis and Machine Intelligence",
# }

import argparse
import json
import os
import sys
from pathlib import Path
from threading import Thread

import numpy as np
import torch
from tqdm import tqdm
import matplotlib.pyplot as plt

FILE = Path(__file__).absolute()
sys.path.append(FILE.parents[0].as_posix())  # add yolov5/ to path

from models.experimental import attempt_load
from models.yolo import OUT_LAYER
from utils.datasets import create_dataloader
from utils.general import coco80_to_coco91_class, check_dataset, check_file, check_img_size, check_requirements, \
    box_iou, scale_coords, xyxy2xywh, xywh2xyxy, set_logging, increment_path, colorstr, \
    PROCESS_BATCH_DICT
from utils.post_process import non_max_suppression, non_max_suppression_dfl,non_max_suppression_ft
from utils.metrics import ap_per_class, ConfusionMatrix, process_batch_ft
from utils.plots import plot_images, output_to_target, plot_study_txt
from utils.torch_utils import select_device, time_sync
from utils.callbacks import Callbacks
import csv
from utils.loss import loop_loss

from copy import deepcopy

import csv # save classes_map to excel
from tools.histrans import Histrans
import pickle
import cv2
from utils.plots import Annotator, colors

import shutil

torch.set_printoptions(linewidth=320, precision=4, profile="default")
np.set_printoptions(linewidth=320, formatter={"float_kind": "{:11.5g}".format})  # format short g, %precision=5

def save_one_txt(predn, save_conf, shape, file):
    # Save one txt result
    gn = torch.tensor(shape)[[1, 0, 1, 0]]  # normalization gain whwh
    for *xyxy, conf, cls in predn.tolist():
        xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
        line = (cls, *xywh, conf) if save_conf else (cls, *xywh)  # label format
        with open(file, 'a') as f:
            f.write(('%g ' * len(line)).rstrip() % line + '\n')


def save_one_json(predn, jdict, path, class_map):
    # Save one JSON result {"image_id": 42, "category_id": 18, "bbox": [258.15, 41.29, 348.26, 243.78], "score": 0.236}
    image_id = int(path.stem) if path.stem.isnumeric() else path.stem
    box = xyxy2xywh(predn[:, :4])  # xywh
    box[:, :2] -= box[:, 2:] / 2  # xy center to top-left corner
    for p, b in zip(predn.tolist(), box.tolist()):
        jdict.append({'image_id': image_id,
                      'category_id': class_map[int(p[5])],
                      'bbox': [round(x, 3) for x in b],
                      'score': round(p[4], 5)})


@torch.no_grad()
def run(data,
        weights=None,  # model.pt path(s)
        batch_size=32,  # batch size
        imgsz=640,  # inference size (pixels)
        conf_thres=0.001,  # confidence threshold
        iou_thres=0.45,  # NMS IoU threshold
        task='val',  # train, val, test, speed or study
        device='',  # cuda device, i.e. 0 or 0,1,2,3 or cpu
        single_cls=False,  # treat as single-class dataset
        augment=False,  # augmented inference
        verbose=True,  # verbose output
        save_txt=False,  # save results to *.txt
        save_hybrid=False,  # save label+prediction hybrid results to *.txt
        save_conf=False,  # save confidences in --save-txt labels
        save_json=False,  # save a COCO-JSON results file
        project='runs/val',  # save to project/name
        name='exp',  # save to project/name
        exist_ok=False,  # existing project/name ok, do not increment
        half=False,  # use FP16 half-precision inference
        model=None,
        dataloader=None,
        save_dir=Path(''),
        plots=True,
        callbacks=Callbacks(),
        compute_loss=None,
        save_nms = 0,
        workers=2,
        hist=None,
        hist_path = None,
        hyp=None,
        map_hv = False,
        polygon=False,
        opt=None,
        reg_max_ft=16,
        ):
    # Initialize/load model and set device
    training = model is not None
    if training:  # called by train.py
        device = next(model.parameters()).device  # get model device

    else:  # called directly
        device = select_device(device, batch_size=batch_size)

        # Directories
        if project!='' and project is not None:
            save_dir = increment_path(Path(project) / name, exist_ok=exist_ok)  # increment run
        else:
            weights_path = os.path.dirname(weights)
            train_path = os.path.dirname(weights_path) if os.path.basename(weights_path)=='weights' else weights_path
            assert os.path.isdir(train_path)
            save_dir = increment_path(Path(train_path) / 'val', exist_ok=exist_ok)
        (save_dir / 'labels' if save_txt else save_dir).mkdir(parents=True, exist_ok=True)  # make dir

        # Load model
        model = attempt_load(weights, map_location=device)  # load FP32 model
        gs = max(int(model.stride.max()), 32)  # grid size (max stride)
        imgsz = check_img_size(imgsz, s=gs)  # check image size

        # Multi-GPU disabled, incompatible with .half() https://github.com/ultralytics/yolov5/issues/99
        # if device.type != 'cpu' and torch.cuda.device_count() > 1:
        #     model = nn.DataParallel(model)

        # Data
        data = check_dataset(data)  # check

    # 判断模型类别    
    for mname in OUT_LAYER.keys():
        m = model.get_module_byname(mname)
        if m is not None:
            dfl_flag = mname in ['DetectDFL', 'DetectDFL_FT']
            break
    _process_batch = PROCESS_BATCH_DICT[mname]
    mname = OUT_LAYER[mname]

    # Half
    half &= device.type != 'cpu'  # half precision only supported on CUDA
    if half:
        model.half()

    # Configure
    model.eval()
    is_coco = type(data['val']) is str and data['val'].endswith('coco/val2017.txt')  # COCO dataset
    nc = 1 if single_cls else int(data['nc'])  # number of classes
    iouv = torch.linspace(0.5, 0.95, 10).to(device)  # iou vector for mAP@0.5:0.95
    niou = iouv.numel()

    # Dataloader
    if not training:
        if device.type != 'cpu':
            imgsz2 = [imgsz,imgsz] if isinstance(imgsz,int) else imgsz    
            model(torch.zeros(1, getattr(model, 'ch', 3), imgsz2[0], imgsz2[1]).to(device).type_as(next(model.parameters())))  # run once
        task = task if task in ('train', 'val', 'test') else 'val'  # path to train/val/test images
        from utils.loss import ComputeLoss
        compute_loss = ComputeLoss(model, ft_stat=1)
        compute_loss.assigner.topk = 5
        compute_loss.ft_loss.forward = compute_loss.ft_loss.forward_ft_statistics
        # Data
        data = check_dataset(data)  # check
        if hyp is not None:
            import yaml
            with open(hyp) as f:
                hyp = yaml.safe_load(f)  # load hyps dict
        val_count = data.get('val_count',0)
        
        ft_coef = (model.model[-1].ft_coef_length - 2) // 4

        dataloader = create_dataloader(data[task], imgsz2, batch_size, gs, single_cls, pad=0.5, rect=False,
                                       hyp=hyp,
                                       prefix=colorstr(f'{task}: '),
                                       save_dir=save_dir,
                                       workers=workers,
                                       sample_count=val_count,
                                       debug_samples=0,
                                       ft_coef = ft_coef,
                                    #    hist=hist
                                       )[0]
        data_path = os.path.dirname(data[task].rstrip('/\\'))
        
    seen = 0
    confusion_matrix = ConfusionMatrix(nc=nc)
    names = {k: v for k, v in enumerate(model.names if hasattr(model, 'names') else model.module.names)}
    s = ('%20s' + '%11s' * 8) % ('Class', 'Images', 'Labels', 'P', 'R', 'mAP@.5', 'mAP@.5:.95', 'f1', 'thresh')
    dt, p, r, f1, mp, mr, map50, map = [0.0, 0.0, 0.0], 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
    tags = getattr(compute_loss, 'tags', None)
    loss = torch.zeros(3 if tags is None else (len(tags) - 4), device=device)
    jdict, stats, ap, ap_class = [], [], [], []
    ft_stat_total = []
    for batch_i, (img, targets, paths, shapes) in enumerate(tqdm(dataloader, desc=s, ncols=max(shutil.get_terminal_size().columns - 40, 10), dynamic_ncols=False)):
        t_ = time_sync()
        img = img.to(device, non_blocking=True)
        img = img.half() if half else img.float()  # uint8 to fp16/32
        img /= 255.0  # 0 - 255 to 0.0 - 1.0
        targets = targets.to(device)
        # if(hist_path==None):
        #     targets = targets[targets[:,-1]>0] #targets[nobj,14=1(batch)+1(cls)+4(xywh) + 4(q)+3(abc)+1(D)]
        ##把targets_all中间的4(box)删掉了！变成了targets[nobj,10+cms+cms_mask]
        targets6 = targets[..., :6].clone().to(device)#targets6[gnt,6=1(b)+1(c)+4(xywh)]  targets6 means 2D information
        nb, _, height, width = img.shape  # batch size, channels, height, width
        t = time_sync()
        dt[0] += t - t_

        # Run model
        out, ft_out, train_out = model(img, augment=augment)  # inference and training outputs
        dt[1] += time_sync() - t

        # Compute loss
        if compute_loss:
            if dfl_flag:
                target_ft_stat = compute_loss(train_out, targets, img.shape[2:])[-1]  # loss scaled by batch_size
            else:
                assert 0, '错误: dfl_flag必须是True'
        ft_stat_total.append(target_ft_stat)

    a0c0_ft_coef_stat = torch.cat(ft_stat_total, 0)
    a0c0 = a0c0_ft_coef_stat[..., :2].T.cpu().numpy()
    ftcoef = a0c0_ft_coef_stat[..., 2:].reshape(a0c0_ft_coef_stat.shape[0], -1, 4).permute(1, 0, 2)
    ftcoef = ftcoef.reshape(ftcoef.shape[0], -1).cpu().numpy()
    stat_name = ['a0', 'c0'] + [f'ft_{i+1}' for i in range(ftcoef.shape[0])]
    distribut_name = os.path.join(data_path, 'distribution_plot.png')
    cgm = np.concatenate([np.std(data, axis=1) for data in [a0c0, ftcoef]], axis=0) #cgm[ft_coef]
    print(cgm.shape, '\n', 'CGM: ', cgm, '\n')
    with open(os.path.join(data_path, 'ft_stat_std.txt'), 'w') as fw:
        fw.write(', '.join([f'{c}' for c in cgm]))
        
    # quantile steps
    quantiles = np.linspace(0, 1, reg_max_ft)
    
    ft_stat_keys = []
    for data in (*a0c0, *ftcoef,):
        row = data
        ft_stat_keys.append(np.quantile(row, quantiles))
    with open(os.path.join(data_path, f'ft_stat_keys_{reg_max_ft}.txt'), 'w') as fw:
        for keys in ft_stat_keys:
            fw.write(', '.join([f'{c}' for c in keys]))
            fw.write('\n')
    ft_stat_keys = np.asarray(ft_stat_keys)
    print(ft_stat_keys.shape, '\n', 'ft_stat_keys:')
    for i, keys in enumerate(ft_stat_keys):
        print(f"{i}:", keys)


    for mode in ['std', 'hist']:
        print('\033[32mgenerating distribution_plot...\033[0m',end='')
        import matplotlib.pyplot as plt
        import seaborn as sns
        from general.MyString import add_suffix_to_filename
        from utils.KAL import compute_gauss_keys,compute_ft_keys,compute_gauss_keys_half

        # # 假设 all_labels_ft 是 [ft_coef, 4*nt] 的 numpy 数组
        # distribut_name 是保存路径
        colors = sns.color_palette("hsv", n_colors=2+ftcoef.shape[0])  # 每行一个颜色
        key_colors = sns.color_palette("coolwarm", n_colors=reg_max_ft)  # Colors for key points
        
        for i, (data, name) in tqdm(enumerate(zip((*a0c0, *ftcoef,), stat_name)), total=2+ftcoef.shape[0], 
            ncols=max(shutil.get_terminal_size().columns - 20, 10), dynamic_ncols=False):
            if mode == 'std':
                keys_ppf =  compute_gauss_keys(reg_max_ft,key_sym=0)#keys_ppf[rgmax=16]
                keys_ppf = keys_ppf.reshape(1, -1)#keys_ppf[rgmax]->keys_ppf[1,rgmax=16]
                ft_keys = cgm[i] * keys_ppf #cgm[4n,1]*keys_ppf[1,rgmax]->ft_keys[4n,rgmax]
                current_keys = ft_keys.copy()[0]
            elif mode == 'hist':
                current_keys = ft_stat_keys[i]
            if np.abs(data).sum()>1e-8:
                # 动态计算该行数据范围
                data_min = data.min()
                data_max = data.max()
                plt.figure(figsize=(12, 6))
                plt.grid(True, linestyle='--', linewidth=0.5, axis='y')
                # sns.kdeplot(data, clip=(data_min, data_max), bw_adjust=5.0, color=colors[i], label=f'Line {1+i}')  # ← 核心修改
                sns.histplot(data, bins=1000, stat='count', alpha=0.4, color=colors[i], label=f'Line {1+i}')
                plt.legend(fontsize='small', ncol=2)
                plt.xlabel(f'{name} in Fourier series')
                plt.ylabel("Density")
                # plt.tight_layout()


                for key_idx, key_val in enumerate(current_keys):
                    plt.axvline(x=key_val, color=key_colors[key_idx], 
                                linestyle='--', linewidth=0.5, 
                                label=f'Key {key_idx}')
                                # label=f'Key {key_idx}' if key_idx < 5 else None)
                    plt.legend(fontsize='small', ncol=2)

                # 设置x轴范围（覆盖所有数据）
                axis_scale = 0.4
                plt.xlim(data_min * axis_scale, data_max * axis_scale)
                plt.title(f"Histogram of Each Row in labels_ft {1+i}")

                # 保存图像
                distribut_name_ = add_suffix_to_filename(distribut_name, f'_{mode}_{name}')
                plt.savefig(distribut_name_, dpi=300)
                # print(f'\nSaved to {distribut_name_} ok.')
                plt.close()
        del sns

    print(save_dir)
    # from utils.KAL import compute_gauss_keys
    # keys_ppf = compute_gauss_keys(compute_loss.reg_max_ft, key_sym=0)#keys_ppf[rgmax=16]
    return cgm, ft_stat_keys


def parse_opt():
    parser = argparse.ArgumentParser(prog='val.py')
    parser.add_argument('--data', type=str, default='data/coco128.yaml', help='dataset.yaml path')
    parser.add_argument('--weights', nargs='+', type=str, default='yolov5s.pt', help='model.pt path(s)')
    parser.add_argument('--batch-size', type=int, default=16, help='batch size')
    parser.add_argument('--imgsz', '--img', '--img-size', type=list, default=640, help='inference size (pixels)')
    parser.add_argument('--conf-thres', type=float, default=0.001, help='confidence threshold')
    parser.add_argument('--iou-thres', type=float, default=0.6, help='NMS IoU threshold')
    parser.add_argument('--task', default='val', help='train, val, test, speed or study')
    parser.add_argument('--device', default='0', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')
    parser.add_argument('--single-cls', action='store_true', help='treat as single-class dataset')
    parser.add_argument('--augment', action='store_true', help='augmented inference')
    parser.add_argument('--verbose', action='store_true', help='report mAP by class')
    parser.add_argument('--save-txt', action='store_true', help='save results to *.txt')
    parser.add_argument('--save-hybrid', action='store_true', help='save label+prediction hybrid results to *.txt')
    parser.add_argument('--save-conf', action='store_true', help='save confidences in --save-txt labels')
    parser.add_argument('--save-json', action='store_true', help='save a COCO-JSON results file')
    parser.add_argument('--project', default='', help='save to project/name') #'runs/val_ft_stat'
    parser.add_argument('--name', default='exp', help='save to project/name')
    parser.add_argument('--exist-ok', action='store_true', help='existing project/name ok, do not increment')
    parser.add_argument('--half', action='store_true', help='use FP16 half-precision inference')
    parser.add_argument('--save_nms', type=int, default=0, help='save_nms')
    parser.add_argument('--hyp', type=str, default='hyps/hyp.scratch.yaml', help='hyperparameters path')
    parser.add_argument('--map_hv', action='store_true', help='use hv coefs to calc map')
    parser.add_argument('--polygon', action='store_true', help='use polygon to calc map')
    parser.add_argument('--reg_max_ft', type=int, default=16, help='reg_max_ft')

    opt = parser.parse_args()
    #general
    # opt.weights = 'runs/train/exp5/weights/last.pt' #'weights/yolov5s.pt'
    # if 0:
    #     opt.data = 'data/coco2017.yaml'
    #     opt.imgsz = [640, 640]
    # else:
    #     opt.data = 'data/road_dlsb417-total.yaml'
    #     opt.imgsz = [896,896]
    #coco128
    # opt.hyp = 'hyps/hyp.scratch-dfl.yaml'
    # opt.data = r'data/coco_ft.yaml'
    # opt.weights = r'weights/best.pt'
    # opt.imgsz = [640, 640]

    #coco
    # opt.hyp = 'hyps/hyp.scratch-dfl.yaml'
    # opt.data = r'data/coco_ft.yaml'
    # opt.weights = r'/home/user/workspace/yolov5/yolov5-dfl-ft/models-all/coco2017/v11m-ft-bs16-60.25-26.17-epo99-2-640x640/weights/best.pt'
    # opt.imgsz = [640, 640]
    # opt.polygon = False
    # opt.iou_thres = 0.45
    # opt.device = '1'
    # opt.task = 'train'

    #cityscapes
    opt.hyp = 'hyps/hyp.scratch-dfl.yaml'
    opt.data = r'data/cityscapes_ft.yaml'
    opt.weights = r'../models/cityscapes/cityscapes_ft-yolov11s-ft-bs16-50.22-20.09/weights/best_map50.pt'
    opt.imgsz = [640, 640]
    opt.reg_max_ft = 16
    opt.polygon = False
    opt.iou_thres = 0.45
    opt.device = '0'
    opt.task = 'train'

    # road_seg
    # opt.data = 'data/road_seg_ft.yaml'
    # opt.imgsz = [640, 896] #[640, 640]
    # opt.batch_size = 16
    # opt.weights = 'runs/train/exp37/weights/best.pt'

    opt.save_json |= opt.data.endswith('coco.yaml')
    opt.save_txt |= opt.save_hybrid
    opt.data = check_file(opt.data)  # check file
    return opt


def main(opt):
    set_logging()
    print(colorstr('val: ') + ', '.join(f'{k}={v}' for k, v in vars(opt).items()))

    run(**vars(opt))

if __name__ == "__main__":
    opt = parse_opt()
    main(opt)
