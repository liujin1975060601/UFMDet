import os
import cv2
import numpy as np
import random
from glob import glob
from tqdm import tqdm

# =========================
# 参数
# =========================

W = 640
H = 640
NUM_IMAGES = 20000
POINTS = 60

cache_size = 8
refresh_interval = 20

# =========================
# 曲线函数
# =========================

def parabola():
    x = np.linspace(-1,1,POINTS)
    y = x**2
    return x,y

def s_curve():
    x = np.linspace(-3,3,POINTS)
    y = np.tanh(x)
    x /= 3
    return x,y

def hyperbola():
    x = np.linspace(0.3,2,POINTS)
    y = 1/x
    x = (x-x.mean())/(x.max()-x.min())
    return x,y

def spiral():
    t = np.linspace(0,4*np.pi,POINTS)
    r = 0.1*t
    x = r*np.cos(t)
    y = r*np.sin(t)
    return x,y

curve_funcs=[parabola,s_curve,hyperbola,spiral]

# =========================
# 曲线随机变换
# =========================

def random_curve_transform(x,y):

    pts=np.stack([x,y],axis=1)

    pts-=pts.mean(axis=0)

    scale=random.uniform(0.2,0.6)
    pts*=scale

    theta=random.uniform(0,2*np.pi)

    R=np.array([
        [np.cos(theta),-np.sin(theta)],
        [np.sin(theta),np.cos(theta)]
    ])

    pts=pts@R.T

    tx=random.uniform(0.1,0.9)
    ty=random.uniform(0.1,0.9)

    pts[:,0]+=tx
    pts[:,1]+=ty

    return pts

def center_inside(pts):

    cx=pts[:,0].mean()
    cy=pts[:,1].mean()

    return 0<=cx<=1 and 0<=cy<=1

# =========================
# 背景cache
# =========================
def load_background_cache(background_dir):
    if not os.path.exists(background_dir):
        return [], []

    paths = []
    paths += glob(os.path.join(background_dir, "*.jpg"))
    paths += glob(os.path.join(background_dir, "*.png"))

    if len(paths) == 0:
        return [], []

    cache = []
    for _ in range(min(cache_size,len(paths))):
        p = random.choice(paths)
        img = cv2.imread(p)
        if img is not None:
            cache.append(img)
    return cache, paths

def refresh_cache(cache,paths):

    if len(cache)==0:
        return cache

    idx=random.randint(0,len(cache)-1)

    new_img=cv2.imread(random.choice(paths))

    if new_img is not None:
        cache[idx]=new_img

    return cache

# =========================
# 随机裁剪背景
# =========================
def random_crop_from_cache(cache):

    if len(cache) == 0:
        return np.zeros((H, W, 3), dtype=np.uint8)

    img = random.choice(cache)

    h, w = img.shape[:2]

    # 随机中心点
    cx = random.uniform(0, w)
    cy = random.uniform(0, h)

    # 随机旋转角度
    angle = random.uniform(0, 360)

    # 旋转矩阵（以中心点为旋转中心）
    M = cv2.getRotationMatrix2D((cx, cy), angle, 1.0)

    # 调整平移，使中心映射到输出图中心
    M[0,2] += W/2 - cx
    M[1,2] += H/2 - cy

    patch = cv2.warpAffine(
        img,
        M,
        (W, H),
        flags=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_REFLECT_101
    )

    return patch

if __name__ == '__main__':
    # =========================
    # 初始化背景
    # =========================
    background_dir = "/media/liu/088d8f6e-fca3-4aed-871f-243ad962413b/datas/dota1.5/images"  # 大图目录
    cache,paths=([],[])
    if os.path.exists(background_dir):
        cache,paths=load_background_cache(background_dir)
    
    dataset_root = '' #"/media/liu/088d8f6e-fca3-4aed-871f-243ad962413b/datas/dota1.5"
    if not os.path.exists(dataset_root):
        dataset_root = os.path.join(os.path.dirname(background_dir),'curves')

    img_dir = os.path.join(dataset_root,"images")
    lab_dir = os.path.join(dataset_root,"labels")

    os.makedirs(img_dir,exist_ok=True)
    os.makedirs(lab_dir,exist_ok=True)

    # =========================
    # 生成数据
    # =========================
    # for i in range(NUM_IMAGES):
    for i in tqdm(range(NUM_IMAGES), desc="Generating images"):
        if (i+1)%refresh_interval==0 and len(paths)>0:
            cache=refresh_cache(cache,paths)

        img=random_crop_from_cache(cache)

        label_lines=[]

        num_obj=random.randint(1,4)

        for _ in range(num_obj):

            for _ in range(50):

                cls=random.randint(0,len(curve_funcs)-1)

                x,y=curve_funcs[cls]()

                pts=random_curve_transform(x,y)

                if center_inside(pts):
                    break

            x=pts[:,0]
            y=pts[:,1]

            # x=np.clip(x,0,1)
            # y=np.clip(y,0,1)

            row=[str(cls)]

            for px,py in zip(x,y):
                row.append(f"{px:.6f}")
                row.append(f"{py:.6f}")

            label_lines.append(" ".join(row))

            # 绘制曲线
            pts_pixel=np.stack([x*W,y*H],axis=1).astype(np.int32)

            color=(
                random.randint(0,255),
                random.randint(0,255),
                random.randint(0,255)
            )

            thick=random.randint(1,4)

            for k in range(len(pts_pixel)-1):

                cv2.line(img,
                        tuple(pts_pixel[k]),
                        tuple(pts_pixel[k+1]),
                        color,
                        thick)

        img_name=f"{i:06d}.jpg"
        lab_name=f"{i:06d}.pol"

        cv2.imwrite(os.path.join(img_dir,img_name),img)

        with open(os.path.join(lab_dir,lab_name),"w") as f:
            f.write("\n".join(label_lines))
    
    # 假设你的 dataset_root, curve_funcs 已经定义
    curve_names = ["parabola","s_curve","hyperbola","spiral"]

    # 生成 names.txt
    names_path = os.path.join(dataset_root, "names.txt")
    with open(names_path,"w") as f:
        for name in curve_names:
            f.write(name+"\n")

    print(f"names.txt created at {names_path}")

    print("dataset generated")