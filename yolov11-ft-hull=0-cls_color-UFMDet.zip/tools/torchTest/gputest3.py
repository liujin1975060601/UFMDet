import torch
import sys

if __name__ == "__main__":
    print("="*60)
    print("快速CUDA兼容性测试")
    print("="*60)

    # 1. 基本信息
    print(f"PyTorch版本: {torch.__version__}")
    print(f"CUDA可用: {torch.cuda.is_available()}")

    if torch.cuda.is_available():
        print(f"GPU: {torch.cuda.get_device_name(0)}")
        print(f"算力: {torch.cuda.get_device_capability(0)}")
        
        # 2. 检查支持的架构
        if hasattr(torch.cuda, 'get_arch_list'):
            arch_list = torch.cuda.get_arch_list()
            print(f"支持的架构: {arch_list}")
            
            # 检查是否包含sm_120
            has_sm_120 = any('sm_120' in str(arch) or '12.0' in str(arch) for arch in arch_list)
            print(f"支持sm_120: {has_sm_120}")
        
        # 3. 最简单的CUDA操作测试
        print("\n测试最简单的CUDA操作...")
        try:
            x = torch.tensor([1.0, 2.0, 3.0])
            print(f"CPU张量: {x}")
            
            # 尝试移动到GPU
            x_gpu = x.cuda()
            print(f"GPU张量: {x_gpu}")
            print(f"设备: {x_gpu.device}")
            
            # 简单运算
            y = x_gpu * 2.0
            print(f"运算结果: {y}")
            
            print("✅ 最简单CUDA操作成功")
            
        except RuntimeError as e:
            print(f"❌ CUDA操作失败: {e}")
            print("\n详细错误信息:")
            import traceback
            traceback.print_exc()
            
    else:
        print("❌ CUDA不可用")

    print("="*60)