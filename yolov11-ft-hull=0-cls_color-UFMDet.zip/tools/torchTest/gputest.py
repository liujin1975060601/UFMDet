# check_gpu.py
import torch

if __name__ == "__main__":
    if torch.cuda.is_available():
        device_count = torch.cuda.device_count()
        print(f"发现 {device_count} 个GPU设备:")
        
        for i in range(device_count):
            print(f"\nGPU {i}:")
            print(f"  名称: {torch.cuda.get_device_name(i)}")
            print(f"  算力: {torch.cuda.get_device_capability(i)}")
            print(f"  内存: {torch.cuda.get_device_properties(i).total_memory / 1024**3:.2f} GB")
    else:
        print("CUDA不可用，将使用CPU")
        print("Python版本:", torch.__version__)
        print("CUDA编译版本:", torch.version.cuda)