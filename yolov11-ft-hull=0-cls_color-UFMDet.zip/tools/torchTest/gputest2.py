#!/usr/bin/env python3
# test_cuda_5090.py - 测试RTX 5090 CUDA兼容性

import torch
import sys
import traceback

def print_system_info():
    """打印系统信息"""
    print("=" * 70)
    print("RTX 5090 D v2 CUDA兼容性测试")
    print("=" * 70)
    
    # 打印Python和PyTorch信息
    print(f"Python版本: {sys.version}")
    print(f"PyTorch版本: {torch.__version__}")
    print(f"PyTorch CUDA编译版本: {torch.version.cuda if hasattr(torch.version, 'cuda') else 'N/A'}")
    
    # 检查CUDA可用性
    cuda_available = torch.cuda.is_available()
    print(f"CUDA可用: {cuda_available}")
    
    if cuda_available:
        print(f"CUDA设备数量: {torch.cuda.device_count()}")
        
        for i in range(torch.cuda.device_count()):
            print(f"\nGPU {i} 信息:")
            print(f"  名称: {torch.cuda.get_device_name(i)}")
            print(f"  算力: {torch.cuda.get_device_capability(i)}")
            print(f"  内存: {torch.cuda.get_device_properties(i).total_memory / 1024**3:.2f} GB")
            
            # 检查支持的架构
            if hasattr(torch.cuda, 'get_arch_list'):
                print(f"  支持的架构: {torch.cuda.get_arch_list()}")
    else:
        print("警告: CUDA不可用！")
    
    print("-" * 70)
    return cuda_available

def test_basic_cuda_operations():
    """测试基本CUDA操作"""
    print("测试1: 基本CUDA操作")
    
    try:
        # 创建GPU张量
        print("创建GPU张量...")
        x = torch.randn(100, 100).cuda()
        y = torch.randn(100, 100).cuda()
        
        print(f"张量x设备: {x.device}")
        print(f"张量y设备: {y.device}")
        
        # 测试矩阵乘法
        print("测试矩阵乘法...")
        z = torch.matmul(x, y)
        print(f"矩阵乘法结果形状: {z.shape}")
        
        # 测试元素级操作
        print("测试元素级操作...")
        w = x + y * 2.0
        print(f"元素级操作结果形状: {w.shape}")
        
        # 测试归约操作
        print("测试归约操作...")
        sum_x = x.sum()
        mean_y = y.mean()
        print(f"x的和: {sum_x.item():.4f}, y的均值: {mean_y.item():.4f}")
        
        print("✅ 基本CUDA操作测试通过")
        return True
        
    except Exception as e:
        print(f"❌ 基本CUDA操作测试失败: {e}")
        traceback.print_exc()
        return False

def test_yolo_style_operations():
    """测试YOLO风格的CUDA操作"""
    print("\n测试2: YOLO风格操作")
    
    try:
        # 测试卷积操作 (YOLO常用)
        print("测试卷积操作...")
        conv = torch.nn.Conv2d(3, 16, kernel_size=3, stride=1, padding=1).cuda()
        input_tensor = torch.randn(1, 3, 64, 64).cuda()  # batch=1, channels=3, height=64, width=64
        
        with torch.no_grad():
            output = conv(input_tensor)
        
        print(f"卷积输入形状: {input_tensor.shape}")
        print(f"卷积输出形状: {output.shape}")
        
        # 测试批量归一化 (YOLO常用)
        print("测试批量归一化...")
        bn = torch.nn.BatchNorm2d(16).cuda()
        bn_output = bn(output)
        print(f"批量归一化输出形状: {bn_output.shape}")
        
        # 测试ReLU激活函数
        print("测试激活函数...")
        relu = torch.nn.ReLU().cuda()
        relu_output = relu(bn_output)
        print(f"ReLU输出形状: {relu_output.shape}")
        
        # 测试池化
        print("测试池化操作...")
        pool = torch.nn.MaxPool2d(kernel_size=2, stride=2).cuda()
        pool_output = pool(relu_output)
        print(f"池化输出形状: {pool_output.shape}")
        
        print("✅ YOLO风格操作测试通过")
        return True
        
    except Exception as e:
        print(f"❌ YOLO风格操作测试失败: {e}")
        traceback.print_exc()
        return False

def test_mixed_precision():
    """测试混合精度训练（现代GPU常用）"""
    print("\n测试3: 混合精度训练")
    
    try:
        # 创建半精度张量
        print("测试半精度张量...")
        x_half = torch.randn(100, 100, dtype=torch.float16).cuda()
        y_half = torch.randn(100, 100, dtype=torch.float16).cuda()
        
        # 混合精度矩阵乘法
        z_half = torch.matmul(x_half, y_half)
        print(f"半精度矩阵乘法结果形状: {z_half.shape}")
        print(f"半精度张量类型: {z_half.dtype}")
        
        # 与单精度比较
        x_float = x_half.float()
        y_float = y_half.float()
        z_float = torch.matmul(x_float, y_float)
        
        # 计算误差
        error = torch.abs(z_half.float() - z_float).max().item()
        print(f"半精度与单精度最大误差: {error:.6f}")
        
        print("✅ 混合精度测试通过")
        return True
        
    except Exception as e:
        print(f"❌ 混合精度测试失败: {e}")
        traceback.print_exc()
        return False

def test_large_tensor():
    """测试大张量操作"""
    print("\n测试4: 大张量操作")
    
    try:
        # 创建大张量，接近GPU内存限制
        print("创建大张量...")
        free_memory = torch.cuda.get_device_properties(0).total_memory - torch.cuda.memory_allocated(0)
        print(f"可用GPU内存: {free_memory / 1024**3:.2f} GB")
        
        # 根据可用内存计算张量大小
        if free_memory > 2 * 1024**3:  # 大于2GB
            size = int((free_memory * 0.3) ** 0.5)  # 使用30%内存
            size = min(size, 10000)  # 限制最大尺寸
            
            print(f"创建 {size}x{size} 的矩阵...")
            x_large = torch.randn(size, size).cuda()
            y_large = torch.randn(size, size).cuda()
            
            # 矩阵乘法
            print("执行大矩阵乘法...")
            torch.cuda.synchronize()
            z_large = torch.matmul(x_large, y_large)
            torch.cuda.synchronize()
            
            print(f"大矩阵乘法完成，结果形状: {z_large.shape}")
            print(f"大矩阵元素总数: {z_large.numel():,}")
            
        else:
            print("可用内存不足，跳过大规模测试")
            
        print("✅ 大张量操作测试通过")
        return True
        
    except Exception as e:
        print(f"❌ 大张量操作测试失败: {e}")
        traceback.print_exc()
        return False

def main():
    """主测试函数"""
    try:
        # 1. 打印系统信息
        cuda_available = print_system_info()
        
        if not cuda_available:
            print("❌ CUDA不可用，无法进行GPU测试")
            print("请检查:")
            print("1. NVIDIA驱动是否正确安装")
            print("2. CUDA工具包是否正确安装")
            print("3. PyTorch是否正确安装")
            return False
        
        print("开始CUDA测试...")
        
        # 2. 设置设备
        device = torch.device('cuda:0')
        
        # 3. 运行各项测试
        tests_passed = 0
        tests_total = 4
        
        # 测试1: 基本操作
        if test_basic_cuda_operations():
            tests_passed += 1
        
        # 测试2: YOLO风格操作
        if test_yolo_style_operations():
            tests_passed += 1
        
        # 测试3: 混合精度
        if test_mixed_precision():
            tests_passed += 1
        
        # 测试4: 大张量操作
        if test_large_tensor():
            tests_passed += 1
        
        # 4. 打印测试结果
        print("\n" + "=" * 70)
        print("测试结果汇总")
        print("=" * 70)
        print(f"测试通过: {tests_passed}/{tests_total}")
        
        if tests_passed == tests_total:
            print("🎉 所有CUDA测试通过！RTX 5090可以正常使用。")
            print("你的YOLO代码问题可能在其他地方。")
        elif tests_passed > 0:
            print("⚠ 部分测试通过，CUDA基本可用。")
            print("可能是PyTorch版本不完全支持RTX 5090的某些操作。")
        else:
            print("❌ 所有CUDA测试失败！")
            print("问题在于PyTorch不支持RTX 5090的sm_120架构。")
        
        # 5. 建议
        print("\n建议:")
        if tests_passed == 0:
            print("1. 等待PyTorch正式版支持RTX 5090")
            print("2. 使用CPU模式运行代码: python train.py --device cpu")
            print("3. 从源码编译支持sm_120的PyTorch")
        elif tests_passed < tests_total:
            print("1. YOLO可能使用了不支持的CUDA操作")
            print("2. 尝试修改YOLO代码避免某些CUDA操作")
            print("3. 使用--device cpu参数运行部分代码")
        
        print("=" * 70)
        
        return tests_passed == tests_total
        
    except Exception as e:
        print(f"测试过程发生异常: {e}")
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)