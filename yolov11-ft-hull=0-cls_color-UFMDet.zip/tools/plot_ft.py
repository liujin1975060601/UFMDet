import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import hsv_to_rgb
import torch
import cv2
import os
from utils.ft_utils import ffts_1,ft_correct_clockwise,fft_area

def plot_abcd(vis_path,name, pred_ft, labels_ft, i, flag):
    nf = (pred_ft.shape[-1] - 2) // 4
    assert nf == (labels_ft.shape[-1] - 2) // 4
    
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))  # 调整为一行两列布局
    
    for j, (label, linestyle_pred, linestyle_gt) in enumerate(zip(['a', 'b'], ['-', '--'], ['-', '--'])):
        if flag & 0x01:
            y_pred_a = pred_ft[2 + 0 :: 4].cpu().numpy()  # a 分量
            y_pred_b = pred_ft[2 + 1 :: 4].cpu().numpy()  # b 分量
            axes[0].plot(range(nf), y_pred_a if j == 0 else y_pred_b, 
                         c='green', linestyle=linestyle_pred, label=f'pred {label}')
        
        if flag & 0x10:
            y_gt_a = labels_ft[2 + 0 :: 4].cpu().numpy()
            y_gt_b = labels_ft[2 + 1 :: 4].cpu().numpy()
            axes[0].plot(range(nf), y_gt_a if j == 0 else y_gt_b, 
                         '--' if j == 1 else '-', c='red', label=f'gt {label}')

    for j, (label, linestyle_pred, linestyle_gt) in enumerate(zip(['c', 'd'], ['-', '--'], ['-', '--']), start=2):
        if flag & 0x01:
            y_pred_c = pred_ft[2 + 2 :: 4].cpu().numpy()  # c 分量
            y_pred_d = pred_ft[2 + 3 :: 4].cpu().numpy()  # d 分量
            axes[1].plot(range(nf), y_pred_c if j == 2 else y_pred_d, 
                         c='green', linestyle=linestyle_pred, label=f'pred {label}')
        
        if flag & 0x10:
            y_gt_c = labels_ft[2 + 2 :: 4].cpu().numpy()
            y_gt_d = labels_ft[2 + 3 :: 4].cpu().numpy()
            axes[1].plot(range(nf), y_gt_c if j == 2 else y_gt_d, 
                         '--' if j == 3 else '-', c='red', label=f'gt {label}')
    
    axes[0].set_title('a and b values')
    axes[0].legend(loc='upper right')
    
    axes[1].set_title('c and d values')
    axes[1].legend(loc='upper right')
    
    plt.tight_layout()
    plt.savefig(os.path.join(vis_path,f'ft_{name}_{i}_abcd.png'))
    plt.close()

def plot_abcd_m(vis_path, name, pred_ft, labels_ft, i, flag):
    nf = (pred_ft.shape[-1] - 2) // 4
    assert nf == (labels_ft.shape[-1] - 2) // 4

    fig, ax = plt.subplots(figsize=(10, 6))
    x_vals = range(nf)

    if flag & 0x01:
        data_p = pred_ft[2:].cpu().numpy()  # shape: (4*nf,)
        a_p = data_p[0::4]
        b_p = data_p[1::4]
        c_p = data_p[2::4]
        d_p = data_p[3::4]

        # 注意：这里画的是原始系数，不是幅度！
        # 如果您仍想画幅度，请用 sqrt(a^2 + b^2)，但那样只有两个曲线。
        # 但根据您“a用实线、b用虚线”的要求，应该是画原始系数。
        ax.plot(x_vals, a_p, color='green', linestyle='-', label='pred a')
        ax.plot(x_vals, b_p, color='green', linestyle='--', label='pred b')
        ax.plot(x_vals, c_p, color='green', linestyle='-', label='pred c')
        ax.plot(x_vals, d_p, color='green', linestyle='--', label='pred d')

    if flag & 0x10:
        data_g = labels_ft[2:].cpu().numpy()
        a_g = data_g[0::4]
        b_g = data_g[1::4]
        c_g = data_g[2::4]
        d_g = data_g[3::4]

        ax.plot(x_vals, a_g, color='red', linestyle='-', label='gt a')
        ax.plot(x_vals, b_g, color='red', linestyle='--', label='gt b')
        ax.plot(x_vals, c_g, color='red', linestyle='-', label='gt c')
        ax.plot(x_vals, d_g, color='red', linestyle='--', label='gt d')

    ax.set_title('Fourier Coefficients a, b, c, d')
    ax.set_xlabel('Fourier order k')
    ax.set_ylabel('Coefficient value')
    ax.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(vis_path, f'ft_{name}_{i}_abcd_m.png'))
    plt.close()


def plot_xy(vis_path,name, pred_ft, labels_ft, i, flag):
    nf = (pred_ft.shape[-1] - 2) // 4
    assert nf == (labels_ft.shape[-1] - 2) // 4
    N = 2 * nf  # 时域点数

    fig, ax = plt.subplots(figsize=(10, 6))

    # Handle prediction
    if flag & 0x01:
        coeffs_p = pred_ft.cpu().numpy()
        xf_p, yf_p = ffts_1(coeffs_p[None, :], N)
        xf_p = xf_p.squeeze()
        yf_p = yf_p.squeeze()
        ax.plot(xf_p, color='green', linestyle='-', label='pred x')
        ax.plot(yf_p, color='green', linestyle='--', label='pred y')
    else:
        xf_p=yf_p=None

    # Handle ground truth
    if flag & 0x10:
        coeffs_g = labels_ft.cpu().numpy()
        xf_g, yf_g = ffts_1(coeffs_g[None, :], N)
        xf_g = xf_g.squeeze()
        yf_g = yf_g.squeeze()
        ax.plot(xf_g, color='red', linestyle='-', label='gt x')
        ax.plot(yf_g, color='red', linestyle='--', label='gt y')
    else:
        xf_g=yf_g=None

    ax.set_title('Reconstructed Signal (Time Domain)')
    ax.set_xlabel('Sample Index')
    ax.set_ylabel('Coordinate Value')
    ax.legend()
    plt.savefig(os.path.join(vis_path,f'ft_{name}_{i}_xy.png'))
    plt.close()

    return xf_p,yf_p,xf_g,yf_g

from tools.plotbox import plot_one_box_with_ft
def crop_image_by_contour(im0, xf_p,yf_p, xf_g, yf_g, margin=0):
    # 根据轮廓点 (xf_g, yf_g) 计算 bounding box，并裁剪图像 im0。
    # Args:
    #     im0 (np.ndarray): 原始图像，shape [H, W, 3]
    #     xf_g (np.ndarray): x 坐标，shape [N,]，值应在 [0, W)
    #     yf_g (np.ndarray): y 坐标，shape [N,]，值应在 [0, H)
    #     margin (int): 在 bounding box 外额外扩展的像素（可选）
    # Returns:
    #     cropped_img (np.ndarray): 裁剪后的图像
    #     bbox (tuple): (x_min, y_min, x_max, y_max)
    H, W = im0.shape[:2]

    im_copy = im0.copy()

    #draw gt poly
    if len(xf_g) > 0:
        x_coords = np.asarray(xf_g).flatten()
        y_coords = np.asarray(yf_g).flatten()
        contour_approx = np.array(list(zip(x_coords, y_coords)), dtype=np.int32).reshape((-1, 1, 2))
        cv2.polylines(im_copy, [contour_approx], isClosed=True, color=(255,0,0), thickness=2)
        cv2.circle(im_copy, (int(x_coords[0]), int(y_coords[0])), radius=5, color=(255, 0, 0), thickness=-1)
    #draw pred poly
    if len(xf_p) > 0:
        xp_coords = np.asarray(xf_p).flatten()
        yp_coords = np.asarray(yf_p).flatten()
        contour_approx = np.array(list(zip(xp_coords, yp_coords)), dtype=np.int32).reshape((-1, 1, 2))
        cv2.polylines(im_copy, [contour_approx], isClosed=True, color=(0,255,0), thickness=2)
        cv2.circle(im_copy, (int(xp_coords[0]), int(yp_coords[0])), radius=5, color=(0, 255, 0), thickness=-1)

    ##############################################

    # 过滤掉 NaN 或 Inf（安全起见）
    valid = np.isfinite(x_coords) & np.isfinite(y_coords)
    if not np.any(valid):
        raise ValueError("All contour points are invalid (NaN/Inf).")

    x_coords = x_coords[valid]
    y_coords = y_coords[valid]

    # 计算边界（注意：x 对应 width，y 对应 height）
    x_min = np.floor(np.min(x_coords)).astype(int)
    x_max = np.ceil(np.max(x_coords)).astype(int)
    y_min = np.floor(np.min(y_coords)).astype(int)
    y_max = np.ceil(np.max(y_coords)).astype(int)

    # 添加 margin（可选）
    x_min = max(0, x_min - margin)
    y_min = max(0, y_min - margin)
    x_max = min(W, x_max + margin)
    y_max = min(H, y_max + margin)

    # 确保 bbox 有效
    if x_min >= x_max or y_min >= y_max:
        # fallback: return small patch around center
        cx = (x_min + x_max) // 2
        cy = (y_min + y_max) // 2
        x_min = max(0, cx - 10)
        y_min = max(0, cy - 10)
        x_max = min(W, cx + 10)
        y_max = min(H, cy + 10)

    cropped = im_copy[y_min:y_max, x_min:x_max]

    bbox = (x_min, y_min, x_max, y_max)

    return cropped, bbox

from utils.ft_utils import ft_rot_normlize,fft_areas,reverse_ffts
from utils.ft_epicycle import draw_epicycle_circles,generate_epicycle_video
from utils.loss import loop_loss
def generate_plots(im0, vis_path, name, matches, pred_ft, labels_ft, min_area=30*30, flag=0x11, margin=25, normlize=1): #pred_ft[np,2+nf*4] labels_ft[nt,2+nf*4]
    # ft_correct_clockwise(pred_ft)
    # name = os.path.splitext(os.path.basename(fname))[0]
    nf = (pred_ft.shape[-1]-2)//4
    # area_pred = fft_areas(pred_ft.cpu().numpy())
    # pred_ft = pred_ft.clone()
    # reverse_ffts(pred_ft[area_pred<0])
    if normlize==2:
        pred_ft = ft_rot_normlize(pred_ft)[0]
        labels_ft = ft_rot_normlize(labels_ft)[0]
    m = matches.shape[0]
    for i in range(m):
        idx_gt = int(matches[i, 0].cpu().item())
        idx_pred = int(matches[i, 1].cpu().item())
        pred_ft1 = pred_ft[idx_pred].clone()
        gt1 = labels_ft[idx_gt].clone()
        area_gt = fft_area(gt1.cpu().numpy())
        if area_gt<0:
            gt1[3::2] *= -1
            area_gt = -area_gt
        assert fft_area(gt1.cpu().numpy())>=0
        if area_gt>=min_area:
            area_pred1 = fft_area(pred_ft1.cpu().numpy())
            if area_pred1<0:
                pred_ft1[3::2] *= -1
                area_pred1 = -area_pred1
            assert fft_area(pred_ft1.cpu().numpy()) >= 0
            if normlize==1:
                gt1[2:] = loop_loss(64, gt1[None, 2:], pred_ft1[None, 2:].detach())[0]
            plot_abcd(vis_path,name, pred_ft1, gt1, i, flag)
            plot_abcd_m(vis_path,name, pred_ft1, gt1, i, flag)
            xf_p,yf_p,xf_g,yf_g = plot_xy(vis_path,name, pred_ft1, gt1, i, flag) #xf_p[2nf],yf_p[2nf] xf_g[2nf],yf_g[2nf]
            # tbox1 = tbox[idx_gt]

            # if not os.path.exists(os.path.join(vis_path,f'ft_{name}.png')):
            #     cv2.imwrite(os.path.join(vis_path,f'ft_{name}.png'), im0)
            
            if 0:
                cropped, bbox = crop_image_by_contour(im0,xf_p,yf_p,xf_g,yf_g, margin=margin) #cropped[h,w,3]
                cropped_bgr = cv2.cvtColor(cropped, cv2.COLOR_RGB2BGR)
                # 保存
                cv2.imwrite(os.path.join(vis_path,f'ft_{name}_{i}_crop.png'), cropped_bgr)
            #
            im02 = im0.copy()
            ft_scale = plot_ft_crop_scale(im02,gt1,pred_ft1)
            crop_pvg,pred_ft1_scale,A23 = ft_scale[0],ft_scale[-2],ft_scale[-1]
            # 保存
            cv2.imwrite(os.path.join(vis_path,f'ft_{name}_{i}_pvg.png'), crop_pvg)
            #
            #epicycle
            im_epicycle = cv2.warpAffine(im02, A23.cpu().numpy(), (crop_pvg.shape[1],crop_pvg.shape[0]))
            draw_ft_poly(im_epicycle,pred_ft1_scale, N=256, color=(0,255,0), draw_cen=1)
            
            generate_epicycle_video(im_epicycle, pred_ft1_scale,os.path.join(vis_path,f'ft_{name}_{i}_epicycle.mp4'))
            
            draw_epicycle_circles(im_epicycle,pred_ft1_scale.cpu().numpy(),t=torch.pi/4,thickness=1)
            cv2.imwrite(os.path.join(vis_path,f'ft_{name}_{i}_epicycle.png'), im_epicycle)
            #
            plot_3d_fourier_waveforms(pred_ft1.cpu().numpy(),(30, 45), save_path=os.path.join(vis_path,f'ft_{name}_{i}_3d.png'))

def plot_3d_fourier_waveforms(pred, view_angle=(30, 45), save_path=None, dpi=150):
    # Plot 3D Fourier waveform spectrum with independent curves per frequency.
    # Parameters:
    #     pred: Fourier coefficients array [a0, c0, a1, b1, c1, d1, a2, b2, c2, d2, ...]
    #     view_angle: (elev, azim) for 3D view
    #     save_path: path to save figure; auto-generate if None
    #     dpi: resolution
    # Returns:
    #     save_path, (X_wave, Y_wave, Z_mag)
    nf = (pred.shape[-1] - 2) // 4

    pred[0]=pred[1] = 0
    
    # Extract coefficients
    a0 = pred[0]
    c0 = pred[1]
    coeffs = pred[2:]
    
    frequencies = np.arange(nf)  # 0, 1, ..., nf-1
    t = np.linspace(0, 4 * np.pi, 400)

    # Precompute waveforms per frequency
    X_wave = np.zeros((nf, len(t)))
    Y_wave = np.zeros((nf, len(t)))
    Z_mag = np.zeros((nf, len(t)))

    for i in range(nf):
        if i == 0:
            # DC component (f=0)
            X_wave[i, :] = a0
            Y_wave[i, :] = c0
            Z_mag[i, :] = np.sqrt(a0**2 + c0**2)
        else:
            idx = (i - 1) * 4
            if idx + 3 < len(coeffs):
                ai = coeffs[idx]
                bi = coeffs[idx + 1]
                ci = coeffs[idx + 2]
                di = coeffs[idx + 3]

                freq = i  # actual harmonic number
                X_wave[i, :] = ai * np.cos(freq * t) + bi * np.sin(freq * t)
                Y_wave[i, :] = ci * np.cos(freq * t) + di * np.sin(freq * t)
                Z_mag[i, :] = np.sqrt(X_wave[i, :]**2 + Y_wave[i, :]**2)

    # Create figure
    fig = plt.figure(figsize=(16, 12))

    # Helper to plot multiple curves in 3D
    def plot_curves_3d(ax, T, F_vals, Z_data, title, zlabel, cmap='tab10'):
        ax.set_xlabel('Time t', fontsize=11, labelpad=8)
        ax.set_ylabel('Frequency f', fontsize=11, labelpad=8)
        ax.set_zlabel(zlabel, fontsize=11, labelpad=8)
        ax.set_title(title, fontsize=12, pad=15)
        ax.view_init(elev=view_angle[0], azim=view_angle[1])
        
        cmap_obj = plt.get_cmap(cmap)
        for i, f in enumerate(F_vals):
            color = cmap_obj(i / max(1, len(F_vals)-1))
            ax.plot(t, np.full_like(t, f), Z_data[i, :], color=color, linewidth=1.8, label=f'f={f}')
        # Optional: add legend only if not too many frequencies
        if nf <= 6:
            ax.legend(loc='upper right', fontsize=8)

    # 1. 3D X-Component (independent curves)
    ax1 = fig.add_subplot(231, projection='3d')
    plot_curves_3d(ax1, t, frequencies, X_wave, '3D X-Component Waveforms', 'X-Component')

    # 2. 3D Y-Component
    ax2 = fig.add_subplot(232, projection='3d')
    plot_curves_3d(ax2, t, frequencies, Y_wave, '3D Y-Component Waveforms', 'Y-Component')

    # 3. 3D Magnitude
    ax3 = fig.add_subplot(233, projection='3d')
    plot_curves_3d(ax3, t, frequencies, Z_mag, '3D Magnitude Spectrum', 'Magnitude', cmap='viridis')

    # Keep the bottom three 2D plots unchanged
    ax4 = fig.add_subplot(234)
    for i in range(nf):
        ax4.plot(t, X_wave[i, :], label=f'f={i}', linewidth=2 if i > 0 else 3)
    ax4.set_xlabel('Time t', fontsize=11)
    ax4.set_ylabel('X-Component Value', fontsize=11)
    ax4.set_title('X-Component Waveforms', fontsize=12)
    ax4.grid(True, alpha=0.3)
    if nf <= 6:
        ax4.legend(loc='upper right', fontsize=9)

    ax5 = fig.add_subplot(235)
    for i in range(nf):
        ax5.plot(t, Y_wave[i, :], label=f'f={i}', linewidth=2 if i > 0 else 3)
    ax5.set_xlabel('Time t', fontsize=11)
    ax5.set_ylabel('Y-Component Value', fontsize=11)
    ax5.set_title('Y-Component Waveforms', fontsize=12)
    ax5.grid(True, alpha=0.3)
    if nf <= 6:
        ax5.legend(loc='upper right', fontsize=9)

    ax6 = fig.add_subplot(236)
    avg_magnitude = np.mean(Z_mag, axis=1)
    bars = ax6.bar(frequencies, avg_magnitude)
    for i, bar in enumerate(bars):
        bar.set_color(plt.cm.viridis(i / max(1, nf - 1)))
    ax6.set_xlabel('Frequency f', fontsize=11)
    ax6.set_ylabel('Average Magnitude', fontsize=11)
    ax6.set_title('Frequency vs Average Magnitude', fontsize=12)
    ax6.grid(True, alpha=0.3)

    plt.tight_layout()
    fig.suptitle(f'Fourier Spectrum Analysis (nf={nf}, view={view_angle})', fontsize=14, y=1.02)

    # Save
    if save_path is None:
        timestamp = np.datetime64('now').astype('datetime64[s]').astype(str).replace(':', '-')
        save_path = f'fourier_3d_waveforms_nf{nf}_view{view_angle[0]}_{view_angle[1]}_{timestamp}.png'

    os.makedirs(os.path.dirname(save_path) if os.path.dirname(save_path) else '.', exist_ok=True)
    plt.savefig(save_path, dpi=dpi, bbox_inches='tight')
    plt.close(fig)

    return save_path, (X_wave, Y_wave, Z_mag)

from utils.ft_utils import ft_affine,draw_ft_poly
def plot_ft_crop_scale(img, coeffs_t, coeffs_p, N=256, margin=20,target_area=512*512,color_t=(0, 0, 255),color_p=(0, 255, 0)):
    # img: 原图 (H,W,3)
    # coeffs_t: 傅里叶系数，coeffs_t[2+nf*4]
    # coeffs_p: 傅里叶系数，coeffs_p[2+nf*4]
    # margin: 外扩的像素
    # ---【关键修复】把所有可能的 CUDA Tensor 统一转 numpy ---
    if isinstance(img, torch.Tensor):
        img = img.detach().cpu().numpy()
        # 如果图像是 CHW，需要转成 HWC:
        if img.ndim == 3 and img.shape[0] < 10:
            img = img.transpose(1,2,0)

    ###############################################
    # (1) 得到闭合曲线点集
    ###############################################
    xf_p, yf_p = ffts_1(coeffs_t[None, :], N)

    # xf_p / yf_p 如果来自 torch，也要保证是 numpy
    if not isinstance(xf_p, np.ndarray):
        xf_p = np.asarray(xf_p.cpu())
    if not isinstance(yf_p, np.ndarray):
        yf_p = np.asarray(yf_p.cpu())

    a0, c0 = coeffs_t[0], coeffs_t[1]

    ###############################################
    # (2) 计算 bounding box + margin
    ###############################################
    xmin, xmax = xf_p.min(), xf_p.max()
    ymin, ymax = yf_p.min(), yf_p.max()

    xmin -= margin
    xmax += margin
    ymin -= margin
    ymax += margin

    # 目标区域大小
    w = xmax - xmin
    h = ymax - ymin

    ###############################################
    # (3) 构建 warpAffine 仿射矩阵 A23
    #
    # 将 [xmin, ymin] 作为裁剪 patch 的左上角
    # A23 把原图坐标映射到 patch 坐标 (u,v)
    ###############################################
    A23 = np.array([
        [1, 0, -xmin],
        [0, 1, -ymin]
    ], dtype=np.float32)
    A33 = torch.eye(3, dtype=torch.float32).to(coeffs_t.device)
    A33[:2, :] = torch.from_numpy(A23).to(coeffs_t.device)

    ###############################################
    # (4) resize 到 512x512
    ###############################################
    # target_area = 512 * 512  # 目标面积
    area = w * h

    # 为保持长宽比不变，scale_x = scale_y = scale
    scale = (target_area / area) ** 0.5

    A_resize = np.array([
        [scale, 0,     0],
        [0,     scale, 0]
    ], dtype=np.float32)

    A_big = torch.eye(3, dtype=torch.float32).to(coeffs_t.device)
    A_big[:2, :] = torch.from_numpy(A_resize).to(coeffs_t.device)

    ###############################################
    # (5) 组合 M = A @ A33
    ###############################################
    M = A_big @ A33  # 3x3
    A23 = M[:2]

    patch_resized = cv2.warpAffine(img, A23.cpu().numpy(), (round(scale*w), round(scale*h)))

    ###############################################
    # (6) 用 M 变换 Fourier 系数
    ###############################################
    coeffs_t2 = ft_affine(coeffs_t, M)
    ###############################################
    # (7) 用变换后的系数重新生成曲线
    ###############################################
    xft, yft = draw_ft_poly(patch_resized,coeffs_t2,N, color=color_t, draw_cen=1)
    
    if coeffs_p is not None:
        coeffs_p2 = ft_affine(coeffs_p, M)
        xfp, yfp = draw_ft_poly(patch_resized,coeffs_p2,N, color=color_p,draw_cen=1)
    else:
        xfp = yfp = coeffs_p2 = None

    ###############################################
    # (8) 返回结果：小图+新曲线点集+变换系数
    ###############################################
    return patch_resized, xft, yft, xfp, yfp, coeffs_t2, coeffs_p2, A23