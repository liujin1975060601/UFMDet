import shutil
from pathlib import Path
from tqdm import tqdm
from typing import Optional, List, Union
import yaml

# 源目录和目标目录
class DataSplit(object):
    SAMPLE_FORMAT = ('.jpg', '.jpeg','.bmp','.png', '.csv')
    LABEL_FORMAT = ('.txt', '.pts', '.ft', '.xyz', '.abc', '.dir', '.pol')
    def __init__(self, allpath, save_path):
        allpath = Path(allpath).absolute()
        self.images_dir = allpath / 'images'
        self.labels_dir = allpath / 'labels'

        self.split_dir = Path(save_path)
        self.split_images_dir = self.split_dir / 'images'
        self.split_labels_dir = self.split_dir / 'labels'

    def __call__(self, 
                 keep_cls: Union[List[str], List[int]]=[], 
                 yaml_path: Optional[str]=None):
        names = self.images_dir.parent / 'names.txt'
        if yaml_path is None:
            with open(names, 'r') as fr:
                names = [c.strip() for c in fr.read().splitlines() if c.strip() != '']
        else:
            with open(yaml_path, 'r') as f:
                names = yaml.safe_load(f)['names']  # load hyps dict

        if all([isinstance(c, int) for c in keep_cls]):
            keep_idx = keep_cls
        else:
            keep_idx = [names.index(c) for c in keep_cls]
        
        # 创建目标目录
        self.split_images_dir.mkdir(parents=True, exist_ok=True)
        self.split_labels_dir.mkdir(parents=True, exist_ok=True)

        # 获取 images 文件列表
        image_files = [f for f in self.images_dir.glob('*.*') if f.suffix.lower() in  self.SAMPLE_FORMAT]

        # 取 ??% 样本
        # num_samples = len(image_files)
        # num_to_move = int(num_samples * sample_ratio)
        # sample_indices = random.sample(range(num_samples), num_to_move)
        num_to_move = 0

        # 转移文件
        for img_name in tqdm(image_files, desc="Moving..."):

            # 检查是否有保留类别的目标
            lbl_name = self.labels_dir / img_name.with_suffix('.txt').name
            with open(lbl_name, 'r') as fr:
                cls_idx = [int(c.strip().split()[0]) for c in fr.read().splitlines() if c.strip() != '']
            keep_label_idx = [i for i, c in enumerate(cls_idx) if c in keep_idx]

            if len(keep_label_idx) > 0:
                # 移动图片
                shutil.copy(img_name, self.split_images_dir / img_name.name)

                # 提取标签
                for suf in self.LABEL_FORMAT:
                    lbl_name = self.labels_dir / img_name.with_suffix(suf).name
                    if lbl_name.exists():
                        with open(lbl_name, 'r') as fr:
                            with open(self.split_labels_dir / f"{img_name.stem}{lbl_name.suffix}", 'w') as fw:
                                read_ = [c.strip() for c in fr.read().splitlines() if c.strip() != '']
                                read_ = [read_[i] for i in keep_label_idx]
                                if suf in ['.pol', '.txt', '.ft']:
                                    read_new = [r.split() for r in read_]
                                    for r in read_new:
                                        r[0] = str(keep_idx.index(int(r[0])))
                                    read_ = [' '.join(r) for r in read_new]
                                fw.write('\n'.join(read_))

                num_to_move += 1

        print(f"Moved {num_to_move} samples to {self.split_dir}.")

if __name__ == '__main__':
    all_dir = r'/data/datas/coco2017/train'
    save_path = r'/data/datas/coco_line/train'

    keep_cls = [
        'cat', 'dog',
        'tie', # 领带
        'toothbrush', # 牙刷
        'fork', # 叉子
        'knife', # 刀
        'spoon', # 勺子
        'skis', # 滑雪板（双板）
        'snowboard', # 滑雪板（单板）
        'baseball bat', # 棒球棒
        'skateboard', # 滑板
        'surfboard' # 冲浪板
    ]

    ds = DataSplit(all_dir, save_path)
    ds(keep_cls)
    print()