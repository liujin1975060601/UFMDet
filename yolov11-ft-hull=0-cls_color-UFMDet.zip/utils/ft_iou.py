# @article{FourierDetByJinLiu,
#     author  = "Jin Liu; Zhongyuan Lu; Yaorong Cen; Hui Hu; Zhenfeng Shao; Yong Hong, Ming Jiang, Miaozhong Xu",
#     title   = "Enhancing Object Detection With Fourier Series",
#     year    = "January 8, 2025",
#     journal = "IEEE Transactions on Pattern Analysis and Machine Intelligence",
#     volume  = "47",
#     number  = "4",
#     pages   = "2581 - 2596",
#     doi = 10.1109/TPAMI.2025.3526990,
#     month   = "January",
# }
# @article{FourierDetByJinLiu,
#     author  = "Jin Liu, Huan Li, Zhenfeng Shao, Biyin Zhang, Mi Wang",
#     title   = "UFMDet: Unified Fourier Multi-shape Detection for Blob-like and Line-like Objects in Natural Scenes",
#     Submit to "IEEE Transactions on Pattern Analysis and Machine Intelligence",
# }
from shapely.geometry import Polygon
import os
import numpy as np
import torch
import warnings
import cv2

def polygon_iou(poly1_pts, poly2_pts):
    # poly1_pts, poly2_pts: list of (x, y) tuples representing polygon vertices.
    poly1 = Polygon(poly1_pts)
    poly2 = Polygon(poly2_pts)

    # 修复无效多边形
    # if not poly1.is_valid:
    poly1 = poly1.buffer(0)
    # if not poly2.is_valid:
    poly2 = poly2.buffer(0)

    if poly1.is_valid and poly2.is_valid: # and is_valid_coords(poly1) and is_valid_coords(poly2):
        try:
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", category=RuntimeWarning) 
                inter_area = poly1.intersection(poly2).area
            union_area = poly1.union(poly2).area
            if union_area > 0:
                return inter_area / union_area
            else:
                print('# 交集为空')
                return 0.0
        except:
            return 0.0
    else:
        print('# 无效多边形')
        return 0.0  # 无效多边形


def read_ft(ft_file):
    if os.path.exists(ft_file):
        with open(ft_file) as f: #.dir (4)
            l_ft = [x.split() for x in f.read().strip().splitlines() if len(x)]#l_ft[nt][str[4]]
            l_ft = np.array(l_ft, dtype=np.float32)#list转np矩阵 l_ft[nt][str[4]]-->l_ft[nt,4])
    else:
        return None
    return l_ft

from .ft_utils import ft2xy
def get_curve(ft_label, num=200):
    theta_fine = np.linspace(0, 2*np.pi, num)
    an,bn,cn,dn = np.split(ft_label[2:].reshape(-1, 4), 4, axis=-1)
    an,bn,cn,dn = np.insert(an,0,ft_label[0]),np.insert(bn,0,0),np.insert(cn,0,ft_label[1]),np.insert(dn,0,0)
    
    x_approx,y_approx = ft2xy(an,bn,cn,dn,theta_fine,0)#an.shape[0]
    contour_approx = np.array(list(zip(x_approx, y_approx))).reshape((-1, 2))
    # cv2.polylines(img, [contour_approx], isClosed=True, color=color, thickness=2)
    return contour_approx       # 200, 1, 2

def box_iou(box1, box2):
    # Return intersection-over-union (Jaccard index) of boxes.
    # Both sets of boxes are expected to be in (x1, y1, x2, y2) format.
    # Arguments:
    #     box1 (np.ndarray[N, 4])
    #     box2 (np.ndarray[M, 4])
    # Returns:
    #     iou (np.ndarray[N, M]): the NxM matrix containing the pairwise
    #         IoU values for every element in boxes1 and boxes2
    def box_area(box):
        return (box[:, 2] - box[:, 0]) * (box[:, 3] - box[:, 1])
    if isinstance(box1, torch.Tensor):
        maximum = torch.maximum
        minimum = torch.minimum
        clip_left = lambda x, y: torch.clamp(x, min=y)
    else:
        maximum = np.maximum
        minimum = np.minimum
        clip_left = lambda x, y: np.clip(x, a_min=y, a_max=np.inf)
    area1 = box_area(box1)  # (N,)
    area2 = box_area(box2)  # (M,)
    
    # Calculate intersection areas
    lt = maximum(box1[:, None, :2], box2[:, :2])  # (N, M, 2)
    rb = minimum(box1[:, None, 2:], box2[:, 2:])  # (N, M, 2)
    
    wh = clip_left(rb - lt, 0)       # (N, M, 2)
    inter = wh[:, :, 0] * wh[:, :, 1]  # (N, M)
    
    # Calculate union areas
    union = area1[:, None] + area2 - inter  # (N, M)
    
    # Avoid division by zero
    iou = inter / clip_left(union, 1e-7)
    return iou

def polygon_iou_ft(ft_1, ft_2, classes_1=None, classes_2=None,
                    ft1_hull=True,
                    ft2_hull=True):
    ft_1 = ft_1.cpu().numpy().astype(np.float64)
    ft_2 = ft_2.cpu().numpy().astype(np.float64)
    ft_1_curve = np.stack([get_curve(ft) for ft in ft_1])
    ft_2_curve = np.stack([get_curve(ft) for ft in ft_2])
    if not ft1_hull:
        ft_1_curve = [cv2.convexHull(ft_.astype(np.float32).reshape(-1, 2)).reshape(-1, 2) for ft_ in ft_1_curve]
    if not ft2_hull:
        ft_2_curve = [cv2.convexHull(ft_.astype(np.float32).reshape(-1, 2)).reshape(-1, 2) for ft_ in ft_2_curve]
    min_ = lambda x: np.array([[min(x_[:, 0]), min(x_[:, 1])] for x_ in x])
    max_ = lambda x: np.array([[max(x_[:, 0]), max(x_[:, 1])] for x_ in x])

    ft_1_xyxy = np.concatenate([min_(ft_1_curve), max_(ft_1_curve)], axis=-1)
    ft_2_xyxy = np.concatenate([min_(ft_2_curve), max_(ft_2_curve)], axis=-1)
    bbox_iou = box_iou(ft_1_xyxy, ft_2_xyxy)

    # import torch
    # import sys
    # sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    # ft_1_torch = torch.from_numpy(ft_1)
    # ft_2_torch = torch.from_numpy(ft_1)
    # for labels_ft in [ft_1_torch, ft_2_torch]:
    #     labels_ft[:, :2] = labels_ft[:, :2] * torch.Tensor([w, h])
    #     labels_ft[:, 2:] = labels_ft[:, 2:] * torch.Tensor([w, w, h, h]).repeat((labels_ft.shape[-1]-2) // 4).view(1, -1)
    # bbox_iou = box_iou_ft(ft_1_torch, ft_2_torch).numpy()

    if (classes_1 is not None) and (classes_2 is not None):
        assert classes_1.shape[0] == ft_1.shape[0]
        assert classes_2.shape[0] == ft_2.shape[0]
        bbox_iou[(classes_1.reshape(-1, 1) != classes_2.reshape(1, -1)).detach().cpu().numpy()] = 0.
    for i in range(bbox_iou.shape[0]):
        for j in range(bbox_iou.shape[1]):
            if bbox_iou[i, j] > 0:
                bbox_iou[i, j] = polygon_iou(ft_1_curve[i], ft_2_curve[j])
    return bbox_iou
    

def xywh2xyxy(x):
    """
    Convert bounding box coordinates from (x, y, width, height) format to (x1, y1, x2, y2) format where (x1, y1) is the
    top-left corner and (x2, y2) is the bottom-right corner. Note: ops per 2 channels faster than per channel.

    Args:
        x (np.ndarray | torch.Tensor): The input bounding box coordinates in (x, y, width, height) format.

    Returns:
        y (np.ndarray | torch.Tensor): The bounding box coordinates in (x1, y1, x2, y2) format.
    """
    assert x.shape[-1] == 4, f"input shape last dimension expected 4 but input shape is {x.shape}"
    xy = x[..., :2]  # centers
    wh = x[..., 2:] / 2  # half width-height
    return (np.concatenate if isinstance(x, np.ndarray) else torch.cat)((xy - wh, xy + wh), -1)


def polygon_iou_hv(ft_1, hv_2, classes_1=None, classes_2=None, xywh=False):
    ft_1 = ft_1.cpu().numpy().astype(np.float64)
    if xywh:
        hv_2 = xywh2xyxy(hv_2)
    hv_2 = hv_2.cpu().numpy().astype(np.float64)
    # ft_2 = ft_2.cpu().numpy().astype(np.float64)
    ft_1_curve = np.stack([get_curve(ft) for ft in ft_1])
    # ft_2_curve = np.stack([get_curve(ft) for ft in ft_2])
    ft_1_xyxy = np.concatenate([np.amin(ft_1_curve, axis=1), np.amax(ft_1_curve, axis=1)], axis=-1)
    # ft_2_xyxy = np.concatenate([np.amin(ft_2_curve, axis=1), np.amax(ft_2_curve, axis=1)], axis=-1)
    hv_2_curve = np.stack([np.array(hv[[0,1,0,3,2,3,2,1]]).reshape(-1, 2) for hv in hv_2])

    bbox_iou = box_iou(ft_1_xyxy, hv_2)

    # import torch
    # import sys
    # sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    # ft_1_torch = torch.from_numpy(ft_1)
    # ft_2_torch = torch.from_numpy(ft_1)
    # for labels_ft in [ft_1_torch, ft_2_torch]:
    #     labels_ft[:, :2] = labels_ft[:, :2] * torch.Tensor([w, h])
    #     labels_ft[:, 2:] = labels_ft[:, 2:] * torch.Tensor([w, w, h, h]).repeat((labels_ft.shape[-1]-2) // 4).view(1, -1)
    # bbox_iou = box_iou_ft(ft_1_torch, ft_2_torch).numpy()

    if (classes_1 is not None) and (classes_2 is not None):
        assert classes_1.shape[0] == ft_1.shape[0]
        assert classes_2.shape[0] == hv_2_curve.shape[0]
        bbox_iou[(classes_1.reshape(-1, 1) != classes_2.reshape(1, -1)).detach().cpu().numpy()] = 0.
    for i in range(bbox_iou.shape[0]):
        for j in range(bbox_iou.shape[1]):
            if bbox_iou[i, j] > 0:
                bbox_iou[i, j] = polygon_iou(ft_1_curve[i], hv_2_curve[j])
    return bbox_iou
    

def polygon_nms_ft(fts, scores, cls, iou_thresh=0.45, cls_offset=0, h_thresh_dec=0.6,dif_cls_iou_thresh=1.1): #fts[np,2+4n]  cls[np]  scores[np]
    fts = fts.cpu().numpy().astype(np.float64)
    if cls_offset:
        fts[:, :2] = fts[:, :2] + cls[:,None] * 4096
    fts_curve = np.stack([get_curve(ft) for ft in fts]) #fts_curve[np,npts,2(xy)]
    fts_xyxy = np.concatenate([np.amin(fts_curve, axis=1), np.amax(fts_curve, axis=1)], axis=-1) #fts_xyxy[np,4(xyxy)]

    order = scores.cpu().numpy().argsort()[::-1].copy() #order[np]
    keep = []
    while order.size > 0:
        order_i = order[0]
        keep.append(order_i)
        cls_i = cls[order_i]

        if order.size == 1:
            break
        
        next_order = order[1:] #next_order[np-1]
        hbb_ord_iou = box_iou(fts_xyxy[order_i:order_i+1], fts_xyxy[next_order])[0] #iou[1,np-1]-->hbb_ord_iou[np-1] 注:这里1:是后面+1的原因
        cls_ord = cls[next_order] #cls_ord[np-1]
        assert hbb_ord_iou.shape[0]==cls_ord.shape[0]
        h_ord_ids = np.where(hbb_ord_iou > h_thresh_dec * iou_thresh)[0]  #与第order_i框hbb有重叠的框order索引  h_ord_ids[nh]
        ids = next_order[h_ord_ids] #注意前面是order[1:]，所以+1 -->ids[nh]

        iou = [polygon_iou(fts_curve[order_i], fts_curve[tmp]) for tmp in ids] #iou[nh]
        hbb_ord_iou[h_ord_ids] = np.array(iou) #list可以复制给一个等大的numpy  hbb_ord_iou[nh]-->hbb_ord_iou[np-1]
        #
        same_cls_mask = cls_ord==cls_i #same_cls_mask[np-1]
        if dif_cls_iou_thresh >= 1.0:
            # 类别逻辑：同类 IoU > iou_thresh 删除，其他保留
            keep_mask = (~same_cls_mask) | (hbb_ord_iou <= iou_thresh)
        else:
            diff_cls_mask = ~same_cls_mask
            # 初始化全保留
            keep_mask = np.ones_like(hbb_ord_iou, dtype=bool)
            # 相同类：Polygon IOU > iou_thresh 就去掉
            keep_mask[same_cls_mask] = hbb_ord_iou[same_cls_mask] <= iou_thresh
            # 不同类：Polygon IOU > dif_cls_iou_thresh 也去掉
            keep_mask[diff_cls_mask] = hbb_ord_iou[diff_cls_mask] <= dif_cls_iou_thresh
            #
            # ord_inds_same = np.where(hbb_ord_iou[ same_cls_mask] <= iou_thresh)[0] #hbb_ord_iou[np]-> ord_inds[nids] 留下iou小的就是不重复的框
            # ord_inds_diff = np.where(hbb_ord_iou[~same_cls_mask] <= 1.0)[0] #hbb_ord_iou[np]-> ord_inds[nids] 留下iou小的就是不重复的框
            # ord_inds = np.concatenate([ord_inds_same, ord_inds_diff])
            # # order = order[ord_inds + 1] #注意前面是order[1:]，所以+1
            # order = next_order[ord_inds]

        # 更新剩余顺序
        order = next_order[keep_mask]
            
    return np.asarray(keep, dtype=int)

def polygon_nms_ft_ok(fts, scores, cls, iou_thresh=0.45):
    fts = fts.cpu().numpy().astype(np.float64)
    scores = scores.cpu().numpy()

    fts_curve = np.stack([get_curve(ft) for ft in fts])  # [N, npts, 2]
    fts_xyxy = np.concatenate([
        np.amin(fts_curve, axis=1), np.amax(fts_curve, axis=1)
    ], axis=-1)  # [N, 4]

    order = scores.argsort()[::-1].copy()
    keep = []

    while order.size > 0:
        order_i = order[0]
        keep.append(order_i)
        cls_i = cls[order_i]

        if order.size == 1:
            break

        next_order = order[1:]
        hbb_ord_iou = box_iou(fts_xyxy[order_i:order_i+1], fts_xyxy[next_order])[0]
        cls_ord = cls[next_order]

        h_ord_ids = np.where(hbb_ord_iou > 0)[0]
        ids = next_order[h_ord_ids]

        iou = [polygon_iou(fts_curve[order_i], fts_curve[tmp]) for tmp in ids]
        hbb_ord_iou[h_ord_ids] = np.array(iou)

        # 类别逻辑：同类 IoU > iou_thresh 删除，其他保留
        keep_mask = (cls_ord != cls_i) | (hbb_ord_iou <= iou_thresh)
        order = next_order[keep_mask]

    return np.asarray(keep, dtype=int)


def get_curve_batch(ft_labels, num=200, half=False, reverse=False):
    bs = ft_labels.shape[0]
    theta_fine_start = 0 if not reverse else torch.pi
    theta_fine_width = 2 if not half else 1
    theta_fine = torch.linspace(theta_fine_start, theta_fine_start + theta_fine_width*torch.pi, num, dtype=ft_labels.dtype, device=ft_labels.device).view(1, -1)

    an,bn,cn,dn = torch.split(ft_labels[:, 2:].reshape(bs, -1, 4), 1, dim=-1)
    zero = torch.zeros((bs, 1), dtype=ft_labels.dtype, device=ft_labels.device)
    an,bn,cn,dn = an.squeeze(-1), bn.squeeze(-1), cn.squeeze(-1), dn.squeeze(-1)
    an, cn = torch.cat([ft_labels[:, 0:1], an], dim=1), torch.cat([ft_labels[:, 1:2], cn], dim=1)
    bn, dn = torch.cat([zero, bn], dim=1), torch.cat([zero, dn], dim=1)
    #
    # new method for torch
    theta_fine = torch.arange(an.shape[1], dtype=ft_labels.dtype, device=ft_labels.device).view(-1, 1) @ theta_fine # [term, num]
    x_approx = an @ torch.cos(theta_fine) + bn @ torch.sin(theta_fine)
    y_approx = cn @ torch.cos(theta_fine) + dn @ torch.sin(theta_fine)
    
    contour_approx = torch.stack([x_approx, y_approx], dim=-1)
    # cv2.polylines(img, [contour_approx], isClosed=True, color=color, thickness=2)
    return contour_approx       # bs, num, 2

def line_dist(labels, detections, mask_line_gt, pixel=False):
    # Arguments:
    #     detections (Array[N, 2+4*ftcoef])
    #     labels (Array[M, 2+4*ftcoef])
    #     mask_line_gt (Array[M])
    # Returns:
    #     correct (Array[N, 10]), for 10 IoU levels
    num = int((labels.shape[-1] - 2) // 4) * 2
    labels_pol = get_curve_batch(labels, num, half=True)   # N, num, 2


    detections_pol = get_curve_batch(detections, num, half=True)   # M, num, 2
    labels_len = torch.sqrt(((labels_pol[:, :-1] - labels_pol[:, 1:]) ** 2).sum(-1)).sum(-1)
    detections_len = torch.sqrt(((detections_pol[:, :-1] - detections_pol[:, 1:]) ** 2).sum(-1)).sum(-1)

    ld_len_0 = torch.sqrt(((labels_pol[:, None] - detections_pol[None]) ** 2).sum(-1)).mean(-1)    # [N, M]
    
    mask_line = mask_line_gt == 1
    if mask_line.sum() > 0:
        labels_pol_reverse = get_curve_batch(labels[mask_line], num, half=True, reverse=True)
        ld_len_1 = torch.sqrt(((labels_pol_reverse[:, None] - detections_pol[None]) ** 2).sum(-1)).mean(-1)
        ld_len_0[mask_line] = torch.minimum(ld_len_0[mask_line], ld_len_1)

    ld_len_relative = ld_len_0 / ((labels_len[:, None] + detections_len[None]) / 2 + 1e-6)

    return ld_len_relative if not pixel else (ld_len_0, ld_len_relative)#iou[ngt,npred] 得到真值框和预测框的iou匹配矩阵

def kpt_iou_ft(labels, detections,
            num=200,
            sigma=0.1, # 0.2 0.1
            fixed_start=True):
    # Arguments:
    #     detections (Array[N, 2+4*ftcoef])
    #     labels (Array[M, 2+4*ftcoef])
    # Returns:
    #     correct (Array[N, 10]), for 10 IoU levels
    num = int((labels.shape[-1] - 2) // 4) * 2

    gt_pts, gt_centers, gt_scales = ft_curve_and_meta(labels, num=num)
    pred_pts, pred_centers, pred_scales = ft_curve_and_meta(detections, num=num)

    kpt_iou = [ft_kpt_iou_pairwise(
            gt_pts[i:i+1], pred_pts,
            gt_scales[i:i+1], pred_scales,
            sigma=sigma,
            fixed_start=fixed_start
        )   for i in range(labels.shape[0])]
    kpt_iou = torch.stack(kpt_iou, dim=0)   # [Ngt, Npred]

    return kpt_iou #iou[ngt,npred] 得到真值框和预测框的iou匹配矩阵

def polygon_nms_ft_line(fts, scores, cls, mask_line, dist_thres=0.5, pixel_thres=10, bboxes=None):
    # fts = fts.cpu().numpy().astype(np.float64)
    scores = scores.cpu().numpy()
    order = scores.argsort()[::-1].copy()
    keep = []

    while order.size > 0:
        order_i = order[0]
        keep.append(order_i)
        cls_i = cls[order_i]

        if order.size == 1:
            break
            
        next_order = order[1:]
        cls_ord = cls[next_order]
        same_cls = torch.from_numpy((cls_ord == cls_i)[np.newaxis]).to(fts.device)  # 
        hbb_ord_dist_pixel = torch.ones((1,next_order.shape[0]), dtype=torch.float32, device=fts.device) * (pixel_thres + 1)
        hbb_ord_dist = torch.ones((1,next_order.shape[0]), dtype=torch.float32, device=fts.device)
        if bboxes is not None:
            bboxes_ord = bboxes[next_order]
            hbb_ord_box = box_iou(bboxes[order_i:order_i+1], bboxes_ord)
            same_cls = same_cls & (hbb_ord_box > 0)
        if same_cls.sum() > 0:
            hbb_ord_dist_pixel_part, hbb_ord_dist_part = line_dist(fts[order_i:order_i+1], fts[next_order][same_cls.squeeze(0)], mask_line[next_order][same_cls.squeeze(0)], pixel=True)
            hbb_ord_dist_pixel[same_cls] = hbb_ord_dist_pixel_part
            hbb_ord_dist[same_cls] = hbb_ord_dist_part
        hbb_ord_dist_pixel = hbb_ord_dist_pixel[0]
        hbb_ord_dist = hbb_ord_dist[0]

        # 类别逻辑：同类 Dist < dist_thresh 删除，其他保留
        keep_mask = (cls_ord != cls_i) | ((hbb_ord_dist > dist_thres).cpu().numpy() & (hbb_ord_dist_pixel > pixel_thres).cpu().numpy())
        order = next_order[keep_mask]

    return np.asarray(keep, dtype=int)

def ft_curve_and_meta(ft, num=200):
    """
    将 FT 参数转换为轮廓采样点，并预计算一些元信息（中心、尺度）。

    参数：
        ft: torch.Tensor, [N, 2 + 4*k]
            每个目标的傅里叶参数（你项目里的格式）
        num: int
            轮廓采样点数量（越大越准，但越慢）
    返回：
        pts:    [N, num, 2]  每个目标的轮廓采样点
        center: [N, 2]       轮廓点的均值中心（用于便宜的距离门控）
        scale:  [N]          尺度（由轮廓bbox面积开根号得到，用于归一化）
    """
    # pts = get_curve_batch(ft, num=num, half=False)  # [N, num, 2]
    pts = get_curve_batch(ft, num=num, half=True)  # [N, num, 2]

    xy_min = pts.amin(dim=1)  # [N,2]
    xy_max = pts.amax(dim=1)  # [N,2]
    wh = (xy_max - xy_min).clamp(min=1e-6)

    scale = torch.sqrt(wh[:, 0] * wh[:, 1])  # [N]
    center = pts.mean(dim=1)  # [N,2]
    return pts, center, scale


def ft_kpt_iou_pairwise(
    pts_a, pts_b, scale_a, scale_b,
    sigma=0.2,
    shifts=(0, 25, 50, 75, 100, 125, 150, 175),
    gate_center=3.0,
    gate_scale_ratio=2.5,
    fixed_start=False
):
    """
    计算 “仿 kpt_iou / OKS” 的轮廓相似度（0~1），用于 NMS。

    核心思想：
        把轮廓采样点当作“关键点集合”，对应点距离越小，相似度越高。
        sim = mean(exp(-d^2/(2*s^2*sigma^2)))

    关键问题：
        1) 闭合轮廓可能起点不同（相位偏移）：用 circular shift 对齐
        2) 顺逆时针可能相反：同时比较 reverse 版本
        3) 不做 box_iou 粗筛，但仍需要“便宜门控”避免 O(N^2) 太慢

    参数：
        pts_a:   [1, M, 2]   一个参考轮廓（当前保留框）
        pts_b:   [K, M, 2]   K 个候选轮廓（要被抑制的候选）
        scale_a: [1]         参考轮廓尺度
        scale_b: [K]         候选轮廓尺度
        sigma:   float       容忍度，越小越严格
        shifts:  tuple       只测试有限个 shift（避免全 shift 太慢）
        gate_center: float   中心距离门控系数：距离 > gate_center * s_ab 直接判 0
        gate_scale_ratio: float  尺度比门控：尺度差太大直接判 0
        fixed_start: bool      固定起点，不做循环位移对齐（更快，但可能错过相位偏移）
    返回：
        sim: [K]，每个候选与参考之间的相似度（0~1）
    """
    # M：轮廓采样点数量。pts_a/pts_b 都是按相同采样策略得到的点序列。
    # 形状约定：
    #   pts_a: [1, M, 2]   当前“保留框”的轮廓点（只取 1 个参考）
    #   pts_b: [K, M, 2]   K 个候选框的轮廓点
    M = pts_a.shape[1]

    # 便宜门控 1：中心距离门控
    # 用轮廓点均值作为“中心”，先排除明显离得太远的候选，避免后续 O(K*M*|shifts|) 计算太慢。
    center_a = pts_a.mean(dim=1)      # [1,2]
    center_b = pts_b.mean(dim=1)      # [K,2]

    # s_ab：用两者尺度的平均值作为归一化尺度（类似 OKS 里的 object scale）。
    # 这里 scale_a 是标量 [1]，scale_b 是向量 [K]，广播后得到 [K]
    s_ab = (scale_a + scale_b) * 0.5  # [K]

    # center_dist：候选中心到参考中心的欧氏距离
    # gate1：距离超过 gate_center * s_ab 的直接判为 0，相当于只在“合理邻域”内做精细匹配。
    center_dist = torch.sqrt(((center_b - center_a) ** 2).sum(-1) + 1e-9)  # [K]
    gate1 = center_dist <= (gate_center * s_ab)

    # 便宜门控 2：尺度比门控
    # ratio 取两者尺度比的“较大者”，保证 ratio >= 1；若差异太大，也没必要做后续对齐。
    ratio = torch.maximum(scale_b / (scale_a + 1e-9), scale_a / (scale_b + 1e-9))
    gate2 = ratio <= gate_scale_ratio

    # valid：同时满足中心距离与尺度比的候选集合
    valid = gate1 & gate2
    if valid.sum() == 0:
        # 没有任何候选通过门控，直接返回全 0（表示与参考都不相似）
        return torch.zeros_like(scale_b)

    # 只对通过门控的候选做后续“相位对齐 + 正反向”相似度计算
    pts_bv = pts_b[valid]       # [Kv, M, 2]
    s_abv = s_ab[valid]         # [Kv]

    # denom：高斯核的分母项 (2 * s^2 * sigma^2)
    # - s 用 s_abv（尺度）让距离度量具备尺度不变性
    # - sigma 控制容忍度：sigma 越小，越严格；越大，越宽松
    denom = 2.0 * (s_abv[:, None] ** 2) * (sigma ** 2) + 1e-9  # [Kv,1]

    # pts_bv_rev：候选点序反向，用来处理轮廓点顺/逆时针不一致的情况
    pts_bv_rev = torch.flip(pts_bv, dims=[1])

    # best：记录每个候选在所有 shift（以及 forward/reverse）里能达到的最大相似度
    best = None

    # 固定起点：只计算一次 forward/reverse 的相似度
    if fixed_start:
        pts_a_shift = pts_a  # [1, M, 2]

        # forward：同方向逐点距离
        d2_f = ((pts_bv - pts_a_shift) ** 2).sum(-1)           # [Kv, M]
        sim_f = torch.exp(-d2_f / denom).mean(dim=1)           # [Kv]

        # reverse：反向（顺/逆时针不确定时取最大）
        d2_r = ((pts_bv_rev - pts_a_shift) ** 2).sum(-1)       # [Kv, M]
        sim_r = torch.exp(-d2_r / denom).mean(dim=1)           # [Kv]

        # 固定起点下取 forward/reverse 的最大相似度
        best = torch.maximum(sim_f, sim_r)
    else:
        # 起点不确定：尝试多个 shift 对齐
        for sh in shifts:
            sh_mod = sh % M
            pts_a_shift = torch.roll(pts_a, shifts=sh_mod, dims=1)  # [1, M, 2]

            # forward：同方向逐点距离
            d2_f = ((pts_bv - pts_a_shift) ** 2).sum(-1)           # [Kv, M]
            sim_f = torch.exp(-d2_f / denom).mean(dim=1)           # [Kv]

            # reverse：反向（顺/逆时针不确定时取最大）
            d2_r = ((pts_bv_rev - pts_a_shift) ** 2).sum(-1)       # [Kv, M]
            sim_r = torch.exp(-d2_r / denom).mean(dim=1)           # [Kv]

            sim = torch.maximum(sim_f, sim_r)
            # 多个 shift：取最大相似度
            best = sim if best is None else torch.maximum(best, sim)

    out = torch.zeros_like(scale_b)
    out[valid] = best
    return out

def ft_iou_one2one(labels, detections, num=200, sigma=0.01,
                   shifts=(0, 25, 50, 75, 100, 125, 150, 175),
                   fixed_start=False):
    # 一对一版本 FT-IoU（完全可微）
    # labels:     [N, 2 + 4*k]
    # detections: [N, 2 + 4*k]
    # 返回:
    #     iou: [N]
    N = labels.shape[0]

    #------------------------------------------------------------
    # 1. inverse FT → 得到轮廓点
    #------------------------------------------------------------
    gt_pts, gt_center, gt_scale = ft_curve_and_meta(labels, num=num)     # [N,M,2]
    pd_pts, pd_center, pd_scale = ft_curve_and_meta(detections, num=num)

    M = gt_pts.shape[1]

    #------------------------------------------------------------
    # 2. 计算每个目标的 scale（OKS 正常化用）
    #------------------------------------------------------------
    scale = 0.5 * (gt_scale + pd_scale)      # [N]

    denom = 2.0 * (scale[:, None]**2) * (sigma**2) + 1e-9 if sigma>0 else 0  # [N,1]

    #------------------------------------------------------------
    # 3. 正反向点序
    #------------------------------------------------------------
    pd_pts_rev = torch.flip(pd_pts, dims=[1])    # [N,M,2]

    #------------------------------------------------------------
    # 4. shift 对齐 → 搜索最大 IoU
    #------------------------------------------------------------
    best = None

    if fixed_start:
        # forward
        d2_f = ((gt_pts - pd_pts)**2).sum(-1)    # [N,M]
        sim_f = torch.exp(-d2_f / denom).mean(dim=1)  # [N]

        # reverse
        d2_r = ((gt_pts - pd_pts_rev)**2).sum(-1)
        sim_r = torch.exp(-d2_r / denom).mean(dim=1)

        best = torch.maximum(sim_f, sim_r)

    else:
        # 遍历所有 shift（可微，roll 不影响梯度）
        for sh in shifts:
            sh_mod = sh % M

            # shift 过的 gt
            gt_shift = torch.roll(gt_pts, shifts=sh_mod, dims=1)   # [N,M,2]

            # forward
            d2_f = ((gt_shift - pd_pts)**2).sum(-1)        # d2_f[N,M]
            # reverse
            d2_r = ((gt_shift - pd_pts_rev)**2).sum(-1)    # d2_r[N,M]
            #
            if sigma > 0:
                sim_f = torch.exp(-d2_f / denom).mean(dim=1)   # sim_f[N]
                sim_r = torch.exp(-d2_r / denom).mean(dim=1)   # sim_r[N]
                sim = torch.maximum(sim_f, sim_r)
                best = sim if best is None else torch.maximum(best, sim)
            else:
                dist_f = d2_f.mean(dim=1) # dist_f[N]
                dist_r = d2_r.mean(dim=1) # dist_r[N]
                dist = torch.minimum(dist_f, dist_r)  # dist[N]
                best = dist if best is None else torch.minimum(best, dist)         

    return best   # [N]


def nms_ft_kpt_iou(
    fts, scores, cls,
    thr=0.7,
    dif_thr=1.1,
    num=200,
    sigma=0.1, # 0.2 0.1
    fixed_start=False,
):
    """
    使用 “FT-KPT-IOU 相似度” 做 NMS。

    参数：
        fts:    [N, 2+4k] torch.Tensor
        scores: [N]       torch.Tensor
        cls:    [N]       torch.Tensor or numpy（建议 torch）
        thr:    float     同类去重阈值
        dif_thr: float    不同类去重阈值逻辑同你原来的 dif_cls_iou_thresh
        num:    int       轮廓点采样数量
        sigma:  float     容忍度（越小越严格）
        fixed_start: bool      固定起点，不做循环位移对齐（更快，但可能错过相位偏移）
    返回：
        keep: torch.LongTensor，保留下来的索引
    """
    device = fts.device
    # 如果 cls 是 numpy 数组或其他非 tensor 类型，转换为与 fts 相同 device 的 torch Tensor
    if not torch.is_tensor(cls):
        try:
            cls = torch.as_tensor(cls, device=device)
        except Exception:
            # fallback: move to cpu then to device
            cls = torch.as_tensor(np.array(cls)).to(device)
    else:
        # 确保 cls 在同设备上（索引时 rest 是 CUDA tensor）
        cls = cls.to(device)
    order = scores.argsort(descending=True)
    keep = []
    
    fixed_start=True #：固定起点，不做循环位移对齐（更快，但可能错过相位偏移）
    # fixed_start=False：对齐轮廓起点（循环位移 + 顺逆方向取最大相似度）
    
    num = int((fts.shape[-1] - 2) // 4) * 2
    # num = int((labels.shape[-1] - 2) // 4) * 2
    pts, _centers, scales = ft_curve_and_meta(fts, num=num)

    while order.numel() > 0:
        # 取当前得分最高的索引作为保留
        i = order[0].item()
        keep.append(i)

        # 如果只剩一个候选，直接结束
        if order.numel() == 1:
            break

        # 剩余候选（按分数降序）
        rest = order[1:]
        # 当前保留框的类别，及剩余候选的类别向量
        cls_i = cls[i]
        cls_r = cls[rest]

        # 计算当前保留框与剩余每个候选的相似度（0~1），使用 ft_kpt_iou_pairwise
        # 该函数已做：中心/尺度门控、顺/逆时针与起点 shift 对齐、以及高斯核相似度聚合
        sim = ft_kpt_iou_pairwise(
            pts[i:i+1], pts[rest],
            scales[i:i+1], scales[rest],
            sigma=sigma,
            fixed_start=fixed_start
        )

        # same 是一个布尔向量，表示每个候选是否与当前保留框属于同一类别
        same = (cls_r == cls_i)

        # 类别抑制逻辑：
        # - 当 dif_thr >= 1.0 时，表示不同类别不互相抑制；同类中 sim > thr 就抑制（删除）
        # - 当 dif_thr < 1.0 时，表示不同类也参与抑制，分别用 thr / dif_thr 两个阈值控制
        if dif_thr >= 1.0:
            # keep_mask 为 True 的候选会被保留（不被抑制）
            keep_mask = (~same) | (sim <= thr)  # 不同类全部保留，同类中相似度小于等于 thr 的保留; 当前 thr = 0.1
        else:
            keep_mask = torch.ones_like(sim, dtype=torch.bool, device=device)
            # 同类：相似度大于 thr 的被抑制（置为 False）
            keep_mask[same] = sim[same] <= thr
            # 不同类：相似度大于 dif_thr 的也会被抑制
            keep_mask[~same] = sim[~same] <= dif_thr

        # 根据 keep_mask 更新待处理的候选序列（注意 rest 已去掉当前 i）
        order = rest[keep_mask]

    # 返回保留索引（tensor，放在原设备上）
    return torch.tensor(keep, device=device, dtype=torch.long)


from DOTA_devkit.polyiou_cpu import poly_iou_cpu64
from utils.ft_utils import ft2pts
def box_iou_ft(coef1s, coef2s, n=15):
    # coef1s [n1, 2 + ft_coef * 4]
    # coef2s [n2, 2 + ft_coef * 4]
    # boxes1 = ft2box(coef1s)
    # boxes2 = ft2box(coef2s)
    boxes1 = ft2pts(coef1s).cpu().numpy().astype(np.float64)
    boxes2 = ft2pts(coef2s).cpu().numpy().astype(np.float64)

    return torch.from_numpy(poly_iou_cpu64(boxes1, boxes2)).to(coef1s.device).float()


if __name__ == '__main__':
    from pathlib import Path
    ft_file = Path('~/workspace/datas/coco2017/train/labels/000000000009.ft').expanduser().resolve()
    img_file = Path('~/workspace/datas/coco2017/train/images/000000000009.jpg').expanduser().resolve()
    from PIL import Image, ImageDraw
    import cv2
    img = Image.open(img_file)
    w, h = img.size
    draw = ImageDraw.Draw(img)
    ft = read_ft(ft_file)

    ious = polygon_iou_ft(ft[:, 1:], ft[:, 1:], ft[:, :1], ft[:, :1])
    print()
    # import torch
    
    # import sys
    # sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    # if ft.shape[0] > 0:
    #     ft = ft[0][1:]
    #     assert ft.shape[0] % 2 == 0
    #     ft1 = ft.copy()
    #     ft1[:2] +=  np.asarray([10 / w, 50 / h])
    #     cont = get_curve(ft).reshape((-1, 2)) * np.asarray([[w, h]])
    #     cont1 = get_curve(ft1).reshape((-1, 2)) * np.asarray([[w, h]])

    #     # 将多边形的坐标提取出来
    #     poly1 = Polygon(cont).buffer(0)
    #     exterior_coords = list(poly1.exterior.coords)
    #     # 绘制多边形
    #     draw.polygon(exterior_coords, outline=(255, 0, 0), fill=(200, 200, 0))

    #     # 将多边形的坐标提取出来
    #     poly1 = Polygon(cont1).buffer(0)
    #     exterior_coords = list(poly1.exterior.coords)
    #     # 绘制多边形
    #     draw.polygon(exterior_coords, outline=(0, 255, 0), fill=(0, 200, 200))
        
    #     img.save('test.jpg')
    #     iou = polygon_iou(cont, cont1)
    #     iou1 = box_iou_ft(torch.from_numpy(ft).view(1, -1), torch.from_numpy(ft1).view(1, -1))
    #     print("IoU:", iou)
    #     print("IoU1:", iou1)