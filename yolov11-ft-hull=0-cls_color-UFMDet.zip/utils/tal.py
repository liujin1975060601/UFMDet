# Ultralytics YOLO 🚀, AGPL-3.0 license

import torch
import torch.nn as nn

from .metrics import bbox_iou,probiou
from .general import xywhr2xyxyxyxy,xywh2xyxy,xyxy2xywh

# TORCH_1_10 = check_version(torch.__version__, "1.10.0")


class TaskAlignedAssigner(nn.Module):
    """
    A task-aligned assigner for object detection.

    This class assigns ground-truth (gt) objects to anchors based on the task-aligned metric, which combines both
    classification and localization information.

    Attributes:
        topk (int): The number of top candidates to consider.
        num_classes (int): The number of object classes.
        alpha (float): The alpha parameter for the classification component of the task-aligned metric.
        beta (float): The beta parameter for the localization component of the task-aligned metric.
        eps (float): A small value to prevent division by zero.
    """

    def __init__(self, topk=13, num_classes=80, alpha=1.0, beta=6.0, eps=1e-9,
                 topk2 = None,
                 stride: list = [8, 16, 32],
                 v26 = False):
        """Initialize a TaskAlignedAssigner object with customizable hyperparameters."""
        super().__init__()
        self.topk = topk
        self.topk2 = topk if topk2 is None else topk2
        self.num_classes = num_classes
        self.bg_idx = num_classes
        self.alpha = alpha
        self.beta = beta
        self.eps = eps
        self.stride = stride
        self.v26 = v26

    @torch.no_grad()
    def forward(self, pd_scores, pd_bboxes, anc_points, gt_labels, gt_bboxes, mask_gt):
        # Compute the task-aligned assignment. Reference code is available at
        # https://github.com/Nioolek/PPYOLOE_pytorch/blob/master/ppyoloe/assigner/tal_assigner.py.
        # Args:
        #     pd_scores[bs, num_total_anchors, num_classes]
        #     pd_bboxes[bs, num_total_anchors, 4(xyxy)]
        #     anc_points[num_total_anchors, 2]
        #     gt_labels[bs, n_max_boxes, 1]
        #     gt_bboxes[bs, n_max_boxes, 4(xyxy)]
        #     mask_gt[bs, n_max_boxes, 1]
        # Returns:
        #     target_labels[bs, num_total_anchors]
        #     target_bboxes[bs, num_total_anchors, 4]
        #     target_scores[bs, num_total_anchors, num_classes]
        #     fg_mask[bs, num_total_anchors]
        #     target_gt_idx[bs, num_total_anchors]
        self.bs = pd_scores.shape[0]
        self.n_max_boxes = gt_bboxes.shape[1]

        if self.n_max_boxes == 0:
            device = gt_bboxes.device
            return (
                torch.full_like(pd_scores[..., 0], self.bg_idx).to(device),
                torch.zeros(*pd_bboxes.shape[:-1], gt_bboxes.shape[-1]).to(device),
                torch.zeros_like(pd_scores).to(device),
                torch.zeros_like(pd_scores[..., 0]).to(device),
                torch.zeros_like(pd_scores[..., 0]).to(device),
            )

        mask_pos, align_metric, overlaps = self.get_pos_mask(
            pd_scores, pd_bboxes, gt_labels, gt_bboxes, anc_points, mask_gt
        )#->mask_pos[b,nt,ntotal] align_metric[b,nt,ntotal] overlaps[b,nt,ntotal]

        target_gt_idx, fg_mask, mask_pos = self.select_highest_overlaps(mask_pos, overlaps, self.n_max_boxes) #target_gt_idx[b,ntotal] fg_mask[b,ntotal] mask_pos[b,nt,ntotal]

        # Assigned target
        target_labels, target_bboxes, target_scores = self.get_targets(gt_labels, gt_bboxes, target_gt_idx, fg_mask) #target_labels[B,ntotal] target_bboxes[B,ntotal,4(xyxy)] target_scores[B,ntotal,cls]

        # Normalize
        align_metric *= mask_pos
        pos_align_metrics = align_metric.amax(dim=-1, keepdim=True)  # b, max_num_obj
        pos_overlaps = (overlaps * mask_pos).amax(dim=-1, keepdim=True)  # b, max_num_obj
        norm_align_metric = (align_metric * pos_overlaps / (pos_align_metrics + self.eps)).amax(-2).unsqueeze(-1)
        target_scores = target_scores * norm_align_metric

        return target_labels, target_bboxes, target_scores, fg_mask.bool(), target_gt_idx #target_labels[b,ntotal] target_bboxes[b,ntotal,4(xyxy)] target_scores[b,ntotal,cls] fg_mask[b,ntotal] target_gt_idx[b,ntotal]

    def get_pos_mask(self, pd_scores, pd_bboxes, gt_labels, gt_bboxes, anc_points, mask_gt):
        # """Get in_gts mask, (b, max_num_obj, h*w)."""
        # 获取 anc_points 和 gt_bboxes(A-左上)/(右下-A) 中心在目标内 pixel的点阵 mask
        mask_in_gts = self.select_candidates_in_gts(anc_points, gt_bboxes, mask_gt=mask_gt if self.v26 else None) #mask_gt
        # Get anchor_align metric, (b, max_num_obj, h*w) 
        # 根据 gt 和 pd 得到每个batch的每个gt对应每个格子的 align_metric = scores^alpha * overlaps^beta
        align_metric, overlaps = self.get_box_metrics(pd_scores, pd_bboxes, gt_labels, gt_bboxes, mask_in_gts * mask_gt)
        # Get topk_metric mask, (b, max_num_obj, h*w)
        # 选取topk, mask_gt[bs, n_max_boxes, 1] --> topk_mask[bs, n_max_boxes, topk]
        mask_topk = self.select_topk_candidates(align_metric, topk_mask=mask_gt.expand(-1, -1, self.topk).bool())
        # Merge all mask to a final mask, (b, max_num_obj, h*w)
        mask_pos = mask_topk * mask_in_gts * mask_gt

        return mask_pos, align_metric, overlaps

    def get_box_metrics(self, pd_scores, pd_bboxes, gt_labels, gt_bboxes, mask_gt): #gt_bboxes[b,n_max,5(xywhr) + 4(xyxy) + 2+nf*4]
        """Compute alignment metric given predicted and ground truth bounding boxes."""
        ntotal = pd_bboxes.shape[-2] # pd_bboxes[b,ntotal,8] num_total_anchors
        mask_gt = mask_gt.bool()  # b, n_max, ntotal
        overlaps = torch.zeros([self.bs, self.n_max_boxes, ntotal], dtype=pd_bboxes.dtype, device=pd_bboxes.device)
        bbox_scores = torch.zeros([self.bs, self.n_max_boxes, ntotal], dtype=pd_scores.dtype, device=pd_scores.device)

        ind = torch.zeros([2, self.bs, self.n_max_boxes], dtype=torch.long)  # 2, b, n_max
        ind[0] = torch.arange(end=self.bs).view(-1, 1).expand(-1, self.n_max_boxes)  # b, n_max
        ind[1] = gt_labels.squeeze(-1)  # b, n_max    # 类标签
        # Get the scores of each grid for each gt cls
        # 取出预测pd_scores中对应batch, 对应类预测, 多维索引 提取
        # 相当于 ind[0][0~b-1], :, ind[1][0~b-1] 分别提取后拼接 是 [b * [n_max, num_total_anchors(, 1: squeeze)]] -- > [bs, n_max, num_total_anchors]
        # pd_scores [bs, num_total_anchors, num_classes] --> pd_scores[ind[0], :, ind[1]] [bs, n_max, num_total_anchors]
        bbox_scores[mask_gt] = pd_scores[ind[0], :, ind[1]][mask_gt]  # b, n_max, h*w (=num_total_anchors)

        # 广播至统一形状
        # pd->(b, n_max, ntotal, 5(xywhr)), gt->(b, n_max, ntotal, 5(xywhr))
        pd_boxes = pd_bboxes.unsqueeze(1).expand(-1, self.n_max_boxes, -1, -1)[mask_gt]#[b,(n_max),ntotal,5+]->pd_boxes[nt,5+]
        gt_boxes = gt_bboxes.unsqueeze(2).expand(-1, -1, ntotal, -1)[mask_gt]          #[b,n_max,(ntotal),5+]->gt_boxes[nt,5+]
        assert pd_boxes.shape[0]==gt_boxes.shape[0]
        if gt_boxes.shape[0]>0:
            overlaps[mask_gt] = self.iou_calculation(gt_boxes, pd_boxes)  # (b, max_num_obj, ntotal)

        align_metric = bbox_scores.pow(self.alpha) * overlaps.pow(self.beta) # (b, max_num_obj, ntotal)
        return align_metric, overlaps

    def iou_calculation(self, gt_bboxes, pd_bboxes):
        """IoU calculation for horizontal bounding boxes."""
        return bbox_iou(gt_bboxes[..., :4], pd_bboxes[..., :4], xywh=False, CIoU=True).squeeze(-1).clamp_(0)

    def select_topk_candidates(self, metrics, largest=True, topk_mask=None):
        """
        Select the top-k candidates based on the given metrics.

        Args:
            metrics (Tensor): A tensor of shape (b, max_num_obj, h*w), where b is the batch size,
                              max_num_obj is the maximum number of objects, and h*w represents the
                              total number of anchor points.
            largest (bool): If True, select the largest values; otherwise, select the smallest values.
            topk_mask (Tensor): An optional boolean tensor of shape (b, max_num_obj, topk), where
                                topk is the number of top candidates to consider. If not provided,
                                the top-k values are automatically computed based on the given metrics.

        Returns:
            (Tensor): A tensor of shape (b, max_num_obj, h*w) containing the selected top-k candidates.
        """
        # (b, max_num_obj, topk)
        topk_metrics, topk_idxs = torch.topk(metrics, self.topk, dim=-1, largest=largest)
        if topk_mask is None:
            topk_mask = (topk_metrics.max(-1, keepdim=True)[0] > self.eps).expand_as(topk_idxs)
        # (b, max_num_obj, topk)
        topk_idxs.masked_fill_(~topk_mask, 0)

        # (b, max_num_obj, topk, h*w) -> (b, max_num_obj, h*w)
        count_tensor = torch.zeros(metrics.shape, dtype=torch.int8, device=topk_idxs.device)
        ones = torch.ones_like(topk_idxs[:, :, :1], dtype=torch.int8, device=topk_idxs.device)
        for k in range(self.topk):
            # Expand topk_idxs for each value of k and add 1 at the specified positions
            count_tensor.scatter_add_(-1, topk_idxs[:, :, k : k + 1], ones)
        # count_tensor.scatter_add_(-1, topk_idxs, torch.ones_like(topk_idxs, dtype=torch.int8, device=topk_idxs.device))
        # Filter invalid bboxes
        count_tensor.masked_fill_(count_tensor > 1, 0)

        return count_tensor.to(metrics.dtype)

    def get_targets(self, gt_labels, gt_bboxes, target_gt_idx, fg_mask):
        """
        Compute target labels, target bounding boxes, and target scores for the positive anchor points.

        Args:
            gt_labels (Tensor): Ground truth labels of shape (b, max_num_obj, 1), where b is the
                                batch size and max_num_obj is the maximum number of objects.
            gt_bboxes (Tensor): Ground truth bounding boxes of shape (b, max_num_obj, 4).
            target_gt_idx (Tensor): Indices of the assigned ground truth objects for positive
                                    anchor points, with shape (b, h*w), where h*w is the total
                                    number of anchor points.
            fg_mask (Tensor): A boolean tensor of shape (b, h*w) indicating the positive
                              (foreground) anchor points.

        Returns:
            (Tuple[Tensor, Tensor, Tensor]): A tuple containing the following tensors:
                - target_labels (Tensor): Shape (b, h*w), containing the target labels for
                                          positive anchor points.
                - target_bboxes (Tensor): Shape (b, h*w, 4), containing the target bounding boxes
                                          for positive anchor points.
                - target_scores (Tensor): Shape (b, h*w, num_classes), containing the target scores
                                          for positive anchor points, where num_classes is the number
                                          of object classes.
        """
        # Assigned target labels, (b, 1)
        batch_ind = torch.arange(end=self.bs, dtype=torch.int64, device=gt_labels.device)[..., None]
        target_gt_idx = target_gt_idx + batch_ind * self.n_max_boxes  # (b, h*w)
        target_labels = gt_labels.long().flatten()[target_gt_idx]  # (b, h*w)

        # Assigned target boxes, (b, max_num_obj, 4) -> (b, h*w, 4)
        target_bboxes = gt_bboxes.view(-1, gt_bboxes.shape[-1])[target_gt_idx]

        # Assigned target scores
        target_labels.clamp_(0)

        # 10x faster than F.one_hot()
        target_scores = torch.zeros(
            (target_labels.shape[0], target_labels.shape[1], self.num_classes),
            dtype=torch.int64,
            device=target_labels.device,
        )  # (b, h*w, 80)
        target_scores.scatter_(2, target_labels.unsqueeze(-1), 1)

        fg_scores_mask = fg_mask[:, :, None].repeat(1, 1, self.num_classes)  # (b, h*w, 80)
        target_scores = torch.where(fg_scores_mask > 0, target_scores, 0)

        return target_labels, target_bboxes, target_scores

    def select_candidates_in_gts(self, xy_centers, gt_bboxes, mask_gt, eps=1e-9):
        """
        Select positive anchor centers within ground truth bounding boxes.

        Args:
            xy_centers (torch.Tensor): Anchor center coordinates, shape (h*w, 2).
            gt_bboxes (torch.Tensor): Ground truth bounding boxes, shape (b, n_boxes, 4).
            eps (float, optional): Small value for numerical stability. Defaults to 1e-9.

        Returns:
            (torch.Tensor): Boolean mask of positive anchors, shape (b, n_boxes, h*w).

        Note:
            b: batch size, n_boxes: number of ground truth boxes, h: height, w: width.
            Bounding box format: [x_min, y_min, x_max, y_max].
        """

        if mask_gt is not None:
            gt_bboxes_xywh = xyxy2xywh(gt_bboxes[..., :4])
            wh_mask = gt_bboxes_xywh[..., 2:4] < self.stride[0]  # the smallest stride
            stride_val = torch.tensor(self.stride[1], dtype=gt_bboxes_xywh.dtype, device=gt_bboxes_xywh.device)
            gt_bboxes_xywh[..., 2:4] = torch.where((wh_mask * mask_gt).bool(), stride_val, gt_bboxes_xywh[..., 2:])
            gt_bboxes = xywh2xyxy(gt_bboxes_xywh)

        n_anchors = xy_centers.shape[0]
        bs, n_boxes, _ = gt_bboxes.shape
        lt, rb = gt_bboxes[..., :4].view(-1, 1, 4).chunk(2, 2)  # left-top, right-bottom
        bbox_deltas = torch.cat((xy_centers[None] - lt, rb - xy_centers[None]), dim=2).view(bs, n_boxes, n_anchors, -1)
        # return (bbox_deltas.min(3)[0] > eps).to(gt_bboxes.dtype)
        return bbox_deltas.amin(3).gt_(eps)

    @staticmethod
    def select_highest_overlaps(mask_pos, overlaps, n_max_boxes):
        """
        Select anchor boxes with highest IoU when assigned to multiple ground truths.

        Args:
            mask_pos (torch.Tensor): Positive mask, shape (b, n_max_boxes, h*w).
            overlaps (torch.Tensor): IoU overlaps, shape (b, n_max_boxes, h*w).
            n_max_boxes (int): Maximum number of ground truth boxes.

        Returns:
            target_gt_idx (torch.Tensor): Indices of assigned ground truths, shape (b, h*w).
            fg_mask (torch.Tensor): Foreground mask, shape (b, h*w).
            mask_pos (torch.Tensor): Updated positive mask, shape (b, n_max_boxes, h*w).

        Note:
            b: batch size, h: height, w: width.
        """
        # Convert (b, n_max_boxes, h*w) -> (b, h*w)
        fg_mask = mask_pos.sum(-2)
        if fg_mask.max() > 1:  # one anchor is assigned to multiple gt_bboxes
            mask_multi_gts = (fg_mask.unsqueeze(1) > 1).expand(-1, n_max_boxes, -1)  # (b, n_max_boxes, h*w)
            overlaps[mask_pos.bool()].clamp_(min=1e-6)
            max_overlaps_idx = overlaps.argmax(1)  # (b, h*w)

            is_max_overlaps = torch.zeros(mask_pos.shape, dtype=mask_pos.dtype, device=mask_pos.device)
            is_max_overlaps.scatter_(1, max_overlaps_idx.unsqueeze(1), 1)

            mask_pos = torch.where(mask_multi_gts, is_max_overlaps, mask_pos).float()  # (b, n_max_boxes, h*w)
            fg_mask = mask_pos.sum(-2)
        # Find each grid serve which gt(index)
        target_gt_idx = mask_pos.argmax(-2)  # (b, h*w)
        return target_gt_idx, fg_mask, mask_pos

class RotatedTaskAlignedAssigner(TaskAlignedAssigner):
    """Assigns ground-truth objects to rotated bounding boxes using a task-aligned metric."""

    def iou_calculation(self, gt_bboxes, pd_bboxes):
        # assert gt_bboxes.shape[-1]==pd_bboxes.shape[-1]
        """IoU calculation for rotated bounding boxes."""
        return probiou(gt_bboxes[:,:5], pd_bboxes).squeeze(-1).clamp_(0)
        # elif gt_bboxes.shape[-1]==8: #xyxyxyxy
        #     return probiou(gt_bboxes[:,:5], pd_bboxes).squeeze(-1).clamp_(0)

    @staticmethod
    def select_candidates_in_gts(xy_centers, gt_bboxes):
        """
        Select the positive anchor center in gt for rotated bounding boxes.

        Args:
            xy_centers (Tensor): shape(h*w, 2)
            gt_bboxes (Tensor): shape(b, n_boxes, 5)

        Returns:
            (Tensor): shape(b, n_boxes, h*w)
        """
        # gt_bboxes[b, n_boxes, 5] --> corners[b, n_boxes, 4, 2]
        corners = xywhr2xyxyxyxy(gt_bboxes) # if gt_bboxes.shape[-1]==5 else gt_bboxes.view(gt_bboxes.shape[0],gt_bboxes.shape[1],4,2)
        # (b, n_boxes, 1, 2)
        a, b, _, d = corners.split(1, dim=-2)
        ab = b - a
        ad = d - a

        # (b, n_boxes, h*w, 2)
        ap = xy_centers - a
        norm_ab = (ab * ab).sum(dim=-1)
        norm_ad = (ad * ad).sum(dim=-1)
        ap_dot_ab = (ap * ab).sum(dim=-1)
        ap_dot_ad = (ap * ad).sum(dim=-1)
        return (ap_dot_ab >= 0) & (ap_dot_ab <= norm_ab) & (ap_dot_ad >= 0) & (ap_dot_ad <= norm_ad)  # is_in_box
    
    @staticmethod
    def select_candidates_in_gts_ellipse(xy_centers, gt_bboxes, radius_ratio=1.0):
        """
        Select positive anchor centers within an *elliptical region* around rotated ground-truth boxes.

        Args:
            xy_centers (Tensor): shape (h*w, 2), anchor/grid center points.
            gt_bboxes (Tensor): shape (b, n_boxes, 5), each box = [cx, cy, w, h, angle(rad)].
            radius_ratio (tuple): (rx_ratio, ry_ratio) controlling the ellipse size relative to box size.

        Returns:
            mask_pos (Tensor): shape (b, n_boxes, h*w), indicating positive anchors.
        """
        B, n_boxes, _ = gt_bboxes.shape
        n_anchors = xy_centers.shape[0]
        device = gt_bboxes.device

        # 提取中心、宽高和旋转角
        cx, cy, w, h, theta = gt_bboxes.split(1, dim=-1)  # [B, n_boxes, 1]
        rx = 0.5 * w * radius_ratio
        ry = 0.5 * h * radius_ratio

        # anchor点扩展成 [1,1,N,2]
        xy = xy_centers[None, None, :, :]  # [1,1,N,2]
        dx = xy[..., 0] - cx               # [B, n_boxes, N]
        dy = xy[..., 1] - cy

        # 旋转坐标系：逆时针旋转 -theta，将点旋转回框的局部坐标系
        cos_t = torch.cos(-theta)
        sin_t = torch.sin(-theta)
        local_x = dx * cos_t - dy * sin_t
        local_y = dx * sin_t + dy * cos_t

        # 椭圆方程: (x/rx)^2 + (y/ry)^2 <= 1
        ellipse_mask = (local_x / (rx + 1e-9)) ** 2 + (local_y / (ry + 1e-9)) ** 2 <= 1.0

        # 🔹 可选增强：确保每个 GT 至少有若干候选点
        # 如果一个gt没有任何正样本，可以放宽椭圆半径再试一次
        no_pos = ellipse_mask.sum(-1) == 0  # [B, n_boxes]
        if no_pos.any():
            rx2 = rx * 1.5
            ry2 = ry * 1.5
            local_x2 = dx * cos_t - dy * sin_t
            local_y2 = dx * sin_t + dy * cos_t
            mask_extra = (local_x2 / (rx2 + 1e-9)) ** 2 + (local_y2 / (ry2 + 1e-9)) ** 2 <= 1.0
            ellipse_mask = torch.where(no_pos[..., None], mask_extra, ellipse_mask)

        return ellipse_mask
    
    @staticmethod
    def select_candidates_in_scale(strides, gt_bboxes, double=False):
        """
        Select positive anchor centers within ground truth bounding boxes.

        Args:
            xy_centers (torch.Tensor): Anchor center coordinates, shape (h*w, 2).
            gt_bboxes (torch.Tensor): Ground truth bounding boxes, shape (b, n_boxes, 5).
            eps (float, optional): Small value for numerical stability. Defaults to 1e-9.

        Returns:
            (torch.Tensor): Boolean mask of positive anchors, shape (b, n_boxes, h*w).

        Note:
            b: batch size, n_boxes: number of ground truth boxes, h: height, w: width.
            Bounding box format: [x_min, y_min, x_max, y_max].
        """
        strides = strides.repeat(1, 2)  # na, 2
        n_anchors = strides.shape[0]
        bs, n_boxes, _ = gt_bboxes.shape
        _, wh = gt_bboxes[..., :4].view(-1, 1, 4).chunk(2, 2)  # left-top, right-bottom
        wh = wh * (2 if double else 1)
        max_scales = (wh / strides[None]).view(bs, n_boxes, n_anchors, -1).amax(-1)
        return (max_scales >= 1) & (max_scales <= 16)

    
    def get_pos_mask(self, pd_scores, pd_bboxes, gt_labels, gt_bboxes, anc_points, mask_gt, strides,ellipse_radius_ratio=0.0):
        # Get in_gts mask, (b, max_num_obj, h*w). pd_bboxes[b,nttoal,5(xywhr)]  gt_bboxes[b,n_max,5(xywhr) + 2+nf*4]
        # 获取 anc_points 和 gt_bboxes(A-左上)/(右下-A) 中心在目标内 pixel的点阵 mask
        if ellipse_radius_ratio > 0.01:
            mask_in_gts = self.select_candidates_in_gts_ellipse(anc_points, gt_bboxes, radius_ratio=ellipse_radius_ratio) #anc_points[ntotal,2] gt_bboxes[b,nt,4]-> mask_in_gts[b,nt,ntotal]
        else:
            mask_in_gts = self.select_candidates_in_gts(anc_points, gt_bboxes[...,:5]) #mask_in_gts[b,n_max,ntotal]

        # get right scale
        mask_in_scale = self.select_candidates_in_scale(strides, gt_bboxes) #gt_bboxes[b,n_max,5(xywhr) + 4(xyxy) + 2+nf*4]

        # Get anchor_align metric, (b, max_num_obj, h*w) 
        # 根据 gt 和 pd 得到每个batch的每个gt对应每个格子的 align_metric = scores^alpha * overlaps^beta
        align_metric, overlaps = self.get_box_metrics(pd_scores, pd_bboxes, gt_labels, gt_bboxes, mask_in_gts * mask_gt)
        # Get topk_metric mask, (b, max_num_obj, h*w)
        # 选取topk, mask_gt[bs, n_max_boxes, 1] --> topk_mask[bs, n_max_boxes, topk]
        mask_topk = self.select_topk_candidates(align_metric, mask_in_scale, topk_mask=mask_gt.expand(-1, -1, self.topk).bool())
        # Merge all mask to a final mask, (b, max_num_obj, h*w)
        mask_pos = mask_topk * mask_in_gts * mask_gt

        return mask_pos, align_metric, overlaps
    
    def select_topk_candidates(self, metrics, mask_scale, largest=True, topk_mask=None, method=1):
        """
        Select the top-k candidates based on the given metrics.

        Args:
            metrics (Tensor): A tensor of shape (b, max_num_obj, h*w), where b is the batch size,
                              max_num_obj is the maximum number of objects, and h*w represents the
                              total number of anchor points.
            largest (bool): If True, select the largest values; otherwise, select the smallest values.
            topk_mask (Tensor): An optional boolean tensor of shape (b, max_num_obj, topk), where
                                topk is the number of top candidates to consider. If not provided,
                                the top-k values are automatically computed based on the given metrics.

        Returns:
            (Tensor): A tensor of shape (b, max_num_obj, h*w) containing the selected top-k candidates.
        """
        if method == 0:
            # (b, max_num_obj, topk)
            metrics = metrics.clone()
            metrics[mask_scale] *= 1.5
            topk_metrics, topk_idxs = torch.topk(metrics, self.topk, dim=-1, largest=largest)
            if topk_mask is None:
                topk_mask = (topk_metrics.max(-1, keepdim=True)[0] > self.eps).expand_as(topk_idxs)
            # (b, max_num_obj, topk)
            topk_idxs.masked_fill_(~topk_mask, 0)

            # (b, max_num_obj, topk, h*w) -> (b, max_num_obj, h*w)
            count_tensor = torch.zeros(metrics.shape, dtype=torch.int8, device=topk_idxs.device)
            ones = torch.ones_like(topk_idxs[:, :, :1], dtype=torch.int8, device=topk_idxs.device)
            for k in range(self.topk):
                # Expand topk_idxs for each value of k and add 1 at the specified positions
                count_tensor.scatter_add_(-1, topk_idxs[:, :, k : k + 1], ones)
            # count_tensor.scatter_add_(-1, topk_idxs, torch.ones_like(topk_idxs, dtype=torch.int8, device=topk_idxs.device))
            # Filter invalid bboxes
            count_tensor.masked_fill_(count_tensor > 1, 0)

            return count_tensor.to(metrics.dtype)
        else:
            count_tensor = torch.zeros(metrics.shape, dtype=torch.int8, device=metrics.device)
            nowcc_tensor = count_tensor[:, :1, :].clone()
            ones = torch.ones_like(count_tensor[:, :1, :self.topk], dtype=torch.int8, device=metrics.device)
            topk_metrics_, topk_idxs_ = torch.topk(metrics, self.topk, dim=-1, largest=largest)
            topk_metrics, topk_idxs = topk_metrics_.clone(), topk_idxs_.clone()
            for n in range(count_tensor.shape[1]):
                metric = metrics[:, n:n+1, :].clone().masked_fill_(nowcc_tensor.bool(), 0)
                metric[mask_scale[:, n:n+1, :]] *= 1.5
                topk_metrics[:, n:n+1, :], topk_idxs[:, n:n+1, :] = torch.topk(metric, self.topk, dim=-1, largest=largest)
                if topk_mask is None:
                    topk_mask_ = (topk_metrics[:, n:n+1, :].max(-1, keepdim=True)[0] > self.eps).expand_as(topk_idxs)
                else:
                    topk_mask_ = topk_mask[:, n:n+1, :]
                topk_idxs[:, n:n+1, :].masked_fill_(~topk_mask_, 0)
                nowcc_tensor.scatter_add_(-1, topk_idxs[:, n:n+1, :], ones)
                nowcc_tensor.masked_fill_(nowcc_tensor > 1, 0)
                count_tensor[:, n:n+1, :].scatter_add_(-1, topk_idxs[:, n:n+1, :], ones)
            return count_tensor.to(metrics.dtype)

    @torch.no_grad()
    def forward(self, pd_scores, pd_bboxes, anc_points, gt_labels, gt_bboxes, mask_gt, strides):
        # Compute the task-aligned assignment. Reference code is available at
        # https://github.com/Nioolek/PPYOLOE_pytorch/blob/master/ppyoloe/assigner/tal_assigner.py.
        # Args:
        #     pd_scores[bs, num_total_anchors, num_classes]
        #     pd_bboxes[bs, num_total_anchors, 5(xywhr)]
        #     anc_points[num_total_anchors, 2]
        #     gt_labels[bs, n_max_boxes, 1]
        #     gt_bboxes[bs, n_max_boxes, 5(xywhr)]
        #     mask_gt[bs, n_max_boxes, 1]
        # Returns:
        #     target_labels[bs, num_total_anchors]
        #     target_bboxes[bs, num_total_anchors, 4]
        #     target_scores[bs, num_total_anchors, num_classes]
        #     fg_mask[bs, num_total_anchors]
        #     target_gt_idx[bs, num_total_anchors]
        self.bs = pd_scores.shape[0]
        self.n_max_boxes = gt_bboxes.shape[1]

        if self.n_max_boxes == 0:
            device = gt_bboxes.device
            return (
                torch.full_like(pd_scores[..., 0], self.bg_idx).to(device),
                torch.zeros_like(pd_bboxes).to(device),
                torch.zeros_like(pd_scores).to(device),
                torch.zeros_like(pd_scores[..., 0]).to(device).bool(),
                torch.zeros_like(pd_scores[..., 0]).to(device),
            )

        mask_pos, align_metric, overlaps = self.get_pos_mask(
            pd_scores, pd_bboxes, gt_labels, gt_bboxes, anc_points, mask_gt, strides, ellipse_radius_ratio=0
        )#->mask_pos[b,nt,ntotal] align_metric[b,nt,ntotal] overlaps[b,nt,ntotal]

        target_gt_idx, fg_mask, mask_pos = self.select_highest_overlaps(mask_pos, overlaps, self.n_max_boxes) #target_gt_idx[b,ntotal] fg_mask[b,ntotal] mask_pos[b,nt,ntotal]

        # Assigned target
        target_labels, target_bboxes, target_scores = self.get_targets(gt_labels, gt_bboxes, target_gt_idx, fg_mask) #target_labels[B,ntotal] target_bboxes[B,ntotal,4(xyxy)] target_scores[B,ntotal,cls]

        # Normalize
        align_metric *= mask_pos
        pos_align_metrics = align_metric.amax(dim=-1, keepdim=True)  # b, max_num_obj
        pos_overlaps = (overlaps * mask_pos).amax(dim=-1, keepdim=True)  # b, max_num_obj
        norm_align_metric = (align_metric * pos_overlaps / (pos_align_metrics + self.eps)).amax(-2).unsqueeze(-1)
        target_scores = target_scores * norm_align_metric

        return target_labels, target_bboxes, target_scores, fg_mask.bool(), target_gt_idx #target_labels[b,ntotal] target_bboxes[b,ntotal,4(xyxy)] target_scores[b,ntotal,cls] fg_mask[b,ntotal] target_gt_idx[b,ntotal]
    
    def ensure_gt_has_positive(self, mask_pos, overlaps):
        # Ensure every GT has at least one positive anchor.
        # Args:
        #     mask_pos: [B, N_gt, N_anchors] bool/float
        #     overlaps: [B, N_gt, N_anchors] IoU or similar metric
        # Returns:
        #     mask_pos: updated mask
        no_pos = (mask_pos.sum(-1) == 0)  # [B, N_gt]
        if not no_pos.any():
            return mask_pos

        # 拿出没有正样本的 (b,g)
        b_idx, g_idx = torch.nonzero(no_pos, as_tuple=True)
        # 每个 GT 找 IoU 最大的 anchor
        max_iou_idx = overlaps.argmax(-1)
        best_anchor = max_iou_idx[b_idx, g_idx]

        # 选取 IoU 过低的跳过（防止错误补配）
        valid_mask = overlaps[b_idx, g_idx, best_anchor] > 0.05
        b_idx, g_idx, best_anchor = b_idx[valid_mask], g_idx[valid_mask], best_anchor[valid_mask]

        # 清零再设置
        mask_pos[b_idx, g_idx, :] = 0
        mask_pos[b_idx, g_idx, best_anchor] = 1
        return mask_pos

def dist2bbox(distance, anchor_points, xywh=True, dim=-1):#anchor_points[ntotal,2] + distance[b,ntotal,4(ltrb)]->[b,ntotal,4(xyxy)]
    """Transform distance(ltrb) to box(xywh or xyxy)."""
    lt, rb = distance.chunk(2, dim) #lt[b,ntotal,2(lt)] rb[b,ntotal,2(rb)]
    x1y1 = anchor_points - lt #x1y1[b,ntotal,2(lt)]
    x2y2 = anchor_points + rb #x2y2[b,ntotal,2(rb)]
    if xywh:
        c_xy = (x1y1 + x2y2) / 2
        wh = x2y2 - x1y1
        return torch.cat((c_xy, wh), dim)  #xywh[b,ntotal,4]
    return torch.cat((x1y1, x2y2), dim)  #x1y1x2y2[b,ntotal,4]
def bbox2dist(anchor_points, bbox, reg_max):
    """Transform bbox(xyxy) to dist(ltrb)."""
    x1y1, x2y2 = bbox.chunk(2, -1)
    return torch.cat((anchor_points - x1y1, x2y2 - anchor_points), -1).clamp_(0, reg_max -1 - 0.01)

def dist2rbox(pred_dist, pred_angle, anchor_points, dim=-1):
    """
    Decode predicted rotated bounding box coordinates from anchor points and distribution.

    Args:
        pred_dist (torch.Tensor): Predicted rotated distance, shape (bs, h*w, 4).
        pred_angle (torch.Tensor): Predicted angle, shape (bs, h*w, 1).
        anchor_points (torch.Tensor): Anchor points, shape (h*w, 2).
        dim (int, optional): Dimension along which to split. Defaults to -1.

    Returns:
        (torch.Tensor): Predicted rotated bounding boxes, shape (bs, h*w, 4).
    """
    lt, rb = pred_dist.split(2, dim=dim) #pred_dist[b,ntotal,4] -> lt[b,ntotal,2],rb[b,ntotal,2]
    cos, sin = torch.cos(pred_angle), torch.sin(pred_angle)
    # (bs, h*w, 1)
    xf, yf = ((rb - lt) / 2).split(1, dim=dim)
    x, y = xf * cos - yf * sin, xf * sin + yf * cos
    xy = torch.cat([x, y], dim=dim) + anchor_points
    return torch.cat([xy, lt + rb], dim=dim)
def rbox2dist(anchor_points, bbox, reg_max, dfl_neg_offset=0): #anchor_points[b,ntotal,2] bbox[b,ntotal,4(xyxy)+1(angle)]
    """Transform bbox(xyxy) to dist(ltrb)."""
    # angle = bbox[...,-1:] #angle[b,ntotal,1]
    x, y, w, h, angle = bbox.chunk(5, -1)
    anchor_points = anchor_points[None]
    cosr,sinr = torch.cos(angle),torch.sin(angle) #[b,ntotal,1],[b,ntotal,1]
    # x1y1, x2y2 = bbox[...,:4].chunk(2, -1) #x1y1[b,ntotal,2] x2y2[b,ntotal,2]
    dx, dy = x - anchor_points[..., :1], y - anchor_points[..., 1:]
    xp, yp = cosr*dx+sinr*dy, -sinr*dx+cosr*dy
    left = xp - w / 2
    top = yp - h / 2
    right = xp + w / 2
    bottom = yp + h / 2
    ltrb = torch.cat((-left, -top, right, bottom), -1)
    return ltrb.clamp_(-dfl_neg_offset, reg_max - 1 - dfl_neg_offset - 0.01)