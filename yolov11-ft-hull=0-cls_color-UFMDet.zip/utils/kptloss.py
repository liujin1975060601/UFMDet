# @article{FourierDetByJinLiu,
#     author  = "Jin Liu; Zhongyuan Lu; Yaorong Cen; Hui Hu; Zhenfeng Shao; Yong Hong, Ming Jiang, Miaozhong Xu",
#     title   = "Enhancing Object Detection With Fourier Series",
#     year    = "January 8, 2025",
#     journal = "IEEE Transactions on Pattern Analysis and Machine Intelligence",
#     volume  = "47",
#     number  = "4",
#     pages   = "2581 - 2596",
#     doi = 10.1109/TPAMI.2025.3526990,
#     month   = "January",
# }
# @article{FourierDetByJinLiu,
#     author  = "Jin Liu, Huan Li, Zhenfeng Shao, Biyin Zhang, Mi Wang",
#     title   = "UFMDet: Unified Fourier Multi-shape Detection for Blob-like and Line-like Objects in Natural Scenes",
#     Submit to "IEEE Transactions on Pattern Analysis and Machine Intelligence",
# }
import torch
import torch.nn as nn

def fft_areas(ft_labels): #ft_labels[n_obj, 2+4n] -> areas[n_obj] 计算多个傅里叶闭合曲线的面积
    n_obj, dim = ft_labels.shape
    n = (dim - 2) // 4  # 傅里叶阶数
    # 取出 an, bn, cn, dn  [n_obj, n]
    coeffs = ft_labels[:, 2:].reshape(n_obj, n, 4)
    an, bn, cn, dn = coeffs[..., 0], coeffs[..., 1], coeffs[..., 2], coeffs[..., 3]
    # 权重 k = 1..n
    k = torch.arange(1, n+1, dtype=ft_labels.dtype, device=ft_labels.device)
    # 面积公式: π * Σ k * (an*dn - bn*cn)
    areas = torch.pi * ((an * dn - bn * cn) * k).sum(dim=1)
    return areas #[n_obj]

def fft_perimeter_approx1(ft_labels):
    # 一阶能量近似周长 L ≈ 2π sqrt( Σ k² (a² + b² + c² + d²) )
    n_obj, dim = ft_labels.shape
    n = (dim - 2) // 4

    coeffs = ft_labels[:, 2:].reshape(n_obj, n, 4)
    a, b, c, d = coeffs[..., 0], coeffs[..., 1], coeffs[..., 2], coeffs[..., 3]

    k = torch.arange(1, n+1, dtype=ft_labels.dtype, device=ft_labels.device)

    energy = (a*a + b*b + c*c + d*d) * (k*k)

    L = 2 * torch.pi * torch.sqrt(energy.sum(dim=1))
    return L

class KeypointLoss(nn.Module):
    """Criterion class for computing keypoint losses."""

    def __init__(self) -> None:
        """Initialize the KeypointLoss class with keypoint sigmas."""
        super().__init__()
        self.cossin_buffer = None    # [nf * 2, num]

    def ft2kpt(self, fts, num):
        # fts [nt, 2+4*nf]
        # x(theta) = a0 + a1*cos(theta) + b1*sin(theta) .... + an*cos(n*theta)+ bn*cos(n*theta)
        # y(theta) = c0 + c1*cos(theta) + d1*sin(theta) .... + cn*cos(n*theta)+ dn*cos(n*theta)
        if (self.cossin_buffer is None) or (self.cossin_buffer.shape[0] != num) or (self.cossin_buffer.shape[1] != ((fts.shape[-1] - 2) / 4)):
            nf = int((fts.shape[-1] - 2) / 4)
            theta = torch.arange(0, num, dtype=fts.dtype, device=fts.device) / num * 2 * torch.pi   # [num]
            theta = theta[:, None] * (torch.arange(0, nf, dtype=fts.dtype, device=fts.device) + 1)[None, :] #theta[num, nf]
            self.cossin_buffer = torch.stack([torch.cos(theta), torch.sin(theta)], dim=-1).reshape(num, -1).T.contiguous() # [num, nf, 2(cos,sin)]-->[num,nf*2]-->[nf*2,num]
        fts_ab, fts_cd = fts[..., 2:].reshape(fts.shape[0], -1, 2, 2).chunk(2, dim=-2) #fts_ab[nt,nf,2] fts_cd[nt,nf,2]
        kpt_points_x = fts_ab.reshape(fts.shape[0], -1) @ self.cossin_buffer # + fts[..., 0:1]  fts_ab[nt, 2*nf] @ [2*nf, num] --> kpt_points_x[nt, num]
        kpt_points_y = fts_cd.reshape(fts.shape[0], -1) @ self.cossin_buffer # + fts[..., 1:2]  fts_cd[nt, 2*nf] @ [2*nf, num] --> kpt_points_y[nt, num]
        kpt_points = torch.stack([kpt_points_x, kpt_points_y], dim=-1) #kpt_points[nt,num,2]
        return kpt_points #kpt_points[nt,num,2]

    def forward(
        self, preds: torch.Tensor, gts: torch.Tensor, #preds[nt,2+nf*4] gts[nt,2+nf*4]
        mask_line: torch.Tensor,
        sigmas: torch.Tensor=None, kpt_mask: torch.Tensor=None
    ):
        """Calculate keypoint loss factor and Euclidean distance loss for keypoints."""
        nf = int((gts.shape[-1] - 2) / 4)
        num = nf * 2
        pred_kpts = self.ft2kpt(preds, num) #pred_kpts[nt,num,2]
        gt_kpts = self.ft2kpt(gts, num)     #gt_kpts[nt,num,2]
        #
        if mask_line is not None:
            area = torch.zeros(gts.shape[0],1,device=gts.device) #area[nt,1]
            area[~mask_line,0] = fft_areas(gts[~mask_line]) #area[nt_~mask_line,1]
            # area[mask_line,0] = fft_perimeter_approx1(gts[mask_line]) #area[nt_mask_line,1]
            # area[mask_line,0] = torch.sqrt(((torch.diff(gt_kpts[mask_line], dim=1) ** 2).sum(dim=(-1,-2)))) / 2 # (sqrt((xn-xn_1)^2 + (yn-yn_1)^2)).sum() / 2
            area[mask_line,0] = torch.sqrt(((torch.diff(gt_kpts[mask_line], dim=1) ** 2).sum(dim=-1))).sum(dim=-1) / 2 # (sqrt((xn-xn_1)^2 + (yn-yn_1)^2)).sum() / 2
        else:
            area = fft_areas(gts)[:, None] #area[nt,1]
        d = (pred_kpts[..., 0] - gt_kpts[..., 0]).pow(2) + (pred_kpts[..., 1] - gt_kpts[..., 1]).pow(2) #d[nt,num]
        if sigmas is None:
            sigmas = torch.full_like(gt_kpts[..., 0], 0.1) #sigmas[nt,num]=0.1
        if kpt_mask is None:
            kpt_mask = gt_kpts[..., 2] != 0 if gt_kpts.shape[-1] == 3 else torch.full_like(gt_kpts[..., 0], True) #kpt_mask[nt,num]=True
        kpt_loss_factor = kpt_mask.shape[1] / (torch.sum(kpt_mask != 0, dim=1) + 1e-9)
        # e = d / (2 * (area * self.sigmas) ** 2 + 1e-9)  # from formula
        e = d / ((2 * sigmas).pow(2) * (area + 1e-9) * 2)  # from cocoeval
        return (kpt_loss_factor.view(-1, 1) * ((1 - torch.exp(-e)) * kpt_mask)).mean()