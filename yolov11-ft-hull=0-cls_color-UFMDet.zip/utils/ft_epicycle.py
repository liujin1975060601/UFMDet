"""提供将傅里叶 Epicycle（谐波圆圈）直接绘制在图像上的工具函数。"""
# @article{FourierDetByJinLiu,
#     author  = "Jin Liu; Zhongyuan Lu; Yaorong Cen; Hui Hu; Zhenfeng Shao; Yong Hong, Ming Jiang, Miaozhong Xu",
#     title   = "Enhancing Object Detection With Fourier Series",
#     year    = "January 8, 2025",
#     journal = "IEEE Transactions on Pattern Analysis and Machine Intelligence",
#     volume  = "47",
#     number  = "4",
#     pages   = "2581 - 2596",
#     doi = 10.1109/TPAMI.2025.3526990,
#     month   = "January",
# }
# @article{FourierDetByJinLiu,
#     author  = "Jin Liu, Huan Li, Zhenfeng Shao, Biyin Zhang, Mi Wang",
#     title   = "UFMDet: Unified Fourier Multi-shape Detection for Blob-like and Line-like Objects in Natural Scenes",
#     Submit to "IEEE Transactions on Pattern Analysis and Machine Intelligence",
# }
from typing import Iterable, Dict, Tuple, Optional

import cv2
import numpy as np

def _coeffs_to_abcd(coeffs: Iterable[float]) -> np.ndarray:
    coeffs = np.asarray(coeffs, dtype=np.float64)
    if coeffs.size < 2 or (coeffs.size - 2) % 4 != 0:
        raise ValueError("coeffs 长度应满足 2 + 4n 的结构")
    order = (coeffs.size - 2) // 4
    abcd = np.zeros((order + 1, 4), dtype=np.float64)
    abcd[0, 0] = coeffs[0]
    abcd[0, 2] = coeffs[1]
    offset = 2
    for i in range(1, order + 1):
        abcd[i] = coeffs[offset : offset + 4]
        offset += 4
    return abcd


def _build_full_complex_coeffs(abcd: np.ndarray) -> np.ndarray:
    order = abcd.shape[0] - 1
    c_vec = np.zeros(2 * order + 1, dtype=np.complex128)
    zero_coeff = abcd[0]
    c_vec[order] = zero_coeff[0] + 1j * zero_coeff[2]
    for n in range(1, order + 1):
        a, b, c_val, d = abcd[n]
        pos = 0.5 * complex(a + d, c_val - b)
        neg = 0.5 * complex(a - d, c_val + b)
        c_vec[order + n] = pos
        c_vec[order - n] = neg
    return c_vec


def _fourier_dict(c_vec: np.ndarray) -> Dict[int, complex]:
    half = len(c_vec) // 2
    freqs = np.arange(-half, half + 1)
    return dict(zip(freqs, c_vec))


def _frequency_order(freqs: Iterable[int]) -> Iterable[int]:
    return sorted(freqs, key=lambda n: (abs(n), 0 if n >= 0 else 1))


def _epicycle_snapshot(coeffs: Dict[int, complex], t: float):
    base_point = coeffs.get(0, 0.0 + 0.0j)
    centers = []
    radii = []
    starts = []
    ends = []
    cumulative = base_point
    ordered = list(_frequency_order(k for k in coeffs.keys() if k != 0))
    for n in ordered:
        cn = coeffs[n]
        vec = cn * np.exp(1j * n * t)
        new_point = cumulative + vec
        centers.append(cumulative)
        radii.append(abs(cn))
        starts.append(cumulative)
        ends.append(new_point)
        cumulative = new_point
    return np.asarray(centers), np.asarray(radii), np.asarray(starts), np.asarray(ends), cumulative, base_point, ordered

def _complex_to_point(z: complex) -> Tuple[int, int]:
    return int(round(z.real)), int(round(z.imag))


_CYCLE_COLORS = [
    (255, 99, 71),   # tomato
    (135, 206, 235), # skyblue
    (144, 238, 144), # lightgreen
    (238, 130, 238), # violet
    (255, 215, 0),   # gold
    (70, 130, 180),  # steelblue
    (255, 182, 193), # lightpink
    (173, 216, 230), # light blue
    (152, 251, 152), # pale green
    (255, 160, 122), # light salmon
]
def draw_epicycle_circles(
    img: np.ndarray,
    coeffs: Iterable[float],
    t: float,
    thickness: int = 1,
    base_color: Tuple[int, int, int] = (255, 255, 255),
) -> None:
    """绘制多色 epicycle，每一阶圆圈使用不同颜色。"""

    if img is None:
        raise ValueError("img 不能为空")

    abcd = _coeffs_to_abcd(coeffs)
    c_vec = _build_full_complex_coeffs(abcd)
    freq_map = _fourier_dict(c_vec)
    centers, radii, starts, ends, endpoint, base_point, ordered = _epicycle_snapshot(freq_map, t)

    if np.isfinite(base_point.real) and np.isfinite(base_point.imag):
        bx, by = _complex_to_point(base_point)
        cv2.circle(img, (bx, by), thickness + 2, base_color, -1, lineType=cv2.LINE_AA)
        cv2.circle(img, (bx, by), thickness + 2, (0, 0, 0), 1, lineType=cv2.LINE_AA)

    for idx, (center, radius) in enumerate(zip(centers, radii)):
        if not np.isfinite(radius) or radius <= 0:
            continue
        if not np.isfinite(center.real) or not np.isfinite(center.imag):
            continue
        color = _CYCLE_COLORS[idx % len(_CYCLE_COLORS)]
        cx, cy = _complex_to_point(center)
        cv2.circle(img, (cx, cy), max(1, int(round(radius))), color, thickness, lineType=cv2.LINE_AA)

    for idx, (start, end) in enumerate(zip(starts, ends)):
        if not (np.isfinite(start.real) and np.isfinite(start.imag) and np.isfinite(end.real) and np.isfinite(end.imag)):
            continue
        color = _CYCLE_COLORS[idx % len(_CYCLE_COLORS)]
        sx, sy = _complex_to_point(start)
        ex, ey = _complex_to_point(end)
        cv2.line(img, (sx, sy), (ex, ey), color, thickness, cv2.LINE_AA)

    if np.isfinite(endpoint.real) and np.isfinite(endpoint.imag):
        ex, ey = _complex_to_point(endpoint)
        cv2.circle(img, (ex, ey), thickness + 2, base_color, -1, lineType=cv2.LINE_AA)
        cv2.circle(img, (ex, ey), thickness + 2, (0, 0, 0), 1, lineType=cv2.LINE_AA)



def init_epicycle_data(coeffs: Iterable[float]) -> Tuple[np.ndarray, Dict[int, complex]]:
    """初始化与时间t无关的数据"""
    abcd = _coeffs_to_abcd(coeffs)
    c_vec = _build_full_complex_coeffs(abcd)
    freq_map = _fourier_dict(c_vec)
    return freq_map

def draw_epicycle_frame(
    img: np.ndarray,
    coeffs: Iterable[float],
    t: float,
    thickness: int = 1,
    base_color: Tuple[int, int, int] = (255, 255, 255),
    precomputed: Optional[Dict[int, complex]] = None
) -> None:
    """绘制单个时间点的epicycle图像"""
    if precomputed is None:
        freq_map = init_epicycle_data(coeffs)
    else:
        freq_map = precomputed
    
    centers, radii, starts, ends, endpoint, base_point, ordered = _epicycle_snapshot(freq_map, t)

    if np.isfinite(base_point.real) and np.isfinite(base_point.imag):
        bx, by = _complex_to_point(base_point)
        cv2.circle(img, (bx, by), thickness + 2, base_color, -1, lineType=cv2.LINE_AA)
        cv2.circle(img, (bx, by), thickness + 2, (0, 0, 0), 1, lineType=cv2.LINE_AA)

    for idx, (center, radius) in enumerate(zip(centers, radii)):
        if not np.isfinite(radius) or radius <= 0:
            continue
        if not np.isfinite(center.real) or not np.isfinite(center.imag):
            continue
        color = _CYCLE_COLORS[idx % len(_CYCLE_COLORS)]
        cx, cy = _complex_to_point(center)
        cv2.circle(img, (cx, cy), max(1, int(round(radius))), color, thickness, lineType=cv2.LINE_AA)

    for idx, (start, end) in enumerate(zip(starts, ends)):
        if not (np.isfinite(start.real) and np.isfinite(start.imag) and np.isfinite(end.real) and np.isfinite(end.imag)):
            continue
        color = _CYCLE_COLORS[idx % len(_CYCLE_COLORS)]
        sx, sy = _complex_to_point(start)
        ex, ey = _complex_to_point(end)
        cv2.line(img, (sx, sy), (ex, ey), color, thickness, cv2.LINE_AA)

    if np.isfinite(endpoint.real) and np.isfinite(endpoint.imag):
        ex, ey = _complex_to_point(endpoint)
        cv2.circle(img, (ex, ey), thickness + 2, base_color, -1, lineType=cv2.LINE_AA)
        cv2.circle(img, (ex, ey), thickness + 2, (0, 0, 0), 1, lineType=cv2.LINE_AA)

def generate_epicycle_video(
    img_bk: None,
    coeffs: Iterable[float],
    output_path: str,
    fps: int = 30,
    num_frames: int = 300,
    thickness: int = 1,
    base_color: Tuple[int, int, int] = (255, 255, 255)
) -> None:
    """生成傅里叶圆圈动画并保存为视频文件"""
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    img_size = (img_bk.shape[1],img_bk.shape[0])
    video_writer = cv2.VideoWriter(output_path, fourcc, float(fps), img_size)

    # 初始化傅里叶系数相关数据
    precomputed = init_epicycle_data(coeffs.cpu().numpy())

    for t in np.linspace(0, 2 * np.pi, num_frames):
        img = img_bk.copy() if img_bk is not None else np.zeros((img_size[1], img_size[0], 3), dtype=np.uint8)
        draw_epicycle_frame(img, coeffs, t, thickness, base_color, precomputed)
        video_writer.write(img)

    video_writer.release()

