import torch
import torch.nn as nn

def prune_yolov5_by_magnitude(model, prune_ratio=0.2):
    """
    专门为YOLOv5设计的按比例剪枝函数
    
    Args:
        model: 训练好的YOLOv5模型
        prune_ratio: 要剪枝的权重比例 (0-1)
    
    Returns:
        model: 原地剪枝后的模型
    """
    # 不创建新实例，直接修改原模型
    all_weights = []
    
    # 收集所有权重（排除BN层的weight，因为它们尺度不同）
    for name, param in model.named_parameters():
        if 'weight' in name and param.dim() > 1 and 'bn' not in name:
            all_weights.append(param.data.abs().view(-1))
    
    if not all_weights:
        print("未找到可剪枝的权重")
        return model
    
    # 计算全局阈值
    all_weights = torch.cat(all_weights)
    threshold = torch.quantile(all_weights, prune_ratio)
    
    print(f"全局剪枝阈值: {threshold:.6f}")
    print(f"目标剪枝比例: {prune_ratio*100:.1f}%")
    
    # 应用剪枝
    total_params = 0
    pruned_params = 0
    
    for name, param in model.named_parameters():
        if 'weight' in name and param.dim() > 1 and 'bn' not in name:
            total_params += param.numel()
            mask = param.data.abs() > threshold
            current_pruned = (mask == 0).sum().item()
            pruned_params += current_pruned
            param.data.mul_(mask.float())
            
            print(f"层 {name}: 剪枝 {current_pruned}/{param.numel()} "
                  f"({current_pruned/param.numel()*100:.1f}%)")
    
    print(f"总参数数: {total_params}")
    print(f"剪枝参数数: {pruned_params}")
    print(f"实际剪枝比例: {pruned_params/total_params*100:.2f}%")
    
    return model

def prune_yolov5_by_threshold(model, threshold=0.01):
    """
    专门为YOLOv5设计的按阈值剪枝函数
    
    Args:
        model: 训练好的YOLOv5模型
        threshold: 绝对值阈值
    """
    print(f"使用阈值剪枝: {threshold}")
    
    total_params = 0
    pruned_params = 0
    
    for name, param in model.named_parameters():
        if 'weight' in name and param.dim() > 1 and 'bn' not in name:
            total_params += param.numel()
            mask = param.data.abs() > threshold
            current_pruned = (mask == 0).sum().item()
            pruned_params += current_pruned
            param.data.mul_(mask.float())
            
            print(f"层 {name}: 剪枝 {current_pruned}/{param.numel()} "
                  f"({current_pruned/param.numel()*100:.1f}%)")
    
    print(f"总参数数: {total_params}")
    print(f"剪枝参数数: {pruned_params}")
    print(f"剪枝比例: {pruned_params/total_params*100:.2f}%")
    
    return model

def safe_prune_yolov5(model, prune_ratio=0.1, method='magnitude'):
    """
    安全的YOLOv5剪枝函数，避免配置文件问题
    """
    # 保存原始状态用于恢复（如果需要）
    original_state = {name: param.data.clone() for name, param in model.named_parameters()}
    
    try:
        if method == 'magnitude':
            return prune_yolov5_by_magnitude(model, prune_ratio)
        elif method == 'threshold':
            return prune_yolov5_by_threshold(model, prune_ratio)
        else:
            raise ValueError("方法必须是 'magnitude' 或 'threshold'")
            
    except Exception as e:
        print(f"剪枝过程中出错: {e}")
        print("恢复原始权重...")
        # 恢复原始权重
        for name, param in model.named_parameters():
            if name in original_state:
                param.data = original_state[name]
        return model