import torch
import torch.nn as nn
from tqdm import tqdm
import numpy as np
import matplotlib.pyplot as plt

import os
import sys
# 获取当前文件的绝对路径
current_file = os.path.abspath(__file__)
# 获取项目根目录（根据你的实际情况调整层级）
# 如果当前在 yyyy 文件夹下，根目录就是父目录
project_root = os.path.dirname(os.path.dirname(current_file))
# 添加根目录到Python路径
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from utils.general import check_dataset,check_img_size

from utils.loss import ComputeLoss

class GradientAnalyzer:
    def __init__(self, model, dataloader):
        self.model = model
        self.dataloader = dataloader
        self.gradient_stats = {}
        self.hook_handles = []
        
    def register_hooks(self):
        """为卷积层注册梯度hook - 修复版本"""
        self.gradient_stats.clear()
        
        def make_hook(name):
            def hook(module, grad_input, grad_output):
                if grad_output[0] is not None:
                    try:
                        # 关键修复：使用detach和clone避免视图问题
                        grad = grad_output[0].detach().clone()
                        grad_norm = grad.norm().item()
                        if name not in self.gradient_stats:
                            self.gradient_stats[name] = []
                        self.gradient_stats[name].append(grad_norm)
                    except Exception as e:
                        print(f"梯度hook错误 {name}: {e}")
            return hook
        
        # 为所有卷积层注册hook
        for name, module in self.model.named_modules():
            if isinstance(module, nn.Conv2d):
                hook = make_hook(name)
                # 使用register_full_backward_hook避免警告，但设置prepend=False
                handle = module.register_full_backward_hook(hook, prepend=False)
                self.hook_handles.append(handle)
                print(f"注册梯度监控: {name}")
    
    def remove_hooks(self):
        """移除所有hook"""
        for handle in self.hook_handles:
            handle.remove()
        self.hook_handles.clear()
    
    def analyze_gradients(self, num_batches=0):
        """分析梯度并计算层重要性 - 修复版本"""
        self.register_hooks()
        
        self.model.train()  # 设置为训练模式以获取梯度
        self.model.requires_grad_(True)
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        hyp = self.model.hyp
        compute_loss = ComputeLoss(self.model,assigner_one2one=hyp.get('assigner_one2one',0),keep_all=hyp.get('keep_all',0),ellipse_radius_ratio=hyp.get('ellipse_radius_ratio',0.0)) # init loss class
        
        batch_count = 0
        with tqdm(total=num_batches, desc="分析梯度") as pbar:
            nb = len(self.dataloader)  # number of batches
            for batch_i, (imgs, targets, paths, _) in enumerate(self.dataloader):
                if num_batches>0 and batch_i >= num_batches:
                    break
                    
                imgs = imgs.to(device, non_blocking=True).float() / 255.0
                
                # 关键修复1：在前向传播时确保输出安全
                pred = self.safe_forward(imgs)
                
                # 计算损失
                loss, loss_items = compute_loss(pred, targets, imgs.shape[2:])
                
                # 关键修复2：在反向传播前检查loss有效性
                if not torch.isfinite(loss):
                    print(f"警告: 第{batch_i}批次的损失值为 {loss.item()}，跳过")
                    continue
                
                # 反向传播
                self.model.zero_grad()
                loss.backward()
                
                batch_count += 1
                pbar.update(1)
        
        # 计算平均梯度重要性
        layer_importance = self._compute_importance()
        self.remove_hooks()
        return layer_importance
    
    def safe_forward(self, imgs):
        """安全的前向传播，避免inplace操作问题"""
        try:
            # 方法1：正常前向传播
            pred = self.model(imgs)
            
            # 如果pred是tuple/list，确保每个元素都不是视图
            if isinstance(pred, (tuple, list)):
                return [p.clone() if p is not None else p for p in pred]
            else:
                return pred.clone() if pred is not None else pred
                
        except RuntimeError as e:
            if "inplace" in str(e).lower() or "view" in str(e).lower():
                # 方法2：使用no_grad前向，然后重新连接计算图
                with torch.no_grad():
                    pred = self.model(imgs)
                
                # 重新连接计算图
                if isinstance(pred, (tuple, list)):
                    return [p.detach().requires_grad_(True) if p is not None else p for p in pred]
                else:
                    return pred.detach().requires_grad_(True) if pred is not None else pred
            else:
                raise e
    
    def _compute_importance(self):
        """计算层重要性"""
        layer_importance = {}
        for name, gradients in self.gradient_stats.items():
            if gradients:
                avg_grad = np.mean(gradients)
                std_grad = np.std(gradients)
                layer_importance[name] = {
                    'avg_gradient': avg_grad,
                    'std_gradient': std_grad,
                    'stability': avg_grad / (std_grad + 1e-8)
                }
        return layer_importance


def get_top_gradient_layers(model, dataloader, top_k=5, num_batches=0):
    """获取梯度最大的前k个层 - 修复版本"""
    # 设置环境变量减少警告
    import warnings
    warnings.filterwarnings("ignore", category=UserWarning, message=".*non-full backward hook.*")
    
    analyzer = GradientAnalyzer(model, dataloader)
    layer_importance = analyzer.analyze_gradients(num_batches)
    
    # 按平均梯度排序
    sorted_layers = sorted(layer_importance.items(), 
                          key=lambda x: x[1]['avg_gradient'], 
                          reverse=True)
    
    print("\n" + "="*60)
    print("层重要性排名 (按梯度大小):")
    print("="*60)
    for i, (name, stats) in enumerate(sorted_layers[:top_k*2]):
        print(f"{i+1:2d}. {name:40} | 梯度: {stats['avg_gradient']:8.4f} | "
              f"稳定性: {stats['stability']:8.4f}")
    
    return sorted_layers[:top_k]

def visualize_gradient_analysis(layer_importance, top_k=10):
    """可视化梯度分析结果"""
    sorted_layers = sorted(layer_importance.items(), 
                          key=lambda x: x[1]['avg_gradient'], 
                          reverse=True)[:top_k]
    
    names = [name.split('.')[-1] for name, _ in sorted_layers]
    gradients = [stats['avg_gradient'] for _, stats in sorted_layers]
    
    plt.figure(figsize=(12, 6))
    bars = plt.bar(range(len(names)), gradients, color='skyblue')
    plt.xlabel('网络层')
    plt.ylabel('平均梯度范数')
    plt.title('YOLOv5层重要性分析 (按梯度大小)')
    plt.xticks(range(len(names)), names, rotation=45, ha='right')
    
    # 添加数值标签
    for bar, gradient in zip(bars, gradients):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height(), 
                f'{gradient:.4f}', ha='center', va='bottom')
    
    plt.tight_layout()
    plt.savefig('layer_importance_analysis.png', dpi=300, bbox_inches='tight')
    plt.show()

# 在val.py中的集成使用
def run_with_gradient_analysis(data, weights, batch_size=16, top_k=5, imgsz=[640,640]):
    # 带梯度分析的验证函数
    from utils.datasets import create_dataloader
    from models.experimental import attempt_load
    
    # 加载模型
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = attempt_load(weights, map_location=device)

    # 关键：如果模型已经融合，重新加载非融合版本
    if hasattr(model, 'fuse') and callable(getattr(model, 'fuse', None)):
        print("检测到融合模型，重新加载非融合版本...")
        # 重新加载模型，跳过融合步骤
        model = attempt_load(weights, map_location=device, fuse=False)
    
    # 创建数据加载器
    dataset = check_dataset(data)
    gs = max(int(model.stride.max()), 32)  # grid size (max stride)
    single_cls = False
    imgsz = check_img_size(imgsz, gs, floor=gs * 2)  # verify imgsz is gs-multiple
    hyp = model.hyp
    workers = 4
    cache_mosaic = 512
    dataloader, dataset = create_dataloader(dataset['val'], imgsz, batch_size, gs, single_cls,
                                            hyp=hyp, augment=True, cache=None, rect=False, rank=-1,
                                            workers=workers, image_weights=False, quad=False,
                                            prefix='',shuffle=True, debug_samples=0,save_dir='',cache_mosaic=cache_mosaic)
    
    print("开始梯度分析...")
    top_layers = get_top_gradient_layers(model, dataloader, top_k=top_k, num_batches=20)
    
    print("\n" + "="*60)
    print("建议扩展的层:")
    print("="*60)
    for i, (name, stats) in enumerate(top_layers):
        print(f"{i+1}. {name}")
        print(f"   平均梯度: {stats['avg_gradient']:.4f}")
        print(f"   稳定性: {stats['stability']:.4f}")
    
    return top_layers, model

# 模型扩展建议函数
def get_architecture_suggestions(top_layers, model):
    # 基于梯度分析给出架构扩展建议
    print("\n" + "="*60)
    print("模型架构扩展建议:")
    print("="*60)
    
    suggestions = []
    
    for name, stats in top_layers:
        module = dict(model.named_modules())[name]
        
        if isinstance(module, nn.Conv2d):
            current_channels = module.out_channels
            suggested_channels = min(current_channels * 2, 1024)  # 最大1024通道
            
            suggestion = {
                'layer': name,
                'type': '宽度扩展',
                'current': f"{current_channels} channels",
                'suggested': f"{suggested_channels} channels",
                'reason': f"高梯度({stats['avg_gradient']:.4f})表明此层对任务很重要"
            }
            suggestions.append(suggestion)
            
            print(f"层: {name}")
            print(f"  类型: 卷积层")
            print(f"  建议: 输出通道从 {current_channels} 扩展到 {suggested_channels}")
            print(f"  理由: {suggestion['reason']}")
    
    return suggestions

# https://chat.deepseek.com/share/rplq7mlxbbb267nlcw
# 使用示例
if __name__ == "__main__":
    # 示例用法
    top_layers, model = run_with_gradient_analysis(
        data='data/voc_segment.yaml', #'data/coco128.yaml',
        weights='runs/exp_voc_segment/weights/last.pt',
        top_k=5,
        batch_size=8,
        imgsz=[640,640]
    )
    
    # 获取扩展建议
    suggestions = get_architecture_suggestions(top_layers, model)
    
    # 可视化结果
    analyzer = GradientAnalyzer(model, None)
    # 需要先运行analyze_gradients来获取数据
    # visualize_gradient_analysis(analyzer.gradient_stats)