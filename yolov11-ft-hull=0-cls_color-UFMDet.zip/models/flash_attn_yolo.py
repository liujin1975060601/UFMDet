import torch
import logging
import sys

logger = logging.getLogger(__name__)

def use_flash_attn_flag():
    attn_func = None
    
    try:
        # 1. 检查 PyTorch 版本
        torch_version = torch.__version__
        major_version = int(torch_version.split('.')[0])
        if major_version < 2:
            logger.warning(f"PyTorch 版本 {torch_version} 太低，需要 2.0+")
            raise ImportError("PyTorch version too old")
        
        # 2. 检查 CUDA
        if not torch.cuda.is_available():
            logger.warning("CUDA 不可用")
            raise ImportError("CUDA not available")
        
        # 3. 检查 GPU 架构 (支持 Volta 7.0+)
        device_capability = torch.cuda.get_device_capability()
        if device_capability[0] < 7:
            logger.warning(f"GPU 算力 {device_capability} 太低，需要 7.0+")
            raise ImportError("GPU capability too low")
        
        # 4. 检查 Python 版本 (Flash Attention 可能不支持 3.13)
        python_version = sys.version_info
        if python_version.major == 3 and python_version.minor >= 13:
            logger.warning(f"Python 3.13 可能不被 Flash Attention 完全支持")
        
        # 5. 尝试导入 Flash Attention
        from flash_attn.flash_attn_interface import flash_attn_func
        
        # 6. 测试功能
        batch_size, seq_len, n_heads, head_dim = 1, 64, 4, 64
        q = torch.randn(batch_size, seq_len, n_heads, head_dim, 
                       device='cuda', dtype=torch.float16)
        k = torch.randn(batch_size, seq_len, n_heads, head_dim, 
                       device='cuda', dtype=torch.float16)
        v = torch.randn(batch_size, seq_len, n_heads, head_dim, 
                       device='cuda', dtype=torch.float16)
        
        with torch.no_grad():
            _ = flash_attn_func(q, k, v)

        attn_func = flash_attn_func
        logger.info(f"✓ Flash Attention 启用成功 (GPU: {torch.cuda.get_device_name()})")
        
    except ImportError as e:
        logger.warning(f"Flash Attention 导入失败: {e}")
        attn_func = _fallback_to_sdpa()
    except Exception as e:
        logger.warning(f"Flash Attention 初始化失败: {e}")
        attn_func = _fallback_to_sdpa()
    return attn_func

def _fallback_to_sdpa():
    """回退到 PyTorch SDPA"""
    try:
        from torch.nn.functional import scaled_dot_product_attention as sdpa
        attn_func = sdpa
        logger.info("使用 PyTorch scaled_dot_product_attention")
    except ImportError:
        logger.warning("SDPA 也不可用，需要自定义注意力实现")
        attn_func = _custom_attention
    return attn_func

def _custom_attention(q, k, v, attn_mask=None, dropout_p=0.0, is_causal=False):
    """自定义注意力实现作为最终回退"""
    # 简化的注意力实现
    scale = q.size(-1) ** -0.5
    attn_scores = torch.matmul(q, k.transpose(-2, -1)) * scale
    
    if attn_mask is not None:
        attn_scores = attn_scores + attn_mask
    
    attn_weights = torch.softmax(attn_scores, dim=-1)
    
    if dropout_p > 0.0:
        attn_weights = torch.nn.functional.dropout(attn_weights, p=dropout_p)
    
    return torch.matmul(attn_weights, v)

if __name__ == "__main__":
    use_flash_attn_flag()