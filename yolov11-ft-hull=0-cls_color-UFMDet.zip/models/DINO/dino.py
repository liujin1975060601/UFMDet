# dino_modules_fixed.py

import torch
import torch.nn as nn
import torch.nn.functional as F
import os

# dino_modules_fixed.py

import torch
import torch.nn as nn
import torch.nn.functional as F
import os

class DINOFeatureExtractorFixed(nn.Module):
    """完全隔离梯度的DINO特征提取器"""
    def __init__(self, model_name='vit_base_patch16_224', freeze_layers=6, patch_size=16, in_channels=16):
        super().__init__()
        
        try:
            import timm
            self.dino = timm.create_model('vit_base_patch16_224', pretrained=True, num_classes=0)
            
            # 完全冻结并设置为eval模式
            for param in self.dino.parameters():
                param.requires_grad = False
            self.dino.eval()
                
            print("成功加载并冻结timm DINO模型")
        except Exception as e:
            print(f"无法加载DINO模型: {e}")
            self.dino = None
        
        self.patch_size = patch_size
        self.in_channels = in_channels
        self.embed_dim = 768
        
        # 关键修改：移除所有可训练层，使用固定转换
        self.channel_adapter = None  # 不再使用可训练的适配器
        
        print(f"DINO特征提取器初始化: 使用固定转换，无梯度")
    
    def forward(self, x):
        # 完全禁用梯度计算
        with torch.no_grad():
            return self._forward_impl(x)
    
    def _forward_impl(self, x):
        B, C, H, W = x.shape

        # 使用简单的固定通道转换，避免梯度问题
        if C == 3:
            x_projected = x
        elif C == 1:
            x_projected = x.repeat(1, 3, 1, 1)
        else:
            # 多通道取前3个通道的平均值
            if C >= 3:
                x_projected = x[:, :3].mean(dim=1, keepdim=True).repeat(1, 3, 1, 1)
            else:
                x_projected = x.repeat(1, 3, 1, 1)
        
        # 调整输入尺寸
        target_size = 224
        if H != target_size or W != target_size:
            x_resized = F.interpolate(x_projected, size=(target_size, target_size), mode='bilinear', align_corners=False)
        else:
            x_resized = x_projected
        
        H_patches = target_size // self.patch_size
        W_patches = target_size // self.patch_size
        
        if self.dino is not None:
            try:
                features = self.dino.forward_features(x_resized)
                spatial_feat = self._sequence_to_spatial(features, H_patches, W_patches)
                
                # 对特征进行简单的归一化
                spatial_feat = spatial_feat / (spatial_feat.norm(dim=1, keepdim=True) + 1e-8)
                
                output_features = {
                    'dino_high_res': spatial_feat,
                    'dino_mid_res': F.interpolate(spatial_feat, scale_factor=0.5, mode='bilinear'),
                    'dino_low_res': F.interpolate(spatial_feat, scale_factor=0.25, mode='bilinear')
                }
                
                return output_features
                
            except Exception as e:
                print(f"DINO特征提取失败: {e}")
                return self._create_mock_features(B, device=x.device)
        else:
            return self._create_mock_features(B, device=x.device)
    
    def _create_mock_features(self, batch_size, device):
        """创建固定的模拟特征"""
        H_patches = 224 // self.patch_size
        W_patches = 224 // self.patch_size
        
        # 使用固定的随机种子创建一致的模拟特征
        with torch.random.fork_rng():
            torch.manual_seed(42)
            base_feat = torch.randn(batch_size, self.embed_dim, H_patches, W_patches, device=device) * 0.01
        
        mock_features = {
            'dino_high_res': base_feat,
            'dino_mid_res': F.interpolate(base_feat, scale_factor=0.5, mode='bilinear'),
            'dino_low_res': F.interpolate(base_feat, scale_factor=0.25, mode='bilinear')
        }
        
        return mock_features
    
    def _sequence_to_spatial(self, sequence_output, H_patches, W_patches):
        B, seq_len, feat_dim = sequence_output.shape
        
        if seq_len == H_patches * W_patches + 1:
            patch_tokens = sequence_output[:, 1:, :]
        else:
            patch_tokens = sequence_output[:, :H_patches * W_patches, :]
        
        spatial_feat = patch_tokens.reshape(B, H_patches, W_patches, feat_dim).permute(0, 3, 1, 2)
        return spatial_feat
    
class DINOYOLOFusionFixed(nn.Module):
    """安全的DINO-YOLO融合模块 - 动态通道分配"""
    def __init__(self, ch_list, dino_channels=768, fusion_channels=512, scale_ratio=0.5):
        super().__init__()
        
        print(f"融合层初始化 - ch_list: {ch_list}")
        
        # 解析通道数
        if isinstance(ch_list, list) and len(ch_list) > 0:
            yolo_channels = ch_list[0]
        else:
            yolo_channels = ch_list
        
        self.yolo_channels = yolo_channels
        self.output_channels = yolo_channels
        
        # 动态计算安全的通道分配
        if yolo_channels >= 128:
            dino_ratio = 0.25  # 大通道数时分配25%给DINO
        elif yolo_channels >= 64:
            dino_ratio = 0.375  # 中等通道数时分配37.5%给DINO
        else:
            dino_ratio = 0.5  # 小通道数时分配50%给DINO
        
        dino_adapt_channels = max(4, int(yolo_channels * dino_ratio))
        yolo_adapt_channels = yolo_channels - dino_adapt_channels
        
        print(f"安全通道分配 - 总通道: {yolo_channels}, DINO: {dino_adapt_channels}, YOLO: {yolo_adapt_channels}")
        
        # 动态创建适配器
        self.dino_adapter = nn.Sequential(
            nn.Conv2d(768, dino_adapt_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(dino_adapt_channels),
        ) if dino_adapt_channels > 0 else nn.Identity()
        
        self.yolo_adapter = nn.Sequential(
            nn.Conv2d(yolo_channels, yolo_adapt_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(yolo_adapt_channels),
        ) if yolo_adapt_channels > 0 else nn.Identity()
        
        # 最终输出确保
        self.output_conv = nn.Conv2d(dino_adapt_channels + yolo_adapt_channels, yolo_channels, kernel_size=1)
        
        # 安全的权重初始化
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
        
    def forward(self, inputs):
        if not isinstance(inputs, (list, tuple)) or len(inputs) < 2:
            return inputs[0] if isinstance(inputs, (list, tuple)) and len(inputs) > 0 else inputs
        
        yolo_feat, dino_feat_dict = inputs[0], inputs[1]
        
        # 如果DINO特征无效，直接返回YOLO特征
        if (dino_feat_dict is None or not isinstance(dino_feat_dict, dict) or 
            not dino_feat_dict):
            return yolo_feat
        
        # 获取DINO特征
        dino_feat = None
        for key in ['dino_high_res', 'dino_mid_res', 'dino_low_res']:
            if key in dino_feat_dict:
                dino_feat = dino_feat_dict[key]
                break
        
        if dino_feat is None:
            return yolo_feat
        
        # 调整DINO特征尺寸
        B, C, H, W = yolo_feat.shape
        dino_feat_resized = F.interpolate(dino_feat, size=(H, W), mode='bilinear')
        
        # 处理特征
        dino_adapted = self.dino_adapter(dino_feat_resized.detach()) * 0.1  # 较小权重
        yolo_adapted = self.yolo_adapter(yolo_feat)
        
        # 特征拼接
        if isinstance(dino_adapted, torch.Tensor) and isinstance(yolo_adapted, torch.Tensor):
            fused = torch.cat([yolo_adapted, dino_adapted], dim=1)
            output = self.output_conv(fused)
        else:
            # 如果适配器是Identity，直接使用原始特征
            output = yolo_feat
        
        return output