# dino_modules_fixed.py

import torch
import torch.nn as nn
import torch.nn.functional as F
import os

# dino_modules_fixed.py

import torch
import torch.nn as nn
import torch.nn.functional as F
import os

class DINOFeatureExtractorFixed(nn.Module):
    """完全隔离梯度的DINO特征提取器"""
    def __init__(self, model_name='vit_base_patch16_224', freeze_layers=6, patch_size=16, in_channels=16):
        super().__init__()
        
        try:
            import timm
            self.dino = timm.create_model('vit_base_patch16_224', pretrained=True, num_classes=0)
            
            # 完全冻结并设置为eval模式
            for param in self.dino.parameters():
                param.requires_grad = False
            self.dino.eval()
                
            print("成功加载并冻结timm DINO模型")
        except Exception as e:
            print(f"无法加载DINO模型: {e}")
            self.dino = None
        
        self.patch_size = patch_size
        self.in_channels = in_channels
        self.embed_dim = 768
        
        # 关键修改：移除所有可训练层，使用固定转换
        self.channel_adapter = None  # 不再使用可训练的适配器
        
        print(f"DINO特征提取器初始化: 使用固定转换，无梯度")
    
    def forward(self, x):
        # 完全禁用梯度计算
        with torch.no_grad():
            return self._forward_impl(x)
    
    def _forward_impl(self, x):
        B, C, H, W = x.shape

        # 使用简单的固定通道转换，避免梯度问题
        if C == 3:
            x_projected = x
        elif C == 1:
            x_projected = x.repeat(1, 3, 1, 1)
        else:
            # 多通道取前3个通道的平均值
            if C >= 3:
                x_projected = x[:, :3].mean(dim=1, keepdim=True).repeat(1, 3, 1, 1)
            else:
                x_projected = x.repeat(1, 3, 1, 1)
        
        # 调整输入尺寸
        target_size = 224
        if H != target_size or W != target_size:
            x_resized = F.interpolate(x_projected, size=(target_size, target_size), mode='bilinear', align_corners=False)
        else:
            x_resized = x_projected
        
        H_patches = target_size // self.patch_size
        W_patches = target_size // self.patch_size
        
        if self.dino is not None:
            try:
                features = self.dino.forward_features(x_resized)
                spatial_feat = self._sequence_to_spatial(features, H_patches, W_patches)
                
                # 对特征进行简单的归一化
                spatial_feat = spatial_feat / (spatial_feat.norm(dim=1, keepdim=True) + 1e-8)
                
                output_features = {
                    'dino_high_res': spatial_feat,
                    'dino_mid_res': F.interpolate(spatial_feat, scale_factor=0.5, mode='bilinear'),
                    'dino_low_res': F.interpolate(spatial_feat, scale_factor=0.25, mode='bilinear')
                }
                
                return output_features
                
            except Exception as e:
                print(f"DINO特征提取失败: {e}")
                return self._create_mock_features(B, device=x.device)
        else:
            return self._create_mock_features(B, device=x.device)
    
    def _create_mock_features(self, batch_size, device):
        """创建固定的模拟特征"""
        H_patches = 224 // self.patch_size
        W_patches = 224 // self.patch_size
        
        # 使用固定的随机种子创建一致的模拟特征
        with torch.random.fork_rng():
            torch.manual_seed(42)
            base_feat = torch.randn(batch_size, self.embed_dim, H_patches, W_patches, device=device) * 0.01
        
        mock_features = {
            'dino_high_res': base_feat,
            'dino_mid_res': F.interpolate(base_feat, scale_factor=0.5, mode='bilinear'),
            'dino_low_res': F.interpolate(base_feat, scale_factor=0.25, mode='bilinear')
        }
        
        return mock_features
    
    def _sequence_to_spatial(self, sequence_output, H_patches, W_patches):
        B, seq_len, feat_dim = sequence_output.shape
        
        if seq_len == H_patches * W_patches + 1:
            patch_tokens = sequence_output[:, 1:, :]
        else:
            patch_tokens = sequence_output[:, :H_patches * W_patches, :]
        
        spatial_feat = patch_tokens.reshape(B, H_patches, W_patches, feat_dim).permute(0, 3, 1, 2)
        return spatial_feat
    
class DINOYOLOFusionFixed(nn.Module):
    """修正的DINO-YOLO融合模块 - 处理字典格式的DINO特征"""
    def __init__(self, ch_list, dino_channels=768, fusion_channels=512, scale_ratio=0.5):
        super().__init__()
        
        print(f"融合层初始化 - ch_list: {ch_list}")
        
        # 解析通道数
        if isinstance(ch_list, list):
            if len(ch_list) >= 2:
                yolo_channels, output_channels = ch_list[0], ch_list[1]
            else:
                yolo_channels = ch_list[0]
                output_channels = yolo_channels
        else:
            yolo_channels = ch_list
            output_channels = yolo_channels
        
        # 关键修正：输出通道数应该是yolo_channels（inputs[0]的通道数）
        self.yolo_channels = yolo_channels
        self.output_channels = yolo_channels
        self.dino_channels = dino_channels
        self.scale_ratio = scale_ratio
        
        print(f"融合层: YOLO输入通道={yolo_channels}, 输出通道={self.output_channels}, 尺度比例={scale_ratio}")
        
        # 根据尺度比例选择合适的DINO特征键
        if scale_ratio <= 0.5:
            self.dino_feat_key = 'dino_high_res'  # 小尺度融合用高分辨率
        elif scale_ratio <= 1.0:
            self.dino_feat_key = 'dino_mid_res'   # 中尺度融合用中分辨率
        else:
            self.dino_feat_key = 'dino_low_res'   # 大尺度融合用低分辨率
        
        print(f"选择的DINO特征键: {self.dino_feat_key}")
        
        # 安全地计算通道数
        dino_compression_channels = max(16, min(64, self.output_channels // 4))
        yolo_processed_channels = max(1, self.output_channels - dino_compression_channels)
        
        # 如果计算出的通道数不合理，重新分配
        if yolo_processed_channels <= 0 or dino_compression_channels <= 0:
            print(f"警告: 通道数计算异常，使用默认分配")
            dino_compression_channels = min(32, self.output_channels // 2)
            yolo_processed_channels = self.output_channels - dino_compression_channels
        
        print(f"DINO压缩通道: {dino_compression_channels}")
        print(f"YOLO处理通道: {yolo_processed_channels}")
        print(f"总输出通道: {yolo_processed_channels + dino_compression_channels} = {self.output_channels}")
        
        # DINO特征压缩器
        self.dino_compressor = nn.Sequential(
            nn.Conv2d(dino_channels, dino_compression_channels, kernel_size=1),
            nn.BatchNorm2d(dino_compression_channels),
            nn.ReLU(inplace=True)
        )
        
        # YOLO特征处理器
        self.yolo_processor = nn.Sequential(
            nn.Conv2d(self.yolo_channels, yolo_processed_channels, kernel_size=1),
            nn.BatchNorm2d(yolo_processed_channels),
            nn.ReLU(inplace=True)
        )
        
        # 特征融合卷积
        self.fusion_conv = nn.Sequential(
            nn.Conv2d(self.output_channels, self.output_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(self.output_channels),
            nn.ReLU(inplace=True)
        )
        
        # DINO特征权重（防止梯度爆炸）
        self.dino_scale = 1.0  # 适当调整这个值
        
        print(f"网络结构:")
        print(f"  DINO压缩器: {dino_channels} -> {dino_compression_channels}")
        print(f"  YOLO处理器: {self.yolo_channels} -> {yolo_processed_channels}")
        print(f"  融合卷积: {self.output_channels} -> {self.output_channels}")
        print(f"  DINO特征权重: {self.dino_scale}")
        
    def forward(self, inputs):
        if not isinstance(inputs, (list, tuple)) or len(inputs) < 2:
            raise ValueError(f"融合层需要2个输入，但得到: {type(inputs)}")
        
        yolo_feat, dino_feat_dict = inputs[0], inputs[1]
        
        # print(f"融合层输入 - YOLO特征: {yolo_feat.shape}")
        # print(f"DINO特征字典键: {list(dino_feat_dict.keys())}")
        
        # 检查DINO特征字典是否有效
        if dino_feat_dict is None or not isinstance(dino_feat_dict, dict) or len(dino_feat_dict) == 0:
            print("警告: DINO特征字典无效，直接返回YOLO特征")
            return yolo_feat
        
        # 获取指定的DINO特征
        if self.dino_feat_key in dino_feat_dict:
            dino_feat = dino_feat_dict[self.dino_feat_key]
            # print(f"使用DINO特征: {self.dino_feat_key}, 形状: {dino_feat.shape}")
        else:
            # 如果指定特征不存在，使用第一个可用的特征
            available_keys = list(dino_feat_dict.keys())
            if available_keys:
                dino_feat = dino_feat_dict[available_keys[0]]
                print(f"警告: {self.dino_feat_key}不存在，使用{available_keys[0]}, 形状: {dino_feat.shape}")
            else:
                print("警告: 无DINO特征可用，直接返回YOLO特征")
                return yolo_feat
        
        # 检查DINO特征是否有效
        if dino_feat.isnan().any() or dino_feat.isinf().any():
            print("警告: DINO特征包含NaN或Inf，直接返回YOLO特征")
            return yolo_feat
        
        # 调整DINO特征尺寸以匹配YOLO特征
        B, C, H, W = yolo_feat.shape
        dino_feat_resized = F.interpolate(
            dino_feat, 
            size=(H, W),
            mode='bilinear', 
            align_corners=False
        )
        # print(f"调整尺寸后的DINO特征: {dino_feat_resized.shape}")
        
        # 压缩DINO特征通道
        dino_compressed = self.dino_compressor(dino_feat_resized)
        if dino_compressed.isnan().any() or dino_compressed.isinf().any():
            print("警告: DINO压缩特征包含NaN或Inf，使用零张量替代")
            dino_compressed = torch.zeros_like(dino_compressed)
        # print(f"压缩后的DINO特征: {dino_compressed.shape}")
        
        # 处理YOLO特征
        yolo_processed = self.yolo_processor(yolo_feat)
        # print(f"处理后的YOLO特征: {yolo_processed.shape}")
        
        # 特征拼接（使用缩放后的DINO特征）
        fused_features = torch.cat([yolo_processed, self.dino_scale * dino_compressed], dim=1)
        # print(f"拼接后特征: {fused_features.shape}")
        
        # 最终验证和调整
        if fused_features.shape[1] != self.output_channels:
            print(f"警告: 拼接后通道数{fused_features.shape[1]} != 期望{self.output_channels}")
            # 使用1x1卷积调整到正确通道数
            adjust_conv = nn.Conv2d(fused_features.shape[1], self.output_channels, kernel_size=1).to(fused_features.device)
            fused_features = adjust_conv(fused_features)
            print(f"调整后特征: {fused_features.shape}")
        
        # 特征融合
        final_output = self.fusion_conv(fused_features)
        # print(f"最终输出: {final_output.shape}")
        
        # 最终形状验证
        if final_output.shape != yolo_feat.shape:
            print(f"严重错误: 最终输出形状{final_output.shape} != 输入形状{yolo_feat.shape}")
            print("紧急修复：返回原始YOLO特征")
            return yolo_feat
        
        return final_output
