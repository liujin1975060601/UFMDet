import torch
import torch.nn as nn
import torch.nn.functional as F

class SPTransformer(nn.Module):
    def __init__(self, in_channels, c_out, num_heads=8, num_layers=1, T=4, dropout=0.1):
        super().__init__()
        self.in_channels = in_channels
        self.T = T
        self.num_heads = num_heads
        self.c_out = c_out

        # 计算最小的 embed_dim >= in_channels 且能被 num_heads 整除
        self.embed_dim = ((in_channels + num_heads - 1) // num_heads) * num_heads

        # 如果需要扩展通道，加一个线性投影（1x1 conv 或 Linear）
        if self.embed_dim != in_channels:
            self.proj_in = nn.Conv2d(in_channels, self.embed_dim, kernel_size=1)
        else:
            self.proj_in = nn.Identity()
        self.proj_out = nn.Conv2d(self.embed_dim, c_out, kernel_size=1)

        # 可学习的位置编码: [T, embed_dim]
        self.pos_embed = nn.Parameter(torch.randn(T, self.embed_dim))

        # Transformer encoder (batch_first=True)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=self.embed_dim,
            nhead=num_heads,
            dropout=dropout,
            batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)

    def forward(self, x):
        # Input:  x of shape [B, C_in, H, W]
        # Output: out of shape [B, C_in, H, W]
        B, C_in, H, W = x.shape
        T = self.T

        # Step 1: 投影到 embed_dim（如果需要）
        x = self.proj_in(x)  # [B, embed_dim, H, W]

        # Step 2: repeat T times -> [B, T, embed_dim, H, W]
        x = x.unsqueeze(1).repeat(1, T, 1, 1, 1)

        # Step 3: reshape to [B*H*W, T, embed_dim]
        x = x.permute(0, 3, 4, 1, 2).contiguous()  # [B, H, W, T, embed_dim]
        x = x.view(B * H * W, T, self.embed_dim)

        # Step 4: add position encoding
        x = x + self.pos_embed.unsqueeze(0)  # [B*H*W, T, embed_dim]

        # Step 5: transformer
        x = self.transformer(x)  # [B*H*W, T, embed_dim]

        # Step 6: reshape back to [B, T, embed_dim, H, W]
        x = x.view(B, H, W, T, self.embed_dim)
        x = x.permute(0, 3, 4, 1, 2).contiguous()  # [B, T, embed_dim, H, W]

        # Step 7: average over T
        x = x.mean(dim=1)  # [B, embed_dim, H, W]

        # Step 8: 投影回原始通道数
        x = self.proj_out(x)  # [B, C_in, H, W]

        return x