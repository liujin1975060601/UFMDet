"""Generate 3D red-blue heatmaps from model features and detections.

该脚本在推理过程中注册网络中间层的前向 hook，收集特征图并累积为空间热力图，
随后以 3D 曲面方式渲染，力求接近参考图中红蓝热力图的视觉效果。同时还会
基于检测结果在热图上添加高斯峰值，用于展示模型对目标区域的关注程度。

示例：
    python visualize_3d_heatmap.py \
        --weights runs/train/exp/weights/best.pt \
        --source data/images/zidane.jpg \
        --feature-layers 10,16 \
        --output-dir runs/3d_heatmap
"""

import argparse
import sys
from pathlib import Path
from typing import Dict, Iterable, List

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.backends.cudnn as cudnn
import torch.nn.functional as F
import cv2
import os

# Prevent negative values from rendering as squares when saving figures.
matplotlib.rcParams["axes.unicode_minus"] = False

FILE = Path(__file__).resolve()
ROOT = FILE.parents[0]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from models.experimental import attempt_load
from models.yolo import OUT_LAYER
from utils.datasets import LoadImages, LoadStreams
from utils.general import (
    check_img_size,
    increment_path,
    scale_coords,
    set_logging,
)
from utils.torch_utils import select_device
from utils.ft_utils import scale_coords_ft
from utils.plots import colors
from tools.plotbox import plot_one_box_with_ft
from utils.general import get_source

from utils.post_process import non_max_suppression, non_max_suppression_dfl

class FeatureCapture:
    """通过前向 hook 收集指定层特征图的工具类。

    属性：
        model (torch.nn.Module): 被监视的模型。
        layer_ids (List[int]): 需要捕获的层索引列表。
        handles (List[RemovableHandle]): hook 句柄集合，便于最终释放。
        outputs (Dict[int, torch.Tensor]): 保存捕获到的特征图，key 为层索引。
    """

    def __init__(self, model: torch.nn.Module, layer_ids: Iterable[int]):
        """注册前向 hook。

        参数：
            model (torch.nn.Module): 需要收集特征的模型实例。
            layer_ids (Iterable[int]): 目标层索引，按模型定义的顺序编号。
        """
        # 按层索引注册前向 hook，收集特征图
        self.model = model
        self.layer_ids = list(layer_ids)
        self.handles: List[torch.utils.hooks.RemovableHandle] = []
        self.outputs: Dict[int, torch.Tensor] = {}
        for idx in self.layer_ids:
            layer = self.model.model[idx]
            handle = layer.register_forward_hook(self._make_hook(idx))
            self.handles.append(handle)

    def _make_hook(self, idx: int):
        """生成 hook 函数，捕获指定层的输出。

        参数：
            idx (int): 层索引。

        返回：
            Callable: 将输出存入 ``self.outputs`` 的闭包函数。
        """

        def hook(_, __, output):
            tensor = output[0] if isinstance(output, (list, tuple)) else output
            # Detach so gradients are not kept around when building heatmaps.
            self.outputs[idx] = tensor.detach()

        return hook

    def clear(self) -> None:
        """清空缓存，确保每次推理前没有历史特征残留。"""
        # 推理前清空缓存，避免旧数据残留
        self.outputs.clear()

    def close(self) -> None:
        """移除所有 hook，并释放已缓存的特征。"""
        for handle in self.handles:
            handle.remove()
        self.handles.clear()
        self.outputs.clear()


def parse_args() -> argparse.Namespace:
    """解析命令行参数，构建可配置的可视化流程。

    返回：
        argparse.Namespace: 包含权重路径、输入源、绘图样式等设定。
    """
    # 定义命令行参数，便于灵活配置推理与可视化流程
    parser = argparse.ArgumentParser(description="Render 3D heatmaps from model features.")
    parser.add_argument("--weights", type=str, default='/sgg/liujin/Noah/code/W_NKAF/runs/train/exp2/weights/best_map50.pt', help="Path to model weights (.pt).")
    parser.add_argument("--source", type=str, default='/sgg/liujin/workspace/datas/voc_segment_benchmark/images', help="File/dir/URL/glob, 0 for webcam.")
    parser.add_argument("--imgsz", type=int, default=640, help="Inference size in pixels.")
    parser.add_argument("--conf-thres", type=float, default=0.25, help="Confidence threshold.")
    parser.add_argument("--iou-thres", type=float, default=0.45, help="NMS IoU threshold.")
    parser.add_argument("--device", type=str, default="0", help="CUDA device id or 'cpu'.")
    parser.add_argument(
        "--feature-layers",
        type=str,
        default="10,16",
        help="Comma-separated layer indices to capture (ordered as center, region).",
    )
    parser.add_argument(
        "--max_samples",
        type=int,
        default=16,
        help="当输入为文件夹时，最多可视化的图片数量（-1 表示全部）。",
    )
    parser.add_argument(
        "--z-scale",
        type=float,
        default=1.0,
        help="Z 轴高度放大系数，>1 可让峰值更突出。",
    )
    parser.add_argument("--topk", type=int, default=100, help="Maximum detections saved per image.")
    parser.add_argument("--output-dir", type=str, default="runs/3d_heatmap", help="Output directory root.")
    parser.add_argument("--cmap", type=str, default="jet", help="Matplotlib colormap for surfaces.") #
    parser.add_argument("--elev", type=float, default=30.0, help="Elevation for 3D camera.")
    parser.add_argument("--azim", type=float, default=-60.0, help="Azimuth for 3D camera.")
    parser.add_argument(
        "--save-npy",
        action="store_true",
        help="Save intermediate heatmaps as .npy alongside rendered figures.",
    )
    parser.add_argument(
        "--save-2d",
        action="store_true",
        help="Additionally save 2D heatmaps for quick inspection.",
    )
    parser.add_argument(
        "--augment",
        action="store_true",
        help="Enable augmented inference to mimic training-time scale jitter.",
    )
    return parser.parse_args()


def normalize_map(arr: np.ndarray) -> np.ndarray:
    """对热力图归一化，将数据压缩至 [0, 1] 范围。

    参数：
        arr (np.ndarray): 待归一化的二维数组。

    返回：
        np.ndarray: 归一化后的矩阵，极值差小于阈值时返回全零矩阵。
    """
    # 对热力图归一化，让值域落在 [0,1]
    arr = arr.astype(np.float32)
    arr -= arr.min()
    max_val = arr.max()
    if max_val < 1e-6:
        return np.zeros_like(arr)
    return arr / max_val


def tensor_to_heatmap(tensor: torch.Tensor, out_size: List[int]) -> np.ndarray:
    """将四维特征张量转成与原图大小一致的二维热力图。

    参数：
        tensor (torch.Tensor): 形状为 ``[B, C, H, W]`` 的特征图。
        out_size (List[int]): 目标尺寸 ``[height, width]``。

    返回：
        np.ndarray: 已插值并归一化的二维热力图。

    异常：
        ValueError: 当输入张量维度不为 4 时抛出。
    """
    # 先对通道求平均，再插值到输出尺寸生成二维热力图
    if tensor.dim() != 4:
        raise ValueError(f"Expected tensor with shape [B, C, H, W], got {tuple(tensor.shape)}")
    # Average channels to get an activation summary similar to Grad-CAM without gradients.
    tensor = tensor.mean(dim=1, keepdim=True)
    tensor = F.interpolate(tensor, size=out_size, mode="bilinear", align_corners=False)
    heatmap = tensor[0, 0].cpu().numpy()
    return normalize_map(heatmap)


def detections_to_gaussian_map(detections: torch.Tensor, shape: List[int]) -> np.ndarray:
    """基于检测框生成高斯响应图，突出模型关注的中心区域。

    参数：
        detections (torch.Tensor): 形状 ``[N, 6]`` 的检测结果，包含 ``xyxy、conf、cls``。
        shape (List[int]): 目标热图的尺寸 ``[height, width]``。

    返回：
        np.ndarray: 与输入图同尺度的二维高斯热图。
    """
    # 将检测框转换为高斯峰值，突出模型关注的目标中心
    h, w = shape
    grid_y, grid_x = np.mgrid[0:h, 0:w]
    heatmap = np.zeros((h, w), dtype=np.float32)
    for det in detections:
        x1, y1, x2, y2, conf, _cls = det.tolist()
        cx = (x1 + x2) * 0.5
        cy = (y1 + y2) * 0.5
        sigma_x = max((x2 - x1) / 6.0, 1.0)
        sigma_y = max((y2 - y1) / 6.0, 1.0)
        exponent = ((grid_x - cx) ** 2) / (2.0 * sigma_x ** 2) + ((grid_y - cy) ** 2) / (2.0 * sigma_y ** 2)
        gaussian = np.exp(-exponent) * conf
        heatmap = np.maximum(heatmap, gaussian)
    return normalize_map(heatmap)


def save_surface(data: np.ndarray, out_path: Path, cmap: str, elev: float, azim: float, title: str, z_scale: float) -> None:
    """以三维曲面方式保存热力图。

    参数：
        data (np.ndarray): 归一化后的热力图数据。
        out_path (Path): 输出文件路径。
        cmap (str): 配色方案名称。
        elev (float): 3D 视角的俯仰角。
        azim (float): 3D 视角的方位角。
        title (str): 图像标题。
        z_scale (float): Z 轴放大系数，影响峰值高度。
    """
    # 使用 3D surface 渲染热力图，模拟论文中的红蓝立体图
    h, w = data.shape
    x = np.arange(w)
    y = np.arange(h)
    X, Y = np.meshgrid(x, y)
    fig = plt.figure(figsize=(6, 5), dpi=220)
    ax = fig.add_subplot(111, projection="3d")
    fig.patch.set_facecolor("white")
    ax.set_facecolor("white")
    surface_vals = data * max(z_scale, 1e-6)
    vmax_val = float(max(1.0, surface_vals.max() if surface_vals.size else 1.0))
    surf = ax.plot_surface(
        X,
        Y,
        surface_vals,
        cmap=cmap,
        linewidth=0,
        antialiased=False,
        vmin=0.0,
        vmax=vmax_val,
    )
    # 上下翻转Y轴
    ax.set_ylim(ax.get_ylim()[::-1])
    
    ax.view_init(elev=elev, azim=azim)
    ax.set_box_aspect((w, h, max(h, w) * 0.4 * max(z_scale, 1.0)))
    ax.grid(False)
    ax.set_axis_off()
    ax.set_title(title, fontsize=10)
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis.pane.set_edgecolor("white")
        axis.pane.set_facecolor((1, 1, 1, 0))
        line = getattr(axis, "line", None)
        if line is not None:
            line.set_visible(False)
    fig.colorbar(surf, shrink=0.5, aspect=10, pad=0.02)
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)


def save_heatmap_2d(data: np.ndarray, out_path: Path, cmap: str, title: str) -> None:
    """以 2D 形式保存热力图，方便快速查看。

    参数：
        data (np.ndarray): 归一化热图。
        out_path (Path): 输出路径。
        cmap (str): 显示所用配色方案。
        title (str): 图像标题。
    """
    # 可选保存二维热力图，便于快速浏览
    plt.figure(figsize=(4.5, 4.5), dpi=220)
    plt.imshow(data, cmap=cmap)
    plt.colorbar(fraction=0.046, pad=0.04)
    plt.title(title)
    plt.axis("off")
    plt.tight_layout()
    plt.savefig(out_path, bbox_inches="tight")
    plt.close()


def detect(
    model,
    img,
    augment,
    conf_thres,
    iou_thres,
    agnostic_nms,
    max_det,
    head_type,
    classes=None,
):
    """执行一次前向推理并完成 NMS，必要时提取傅里叶系数。

    参数：
        model (nn.Module): 目标检测模型。
        img (torch.Tensor): 预处理后的输入图像张量，形状 ``[B,3,H,W]``。
        augment (bool): 是否启用数据增强推理。
        conf_thres (float): 置信度阈值。
        iou_thres (float): IoU 阈值。
        agnostic_nms (bool): 是否进行类别无关的 NMS。
        max_det (int): 单图最大保留目标数。
        head_type (int): 检测头类型，参考 ``models.yolo.OUT_LAYER``。
        classes (Optional[Iterable[int]]): 只保留的类别索引。

    返回：
        Tuple[List[torch.Tensor], List[torch.Tensor], torch.Tensor, Optional[List[torch.Tensor]]]:
            - det: 每张图的 NMS 结果列表。
            - indices: NMS 对应的候选索引，用于匹配傅里叶系数。
            - base_pred: 原始输出张量。
            - selected_ft: 若模型包含傅里叶头，则为每张图选中的系数列表，否则为 ``None``。
    """
    # 复用项目中的推理接口并执行 NMS，并在需要时提取傅里叶系数
    prediction = model(img, augment=augment, visualize=False)
    pred_ft = None
    if head_type == OUT_LAYER.get("DetectDFL_FT"):
        base_pred, pred_ft, _ = prediction
    else:
        base_pred = prediction[0] if isinstance(prediction, (list, tuple)) else prediction

    if not isinstance(base_pred, torch.Tensor):
        base_pred = torch.tensor(base_pred)

    if head_type == OUT_LAYER.get("Detect"):
        det, indices = non_max_suppression(
            base_pred.clone(),
            conf_thres,
            iou_thres,
            classes=classes,
            agnostic=agnostic_nms,
            max_det=max_det,
            return_indices=True,
        )
    else:
        det, indices = non_max_suppression_dfl(
            base_pred.clone(),
            conf_thres,
            iou_thres,
            labels=classes,
            agnostic=agnostic_nms,
            multi_label=True,
            max_det=max_det,
            return_indices=True,
        )

    selected_ft = None
    if head_type == OUT_LAYER.get("DetectDFL_FT") and pred_ft is not None:
        selected_ft = []
        if isinstance(pred_ft, (list, tuple)):
            iterable_ft = pred_ft
        else:
            tensor_ft = pred_ft if isinstance(pred_ft, torch.Tensor) else torch.as_tensor(pred_ft, device=base_pred.device)
            iterable_ft = tensor_ft if tensor_ft.dim() == 3 else tensor_ft.unsqueeze(0)

        for ft_map, index in zip(iterable_ft, indices):
            # 针对 batch 内每张图选择对应的傅里叶系数，保证索引对齐
            ft_tensor = ft_map if isinstance(ft_map, torch.Tensor) else torch.as_tensor(ft_map, device=base_pred.device)
            if index.numel() == 0:
                selected_ft.append(ft_tensor.new_zeros((0, ft_tensor.shape[-1])))
            else:
                selected_ft.append(ft_tensor[index])

    return det, indices, base_pred, selected_ft


def main() -> None:
    """脚本主入口，负责模型加载、推理循环与结果保存。"""
    opt = parse_args()
    #kitti
    opt.weights = '../models/isAID/isAID-hull_ft-yolov11s-ft-bs16-71.31-38.03-epo99-640x640/weights/best.pt'
    opt.source = get_source('','data/isAID-hull_ft.yaml')
    opt.max_samples = 16

    set_logging()

    device = select_device(opt.device)
    half = device.type != "cpu"

    model = attempt_load(opt.weights, map_location=device, fuse=False)
    stride = int(model.stride.max())
    imgsz = check_img_size(opt.imgsz, s=stride)

    capture_layers = [int(idx.strip()) for idx in opt.feature_layers.split(",") if idx.strip()]
    feature_capture = FeatureCapture(model, capture_layers)

    if half:
        model.half()

    streaming_source = opt.source.isnumeric() or opt.source.lower().startswith(("rtsp://", "rtmp://", "http://", "https://"))
    if streaming_source:
        dataset = LoadStreams(opt.source, img_size=imgsz, stride=stride, auto=True)
        bs = len(dataset)
        cudnn.benchmark = True
    else:
        dataset = LoadImages(opt.source, img_size=imgsz, stride=stride, auto=True)
        bs = 1
    dir_source = (not streaming_source) and Path(opt.source).is_dir()

    # 自动递增输出目录，避免覆盖既有结果
    opt.save_dir = os.path.join(os.path.dirname(os.path.dirname(opt.weights)),'3d_heatmap')
    save_dir = increment_path(Path(opt.save_dir), exist_ok=False)
    save_dir.mkdir(parents=True, exist_ok=True)
    print(f"Saving visualizations to {save_dir}")

    names = model.module.names if hasattr(model, "module") else model.names

    # 自动判断当前模型使用的检测头类型，兼容不同结构
    head_type = OUT_LAYER.get("Detect", 0)
    for layer_name, layer_idx in OUT_LAYER.items():
        module = model.get_module_byname(layer_name)
        if module is not None:
            head_type = layer_idx
            break

    processed = 0
    for path, img, im0s, vid_cap in dataset:
        feature_capture.clear()
        # 将 numpy 转成 tensor，并按需求转为半精度
        img_tensor = torch.from_numpy(img).to(device)
        img_tensor = img_tensor.half() if half else img_tensor.float()
        img_tensor /= 255.0
        if img_tensor.ndim == 3:
            img_tensor = img_tensor.unsqueeze(0)

        detections, indices, _, selected_ft = detect(
            model,
            img_tensor,
            opt.augment,
            opt.conf_thres,
            opt.iou_thres,
            agnostic_nms=False,
            max_det=opt.topk,
            head_type=head_type,
            classes=None,
        )

        if bs > 1:  # stream mode returns batches
            raise NotImplementedError("Streaming sources are not supported for 3D heatmap export yet.")

        im0 = im0s.copy()
        stem = Path(path).stem
        img_dir = save_dir / stem
        img_dir.mkdir(parents=True, exist_ok=True)

        ft_np = None

        if len(detections) == 0:
            print(f"No detections found in {stem}, skipping prediction heatmap.")
            detections_scaled = torch.empty((0, 6))
        else:
            detections = detections[0]
            detections_scaled = detections.clone()
            detections_scaled[:, :4] = scale_coords(img_tensor.shape[2:], detections[:, :4], im0.shape)
            if selected_ft is not None and len(selected_ft) > 0:
                ft_tensor = selected_ft[0]
                if isinstance(ft_tensor, torch.Tensor) and ft_tensor.numel() > 0:
                    ft_np = ft_tensor.detach().cpu().numpy().copy()
                    ft_np = scale_coords_ft(img_tensor.shape[2:], ft_np, im0.shape)

        detections_np = (
            detections_scaled.detach().cpu().numpy()
            if detections_scaled.numel() > 0
            else np.empty((0, 6))
        )

        # 保存当前样本需要输出的热力图集合 key->heatmap
        heatmaps: Dict[str, np.ndarray] = {}

        for idx in capture_layers:
            if idx not in feature_capture.outputs:
                print(f"Layer {idx} did not produce an output for {stem}.")
                continue
            # 将特征图转成与原图同尺寸的二维热力图
            spatial = tensor_to_heatmap(feature_capture.outputs[idx], [im0.shape[0], im0.shape[1]])
            heatmaps[f"layer_{idx}"] = spatial

        # if len(capture_layers) >= 2:
        #     first_key = f"layer_{capture_layers[0]}"
        #     second_key = f"layer_{capture_layers[1]}"
        #     if first_key in heatmaps and second_key in heatmaps:
        #         # 两个分支热力图相乘，近似论文中的融合效果
        #         combined = normalize_map(heatmaps[first_key] * heatmaps[second_key])
        #         heatmaps["combined"] = combined

        if detections_scaled.shape[0] > 0:
            # 预测热力图体现模型在目标位置的响应
            gaussian_map = detections_to_gaussian_map(detections_scaled[:, :6], [im0.shape[0], im0.shape[1]])
            heatmaps["prediction"] = gaussian_map

        if ft_np is not None and detections_np.shape[0] == ft_np.shape[0] and detections_np.shape[0] > 0:
            # 仅保留傅里叶轮廓可视化，满足“不要旋转框”的需求
            fourier_vis = im0.copy()
            for det_row, ft_row in zip(detections_np, ft_np):
                cls_id = int(det_row[5]) if det_row.shape[0] > 5 else 0
                conf_val = float(det_row[4]) if det_row.shape[0] > 4 else 0.0
                color = tuple(int(c) for c in colors(cls_id, bgr=True))
                label = f"{names[int(cls_id)]} {conf_val:.2f}"
                plot_one_box_with_ft(det_row[:4], fourier_vis, color=color, label=label, ft_label=ft_row)

            cv2.imwrite(str(img_dir / "prediction_fourier.jpg"), fourier_vis)

        for key, data in heatmaps.items():
            title = f"{stem} - {key}"
            surface_path = img_dir / f"{key}_3d.png"
            save_surface(data, surface_path, opt.cmap, opt.elev, opt.azim, title, opt.z_scale)
            if opt.save_2d:
                save_heatmap_2d(data, img_dir / f"{key}_2d.png", opt.cmap, title)
            if opt.save_npy:
                np.save(img_dir / f"{key}.npy", data)

        label_lines = []
        if detections_scaled.shape[0] > 0:
            for det in detections_scaled[: opt.topk]:
                x1, y1, x2, y2, conf, cls = det[:6].tolist()
                label = f"{names[int(cls)]} {conf:.2f} ({x1:.1f},{y1:.1f},{x2:.1f},{y2:.1f})"
                label_lines.append(label)
        metadata_path = img_dir / "detections.txt"
        # 保存文本信息，方便快速核对检测结果
        metadata_path.write_text("\n".join(label_lines) if label_lines else "No detections.")

        processed += 1
        if dir_source and opt.max_samples > 0 and processed >= opt.max_samples:
            print(f"达到 --max_samples={opt.max_samples} 限制，停止后续可视化。")
            break

    feature_capture.close()


if __name__ == "__main__":
    main()
